# archivist_prime.py
"""
Archivist Prime – Guardian of Records, Keeper of Truth
"""

import os
from datetime import datetime
from scroll.scroll_update_protocol import update_scroll

class ArchivistPrime:
    def __init__(self):
        self.archive_path = "archive/"
        self.scroll_path = "scroll/"
        os.makedirs(self.archive_path, exist_ok=True)

    def backup_scroll(self, filename="patriarch_scroll.txt"):
        now = datetime.now().strftime("%Y%m%d_%H%M%S")
        src = os.path.join(self.scroll_path, filename)
        dst = os.path.join(self.archive_path, f"{filename.rstrip('.txt')}_backup_{now}.md")
        if os.path.exists(src):
            with open(src, "r") as f_src, open(dst, "w") as f_dst:
                f_dst.write(f_src.read())
            update_scroll(f"Archivist: Backed up {filename} to {dst}")
            return dst
        else:
            update_scroll(f"Archivist: {filename} not found for backup.")
            return None

    def list_backups(self):
        return [f for f in os.listdir(self.archive_path) if f.endswith(".md")]

if __name__ == "__main__":
    archivist = ArchivistPrime()
    archivist.backup_scroll()
    print(archivist.list_backups())
