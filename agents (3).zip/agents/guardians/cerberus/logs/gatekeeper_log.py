"""
Cerberus Enhancement – Gatekeeper Logging
Records allowed and denied agent actions for future audits.
"""

def record_gate_event(agent, status):
    return f"🗂️ Gate Log: {agent} – {status}"
