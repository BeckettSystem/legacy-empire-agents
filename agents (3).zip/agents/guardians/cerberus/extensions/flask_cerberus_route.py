
# flask_cerberus_route.py
from flask import Blueprint, request, jsonify
from utils.redis_handler import store_data
from datetime import datetime

cerberus_bp = Blueprint('cerberus_bp', __name__)

@cerberus_bp.route('/system_check', methods=['POST'])
def system_check():
    data = request.json
    check_input = data.get("check")
    if not check_input:
        return jsonify({"error": "Missing 'check' field"}), 400

    entry = {
        "check": check_input,
        "timestamp": datetime.utcnow().isoformat(),
        "status": "received"
    }
    store_data("cerberus_check_queue", entry)
    return jsonify({"message": "Check sent to Cerberus", "entry": entry}), 200
