"""
Cerberus Enhancement – System Lockdown Trigger
Enforces a halt across agents if conditions are breached.
"""

def trigger_lockdown(status_flag):
    if status_flag in ["data_breach", "rogue_process", "untracked_agent"]:
        return "🔒 Lockdown executed by Cerberus."
    return "✅ No lockdown required."
