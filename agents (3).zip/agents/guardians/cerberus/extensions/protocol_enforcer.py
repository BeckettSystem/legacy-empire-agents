"""
Cerberus Enhancement – Protocol Enforcer
Checks if agent actions match defined protocol rules.
"""

def validate_protocol(task_data):
    if "unauthorized" in task_data.get("tags", []):
        return "🚫 Violation: Unauthorized protocol detected."
    return "✅ Protocol approved."
