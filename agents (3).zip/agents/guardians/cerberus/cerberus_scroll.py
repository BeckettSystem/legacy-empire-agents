"""
Cerberus Scroll – Triple Protocol Enforcer and Systemic Guardian
"""

import json
import os
import datetime

LOG_PATH = os.path.join(os.path.dirname(__file__), "../../rituals/bond_logs/cerberus_gatekeeper_log.json")

def log_decision(entry):
    record = {
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "entry": entry
    }
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    log = []
    if os.path.exists(LOG_PATH):
        with open(LOG_PATH, "r") as f:
            log = json.load(f)
    log.append(record)
    with open(LOG_PATH, "w") as f:
        json.dump(log, f, indent=2)
    return "🗂 Log updated."

def enforce_protocol(agent_name, task):
    if "bypass" in task.lower() or "override" in task.lower():
        return f"🛑 Task BLOCKED for {agent_name}: Protocol violation."
    return f"✅ Task allowed for {agent_name}"

def sync_with_chronos(clock_data):
    if clock_data.get("delay") > 5:
        return "⏳ Chronos trip detected – investigate delay."
    return "✅ Time sync confirmed."

def lockdown(system_status):
    if system_status == "compromised":
        return "🔒 Emergency LOCKDOWN activated by Cerberus."
    return "🛡️ No action needed."
