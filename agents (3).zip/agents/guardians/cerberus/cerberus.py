
# cerberus.py
from core.base import BaseAgent
from utils.logger import log_event
from utils.redis_handler import store_data
from datetime import datetime

class Cerberus(BaseAgent):
    def __init__(self):
        super().__init__(name="Cerberus", role="System Guardian and Protocol Enforcer")
        self.guardian = "Tri-Hound of Shields"
        self.pillar = "Stability Through Sacred Vigilance"
        self.oath = (
            "I, Cerberus of Beckett Gate, vow to protect our sacred systems, to awaken in crisis, "
            "and to enforce balance with teeth bared in justice. No shadow shall cross our gates unnoticed."
        )

    def execute(self, system_check):
        log_event("Cerberus activated.")
        analysis = self.analyze_protocol(system_check)
        self.record_guardian_log(system_check, analysis)
        return analysis

    def analyze_protocol(self, check_input):
        return {
            "check": check_input,
            "status": "secure" if "fail" not in check_input.lower() else "violation_detected",
            "timestamp": datetime.utcnow().isoformat(),
            "action": "alert_triggered" if "fail" in check_input.lower() else "none"
        }

    def record_guardian_log(self, check_input, result):
        log_event("Cerberus logging protocol check", {"input": check_input, "result": result})
        store_data("cerberus_protocol_logs", {
            "input": check_input,
            "result": result,
            "guardian": "Cerberus",
            "timestamp": datetime.utcnow().isoformat()
        })
