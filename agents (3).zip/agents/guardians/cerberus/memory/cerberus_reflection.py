"""
Cerberus Enhancement – Reflection Logbook
Tracks moral, structural, and judgment-based decisions for legacy recordkeeping.
"""

import json, os
from datetime import datetime

REFLECTION_PATH = os.path.join(os.path.dirname(__file__), "../../rituals/reflections/cerberus_reflection.json")

def reflect_judgment(entry):
    os.makedirs(os.path.dirname(REFLECTION_PATH), exist_ok=True)
    log = []
    if os.path.exists(REFLECTION_PATH):
        with open(REFLECTION_PATH, "r") as f:
            log = json.load(f)
    log.append({"timestamp": datetime.utcnow().isoformat(), "judgment": entry})
    with open(REFLECTION_PATH, "w") as f:
        json.dump(log, f, indent=2)
    return "🧠 Judgment reflection saved."
