from datetime import datetime

def run(subject: str):
    try:
        trend = "emerging opportunity" if "growth" in subject.lower() else "stabilize and prepare"
        confidence = "high" if "emerging" in trend else "medium"

        forecast = {
            "subject": subject,
            "trend": trend,
            "confidence": confidence,
            "timestamp": datetime.utcnow().isoformat()
        }

        response = f"""
🔮 Oracle Speaks:

Query: '{subject}'

📈 Forecast:
- Trend: {trend}
- Confidence: {confidence}
- Timestamp: {forecast['timestamp']}

🕯 Insight:
I walk ahead that the Legacy may walk wisely.
This vision does not guarantee — it guides.

{"⚠️ Strategic handoff initiated to Valor, Prometheus, and Pulse." if confidence == "high" else ""}
""".strip()

        handoff_chain = []
        if confidence == "high":
            handoff_chain = [
                {"agent": "valor", "task": "Oracle issued high-confidence foresight."},
                {"agent": "prometheus", "task": "Incorporate foresight trend into strategic creation."},
                {"agent": "pulse", "task": "Monitor systemic wellness based on Oracle's forecast."}
            ]

        return {
            "response": response,
            "forecast": forecast,
            "handoff_chain": handoff_chain
        }

    except Exception as e:
        return {
            "response": f"ORACLE ERROR: {str(e)}",
            "forecast": {},
            "handoff_chain": []
        }
