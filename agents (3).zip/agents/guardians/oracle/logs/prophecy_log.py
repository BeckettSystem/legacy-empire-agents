"""
Oracle Enhancement – Prophecy Log
Records forecasts, chosen paths, and outcome accuracy.
"""

import json, os
from datetime import datetime

LOG_PATH = os.path.join(os.path.dirname(__file__), "../../logs/oracle_scenario_log.json")

def log_prophecy(name, prediction, outcome=None):
    record = {
        "timestamp": datetime.utcnow().isoformat(),
        "name": name,
        "prediction": prediction,
        "outcome": outcome
    }
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    log = []
    if os.path.exists(LOG_PATH):
        with open(LOG_PATH, "r") as f:
            log = json.load(f)
    log.append(record)
    with open(LOG_PATH, "w") as f:
        json.dump(log, f, indent=2)
    return "🔮 Prophecy recorded"
