
# flask_oracle_route.py
from flask import Blueprint, request, jsonify
from utils.redis_handler import store_data
from datetime import datetime

oracle_bp = Blueprint('oracle_bp', __name__)

@oracle_bp.route('/submit_scenario', methods=['POST'])
def submit_scenario():
    data = request.json
    scenario = data.get("scenario")
    source = data.get("from", "unknown")
    if not scenario:
        return jsonify({"error": "Missing 'scenario' field"}), 400

    entry = {
        "source": source,
        "scenario": scenario,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("oracle_forecast_triggers", entry)
    return jsonify({"message": "Scenario submitted to Oracle", "entry": entry}), 200
