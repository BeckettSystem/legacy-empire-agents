"""
Oracle Enhancement – Signal Strength Calculator
Rates forecast clarity and scenario strength from signal confidence.
"""

def calculate_strength(clarity, confidence):
    score = (clarity + confidence) / 2
    if score < 50:
        return "🌫 Weak signal – forecast unstable"
    elif score < 75:
        return "🔆 Moderate signal – review advised"
    return "💡 Clear signal – strong forecast"
