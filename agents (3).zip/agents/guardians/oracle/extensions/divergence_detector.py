"""
Oracle Enhancement – Divergence Detector
Compares actual outcome to predicted scenario to find drift.
"""

def detect_divergence(prediction, actual):
    if prediction != actual:
        return "⚠️ Divergence Detected – forecast vs. result mismatch"
    return "✅ Outcome aligned with forecast"
