
# oracle_scenario_tree.py
from datetime import datetime

def generate_scenario_tree(seed_idea):
    return {
        "root": seed_idea,
        "branches": [
            {"path": "positive_shift", "impact": "growth", "confidence": "high"},
            {"path": "negative_shift", "impact": "risk", "confidence": "medium"},
            {"path": "status_quo", "impact": "stability", "confidence": "low"}
        ],
        "timestamp": datetime.utcnow().isoformat()
    }
