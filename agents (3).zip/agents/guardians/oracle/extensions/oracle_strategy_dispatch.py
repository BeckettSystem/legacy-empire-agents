
# oracle_strategy_dispatch.py
from utils.redis_handler import store_data
from datetime import datetime

def send_to_apollo(scenario):
    payload = {
        "from": "Oracle",
        "to": "Apollo",
        "type": "strategy_brief",
        "content": scenario,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("apollo_campaign_queue", payload)
    return payload

def send_to_mentor(scenario):
    strategy = {
        "from": "Oracle",
        "to": "Mentor",
        "type": "agent_preparation_trigger",
        "scenario": scenario,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("mentor_growth_log", strategy)
    return strategy
