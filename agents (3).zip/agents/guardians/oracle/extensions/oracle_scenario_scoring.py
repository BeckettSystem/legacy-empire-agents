
# oracle_scenario_scoring.py
from datetime import datetime

def categorize_scenario(text):
    text = text.lower()
    if "opportunity" in text or "expansion" in text:
        return "Opportunity"
    elif "risk" in text or "threat" in text or "instability" in text:
        return "Disruption"
    elif "window" in text or "shift" in text:
        return "Adaptation Window"
    return "Unknown"

def score_forecast(text):
    return {
        "confidence": "high" if "growth" in text.lower() else "medium",
        "urgency": "now" if "critical" in text.lower() else "monitor",
        "timestamp": datetime.utcnow().isoformat()
    }
