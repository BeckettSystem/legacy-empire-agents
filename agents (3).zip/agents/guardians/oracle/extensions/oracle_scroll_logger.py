
# oracle_scroll_logger.py
from utils.redis_handler import store_data
from datetime import datetime

def log_to_scroll(entry):
    record = {
        "origin": "Oracle",
        "type": "foresight_entry",
        "data": entry,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("patriarch_scroll_log", record)
    return record
