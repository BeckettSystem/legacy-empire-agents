"""
use_scholar – A simplified deep research bridge for agents.

Place this in any agent's /extensions/ folder.

Usage:
    from extensions.use_scholar import use_scholar
    result = use_scholar("AI and Real Estate")
    print(result["summary"])
"""

from agents.knowledge.scholar.extensions.scholar_deep_search import query_sources
from agents.knowledge.scholar.extensions.citation_engine import generate_citations

def use_scholar(topic):
    try:
        research = query_sources(topic)
        citations = generate_citations(research["summary"], topic)
        return {
            "topic": topic,
            "summary": research["summary"],
            "citations": citations
        }
    except Exception as e:
        return {
            "topic": topic,
            "summary": f"[Scholar Error] Unable to retrieve: {topic}",
            "citations": [],
            "error": str(e)
        }
