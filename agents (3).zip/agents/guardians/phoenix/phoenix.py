
from phoenix_scroll import scroll
from waste_classification_engine import detect_waste_flags
from emotional_residue_filter import filter_emotional_decay
from reforging_dispatcher import dispatch_to_reforging
from void_ledger_writer import archive_to_void
from phoenix_release_protocol import initiate_release
from datetime import datetime

class Phoenix:
    def __init__(self):
        self.profile = scroll()

    def review_entry(self, entry, entry_id="unknown"):
        flags = detect_waste_flags(entry)
        release_action = initiate_release(entry, flags)

        result = {
            "entry_id": entry_id,
            "waste_tags": flags,
            "release_action": release_action,
            "timestamp": datetime.utcnow().isoformat()
        }

        if "emotional_residue" in flags:
            result["emotional_filter"] = filter_emotional_decay([entry])
        if "structural_expiry" in flags or "redundant_scroll" in flags:
            result["void_log"] = archive_to_void(entry_id, reason="System renewal purge")

        if "emotional_residue" in flags or "redundant_scroll" in flags:
            result["reforge_dispatch"] = dispatch_to_reforging(entry)

        return result
