# core/utilities/warden_log_trail.py
import os
import datetime

def log_change(actor, action, target_file):
    log_path = "core/logs/warden_chain_of_custody.log"
    with open(log_path, "a") as log:
        log.write(f"{datetime.datetime.now()} | {actor} | {action} | {target_file}\n")
