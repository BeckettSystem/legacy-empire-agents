# core/scrolls/scroll_warden.py
from core.guardians.warden import Warden

def run_audit(sample_text, context=""):
    w = Warden()
    result = w.scan(sample_text, context)
    return result
