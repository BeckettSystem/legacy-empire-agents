# core/guardians/warden.py
import json
import datetime

class Warden:
    def __init__(self, soul_path="core/souls/soul_warden.json"):
        with open(soul_path) as f:
            self.soul = json.load(f)
        self.log_path = "core/logs/warden_reflection.log"

    def scan(self, payload: str, context: str = ""):
        alerts = []
        trigger_terms = self.soul.get("trigger_terms", [])
        for term in trigger_terms:
            if term.lower() in payload.lower():
                alerts.append(term)
        if alerts:
            self.log_decision(payload, alerts, context)
            return {"status": "alert", "terms": alerts}
        return {"status": "clear"}

    def log_decision(self, text, alerts, context):
        with open(self.log_path, "a") as log:
            log.write(f"{datetime.datetime.now()} | ALERT: {alerts} | Context: {context}\nContent: {text}\n\n")
