"""
Warden Enhancement – Chain Integrity Scanner
Verifies that log, scroll, and ritual chains have not been altered.
"""

def scan_chain(records, expected_hashes):
    mismatches = [k for k, h in expected_hashes.items() if records.get(k) != h]
    if mismatches:
        return f"🧨 Chain Integrity Breach: {', '.join(mismatches)}"
    return "✅ Chain verified"
