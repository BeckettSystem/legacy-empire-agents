# core/schedulers/warden_schedule.py
from core.scrolls.scroll_warden import run_audit
import os

def scheduled_compliance_check():
    content_folder = "content/to_audit"
    for filename in os.listdir(content_folder):
        if filename.endswith(".txt"):
            with open(os.path.join(content_folder, filename), "r") as file:
                text = file.read()
                result = run_audit(text, context=filename)
                print(f"{filename}: {result}")
