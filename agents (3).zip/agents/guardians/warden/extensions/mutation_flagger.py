"""
Warden Enhancement – Mutation Flagging
Detects unauthorized edits to scrolls, souls, or logs.
"""

def flag_mutation(file_name, modified_by):
    if modified_by not in ["Valor", "Patriarch"]:
        return f"⚠️ Unauthorized Mutation Detected in {file_name} by {modified_by}"
    return "✅ Authorized edit"
