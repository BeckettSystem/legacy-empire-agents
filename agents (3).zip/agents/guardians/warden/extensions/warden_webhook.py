# core/integrations/warden_webhook.py
import requests

def send_alert(message, webhook_url):
    payload = {"text": message}
    response = requests.post(webhook_url, json=payload)
    return response.status_code
