# core/extensions/warden_advanced_scan.py
import openai
import os

openai.api_key = os.getenv("OPENAI_API_KEY")

def gpt_compliance_review(text):
    prompt = f"Review this content for any possible legal, ethical, or fair housing violations:\n\n{text}\n\nBe specific."
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are a compliance auditor."},
            {"role": "user", "content": prompt}
        ]
    )
    return response.choices[0].message['content']
