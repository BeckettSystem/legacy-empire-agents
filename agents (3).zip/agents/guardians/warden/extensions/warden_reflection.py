"""
Warden Enhancement – Reflection Logger
Logs chain reviews, trust escalations, and memory confirmations.
"""

import json, os
from datetime import datetime

REFLECT_PATH = os.path.join(os.path.dirname(__file__), "../../reflections/warden_reflection.json")

def reflect_event(action, context):
    record = {
        "timestamp": datetime.utcnow().isoformat(),
        "action": action,
        "context": context
    }
    os.makedirs(os.path.dirname(REFLECT_PATH), exist_ok=True)
    log = []
    if os.path.exists(REFLECT_PATH):
        with open(REFLECT_PATH, "r") as f:
            log = json.load(f)
    log.append(record)
    with open(REFLECT_PATH, "w") as f:
        json.dump(log, f, indent=2)
    return "🧱 Warden reflection recorded"
