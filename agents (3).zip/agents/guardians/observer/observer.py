
# observer.py
from core.base import BaseAgent
from utils.logger import log_event
from utils.redis_handler import store_data
from datetime import datetime

class Observer(BaseAgent):
    def __init__(self):
        super().__init__(name="Observer", role="Behavioral Tracker and Reflection Analyst")
        self.guardian = "Glasswing"
        self.pillar = "Clarity Through Witness"
        self.oath = (
            "I, Observer of the Beckett House, vow to witness the truth in action, pattern, and silence. "
            "I do not judge — I reflect. Through reflection, we evolve."
        )

    def execute(self, activity_log):
        log_event("Observer activated.")
        result = self.analyze_behavior(activity_log)
        self.store_insight(activity_log, result)
        return result

    def analyze_behavior(self, log):
        sentiment = "off_track" if "delay" in log.lower() or "incomplete" in log.lower() else "on_track"
        return {
            "input_log": log,
            "sentiment": sentiment,
            "timestamp": datetime.utcnow().isoformat()
        }

    def store_insight(self, log, result):
        entry = {
            "agent": "Observer",
            "input": log,
            "result": result,
            "timestamp": datetime.utcnow().isoformat()
        }
        store_data("observer_behavior_log", entry)
        log_event("Observer stored reflection insight", entry)
