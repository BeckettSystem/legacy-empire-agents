"""
Observer Enhancement – Reflection Logger
Logs interpretive observations, missed feedback loops, or pattern insights.
"""

import json, os
from datetime import datetime

REFLECT_PATH = os.path.join(os.path.dirname(__file__), "../../rituals/reflections/observer_reflection.json")

def reflect_insight(message):
    log = []
    os.makedirs(os.path.dirname(REFLECT_PATH), exist_ok=True)
    if os.path.exists(REFLECT_PATH):
        with open(REFLECT_PATH, "r") as f:
            log = json.load(f)
    log.append({"timestamp": datetime.utcnow().isoformat(), "insight": message})
    with open(REFLECT_PATH, "w") as f:
        json.dump(log, f, indent=2)
    return "🧠 Observer reflection recorded."
