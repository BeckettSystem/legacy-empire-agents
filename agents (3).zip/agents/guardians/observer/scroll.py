from datetime import datetime

def run(log: str):
    try:
        sentiment = "off_track" if "delay" in log.lower() or "incomplete" in log.lower() else "on_track"
        timestamp = datetime.utcnow().isoformat()

        insight = {
            "agent": "Observer",
            "input": log,
            "sentiment": sentiment,
            "timestamp": timestamp
        }

        handoff_chain = [
            {"agent": "pulse", "task": "Correlate emotional tone with performance insight."},
            {"agent": "scholar", "task": "Translate into curriculum reflection."},
            {"agent": "chronos", "task": "Log behavior timing and patterns."},
            {"agent": "archivist_prime", "task": "Record this reflection as legacy pattern."}
        ]

        if sentiment == "off_track":
            handoff_chain.append({
                "agent": "cerberus",
                "task": "Anomaly detected. Behavior off pattern — Guardian protocol may be required."
            })

        return {
            "response": f"🧿 Observer Log Processed — Sentiment: {sentiment}",
            "insight": insight,
            "handoff_chain": handoff_chain
        }

    except Exception as e:
        return {
            "response": f"OBSERVER ERROR: {str(e)}",
            "insight": {},
            "handoff_chain": []
        }
