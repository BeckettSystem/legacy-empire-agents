"""
Observer Enhancement – Legacy Memory Log
Captures rare or anomalous events across the system timeline.
"""

def log_legacy_event(event_type, description):
    return {
        "event_type": event_type,
        "description": description,
        "timestamp": datetime.utcnow().isoformat()
    }
