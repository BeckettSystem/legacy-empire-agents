
from utils.redis_handler import store_data
from datetime import datetime

def vault_scroll(insight, summary_note):
    scroll = {
        "from": "Observer",
        "category": "Monthly Reflection",
        "summary": summary_note,
        "insight": insight,
        "timestamp": datetime.utcnow().isoformat()
    }

    store_data("patriarch_scroll_archive", scroll)
    store_data("observer_scrolls", scroll)
    return {"message": "Scroll vaulted successfully", "scroll": scroll}
