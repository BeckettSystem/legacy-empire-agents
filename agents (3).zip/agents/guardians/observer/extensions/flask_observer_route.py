
# flask_observer_route.py
from flask import Blueprint, request, jsonify
from utils.redis_handler import store_data
from datetime import datetime

observer_bp = Blueprint('observer_bp', __name__)

@observer_bp.route('/submit_behavior_log', methods=['POST'])
def submit_behavior_log():
    data = request.json
    log_entry = data.get("log")
    if not log_entry:
        return jsonify({"error": "Missing 'log' field"}), 400

    record = {
        "log": log_entry,
        "timestamp": datetime.utcnow().isoformat(),
        "agent": "Observer"
    }
    store_data("observer_behavior_log", record)
    return jsonify({"message": "Behavior log submitted to Observer", "entry": record}), 200
