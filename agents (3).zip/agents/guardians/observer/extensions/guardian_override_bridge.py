def authorize_override(requester):
    if requester in ["Valor", "Patriarch"]:
        return "🔓 Override approved – failsafe reset"
    return "❌ Override denied – unauthorized entity"
