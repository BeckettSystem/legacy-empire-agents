
from utils.redis_handler import get_recent_data, store_data
from datetime import datetime, timedelta

def detect_pattern_drift(current_insight):
    try:
        recent_entries = get_recent_data("observer_behavior_log", days=30)
        off_track_count = sum(1 for entry in recent_entries if entry.get("result", {}).get("sentiment") == "off_track")
        ratio = off_track_count / max(len(recent_entries), 1)

        drift_detected = ratio > 0.3  # Adjust threshold as needed
        if drift_detected:
            drift_report = {
                "agent": "Observer",
                "type": "pattern_drift_warning",
                "details": {
                    "off_track_ratio": ratio,
                    "threshold": 0.3,
                    "timestamp": datetime.utcnow().isoformat()
                }
            }
            store_data("cerberus_protocol_queue", drift_report)
            return drift_report
        return {"message": "No pattern drift detected."}

    except Exception as e:
        return {"error": str(e)}
