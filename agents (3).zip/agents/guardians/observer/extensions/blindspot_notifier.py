"""
Observer Enhancement – Blind Spot Notifier
Detects agents that have not responded, activated, or logged output recently.
"""

def detect_silence(agent_activity_log):
    silent = [a for a, log in agent_activity_log.items() if log.get("last_action", 0) > 48]
    return f"🚨 Blind Spots: {', '.join(silent)}" if silent else "✅ No blind spots detected"
