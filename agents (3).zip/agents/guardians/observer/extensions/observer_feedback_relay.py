
# observer_feedback_relay.py
from utils.redis_handler import store_data
from datetime import datetime

def send_reflection_to_scholar(insight):
    payload = {
        "from": "Observer",
        "to": "Scholar",
        "type": "behavioral_reflection",
        "payload": insight,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("scholar_reflection_feed", payload)
    return payload

def send_to_pulse(insight):
    payload = {
        "from": "Observer",
        "to": "Pulse",
        "type": "emotional_correlation",
        "payload": insight,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("pulse_sync_feed", payload)
    return payload

def alert_cerberus_if_critical(insight):
    if insight.get("sentiment") == "off_track":
        payload = {
            "from": "Observer",
            "to": "Cerberus",
            "type": "behavior_anomaly",
            "payload": insight,
            "timestamp": datetime.utcnow().isoformat()
        }
        store_data("cerberus_protocol_queue", payload)
        return payload
    return None
