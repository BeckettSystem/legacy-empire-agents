def validate_condition(reason, initiator):
    if reason in ["breach", "rogue", "infiltration"]:
        return f"⚠️ LOCKDOWN VALIDATED by Fortress (initiated by {initiator})"
    return "✅ No lockdown necessary"
