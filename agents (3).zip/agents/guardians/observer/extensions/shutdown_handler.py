def execute_shutdown(affected_zones):
    return f"🔒 Scrolls in zones {', '.join(affected_zones)} locked down by Fortress"
