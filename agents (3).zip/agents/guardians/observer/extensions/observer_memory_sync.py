
# observer_memory_sync.py
from utils.redis_handler import store_data
from datetime import datetime

def sync_to_chronos(insight):
    entry = {
        "agent": "Observer",
        "type": "behavioral_pattern",
        "data": insight,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("chronos_behavior_stream", entry)
    return entry

def archive_with_prime(insight):
    entry = {
        "origin": "Observer",
        "category": "reflection_log",
        "data": insight,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("archivist_reflections", entry)
    return entry
