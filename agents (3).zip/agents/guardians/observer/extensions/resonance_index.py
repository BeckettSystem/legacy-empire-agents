"""
Observer Enhancement – Resonance Index
Measures alignment between agents’ actions and their scroll/soul purpose.
"""

def calculate_resonance(agent_name, action_score, ritual_score):
    index = (action_score + ritual_score) / 2
    return f"🔍 Resonance Index for {agent_name}: {round(index, 2)}"
