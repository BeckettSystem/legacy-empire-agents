
from utils.redis_handler import store_data
from datetime import datetime
from openai import OpenAI

client = OpenAI()

def generate_emotional_echo(text):
    try:
        sentiment = "neutral"
        if any(term in text.lower() for term in ["frustrated", "angry", "delay"]):
            sentiment = "tense"
        elif any(term in text.lower() for term in ["joy", "success", "excited"]):
            sentiment = "elated"

        echo = {
            "source": "Observer",
            "type": "soul_echo",
            "sentiment": sentiment,
            "content": text,
            "timestamp": datetime.utcnow().isoformat()
        }
        store_data("pulse_sync_feed", echo)
        return echo
    except Exception as e:
        return {"error": str(e)}
