def scan_system(integrity_map):
    failures = [k for k, v in integrity_map.items() if not v]
    if failures:
        return f"🛑 Integrity Breach: {', '.join(failures)}"
    return "✅ System integrity confirmed"
