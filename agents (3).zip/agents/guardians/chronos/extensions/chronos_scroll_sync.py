
# chronos_scroll_sync.py
from utils.redis_handler import store_data
from datetime import datetime

def build_scroll_entry(event_log):
    scroll_entry = {
        "origin": "Chronos",
        "scroll_type": "timeline_entry",
        "content": event_log,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("patriarch_scroll_log", scroll_entry)
    return scroll_entry
