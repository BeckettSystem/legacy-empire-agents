"""
Chronos Enhancement – Drift Detector
Detects if agents or system have become idle, delayed, or desynchronized.
"""

def detect_drift(agent_logs):
    if not agent_logs:
        return "❌ No agent logs available – possible desync."
    recent = [log for log in agent_logs if log.get("last_active") < 10]
    if len(recent) < len(agent_logs) // 2:
        return "⚠️ Drift Detected: Majority of agents out of sync."
    return "✅ System rhythm stable."
