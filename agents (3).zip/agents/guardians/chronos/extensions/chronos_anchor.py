
# chronos_anchor.py
from datetime import datetime

def anchor_event(agent, context):
    anchor_id = f"{agent}-{datetime.utcnow().isoformat()}"
    return {
        "agent": agent,
        "context": context,
        "anchor_id": anchor_id,
        "timestamp": datetime.utcnow().isoformat()
    }
