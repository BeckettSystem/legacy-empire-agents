"""
Chronos Enhancement – Campaign Surge Trigger
Notifies Apollo when system activity is low and momentum is needed.
"""

def recommend_surge(active_events, past_48h):
    if active_events < 3 and past_48h < 10:
        return "⚡ Surge Recommended – Apollo triggered for momentum reset."
    return "📊 Activity normal – no surge needed."
