
# chronos_filters.py
from utils.redis_handler import fetch_data
from datetime import datetime, timedelta

def filter_by_days_back(logs, days):
    threshold = datetime.utcnow() - timedelta(days=days)
    return [log for log in logs if datetime.fromisoformat(log.get("timestamp", "")) >= threshold]

def filter_by_agent(logs, agent_name):
    return [log for log in logs if log.get("agent") == agent_name]
