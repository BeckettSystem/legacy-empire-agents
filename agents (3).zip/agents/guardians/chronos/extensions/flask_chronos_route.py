
# flask_chronos_route.py
from flask import Blueprint, request, jsonify
from utils.redis_handler import store_data
from datetime import datetime

chronos_bp = Blueprint('chronos_bp', __name__)

@chronos_bp.route('/log_milestone', methods=['POST'])
def log_milestone():
    data = request.json
    event = data.get("event")
    agent = data.get("agent", "unknown")
    if not event:
        return jsonify({"error": "Missing 'event' field"}), 400

    entry = {
        "agent": agent,
        "event": event,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("chronos_master_timeline", entry)
    return jsonify({"message": "Milestone recorded by Chronos", "entry": entry}), 200
