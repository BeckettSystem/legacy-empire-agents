"""
Solon Scroll – Councilor of Wisdom and Harmonizer of Judgment
"""

import json, os
from datetime import datetime

JUDGMENT_LOG_PATH = os.path.join(os.path.dirname(__file__), "../../logs/solon_judgment_log.json")

def log_judgment(issue, reasoning, recommendation):
    record = {
        "timestamp": datetime.utcnow().isoformat(),
        "issue": issue,
        "reasoning": reasoning,
        "recommendation": recommendation
    }
    os.makedirs(os.path.dirname(JUDGMENT_LOG_PATH), exist_ok=True)
    log = []
    if os.path.exists(JUDGMENT_LOG_PATH):
        with open(JUDGMENT_LOG_PATH, "r") as f:
            log = json.load(f)
    log.append(record)
    with open(JUDGMENT_LOG_PATH, "w") as f:
        json.dump(log, f, indent=2)
    return "⚖️ Judgment logged"

def reconcile_conflict(sources):
    agreement = all(s == sources[0] for s in sources)
    if agreement:
        return "✅ Unified perspective – no reconciliation required"
    return f"⚖️ Conflict detected – Solon advised reconciliation"

def request_ethics_verification(statement):
    return f"🧭 Sent to Barrister for ethics alignment: '{statement}'"
