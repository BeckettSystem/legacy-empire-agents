"""
Solon Enhancement – Judgment Reflection
Stores reasons, philosophical notes, and ethical impressions from advisory cycles.
"""

import json, os
from datetime import datetime

LOG_PATH = os.path.join(os.path.dirname(__file__), "../../reflections/solon_reflection.json")

def reflect(reasoning, insight):
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    log = []
    if os.path.exists(LOG_PATH):
        with open(LOG_PATH, "r") as f:
            log = json.load(f)
    log.append({"timestamp": datetime.utcnow().isoformat(), "reasoning": reasoning, "insight": insight})
    with open(LOG_PATH, "w") as f:
        json.dump(log, f, indent=2)
    return "📘 Solon reflection saved"
