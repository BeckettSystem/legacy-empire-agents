"""
Solon Enhancement – System Mediator
Bridges disagreement or conflicting signals between Oracle, Barrister, and Observer.
"""

def mediate_signals(oracle_path, barrister_stance, observer_echo):
    if len(set([oracle_path, barrister_stance, observer_echo])) == 1:
        return "🧩 Consensus detected"
    return "⚖️ Disagreement flagged – Solon recommends further counsel"
