"""
Solon Enhancement – Ledger Bridge
Reads financial position to advise on expansion, risk, or resource policy.
"""

def advise_from_ledger(balance, commitments):
    free_cap = balance - sum(commitments)
    if free_cap < 10000:
        return "⚠️ Ledger constraint: Delay initiative"
    return "✅ Financial posture clear – safe to proceed"
