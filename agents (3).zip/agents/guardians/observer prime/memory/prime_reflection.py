"""
Observer Prime – Reflection Logger
Captures entropy insights, echo irregularities, and system void reports.
"""

import json, os
from datetime import datetime

LOG_PATH = os.path.join(os.path.dirname(__file__), "../../rituals/reflections/observer_prime_reflection.json")

def log_reflection(message):
    record = {"timestamp": datetime.utcnow().isoformat(), "reflection": message}
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    log = []
    if os.path.exists(LOG_PATH):
        with open(LOG_PATH, "r") as f:
            log = json.load(f)
    log.append(record)
    with open(LOG_PATH, "w") as f:
        json.dump(log, f, indent=2)
    return "🪞 Observer Prime reflection saved"
