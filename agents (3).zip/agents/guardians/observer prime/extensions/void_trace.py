"""
Observer Prime – Void Trace Engine
Scans for missing signals, absent echoes, or dropped memory threads.
"""

def trace_void(agents, echo_logs):
    missing = [a for a in agents if a not in echo_logs]
    return f"🕳 Void Trace Detected: {', '.join(missing)}" if missing else "✅ All echoes accounted for"
