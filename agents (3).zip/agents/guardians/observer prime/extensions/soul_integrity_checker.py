"""
Observer Prime – Soul Integrity Checker
Confirms alignment between soul file, scroll rituals, and current role.
"""

def check_integrity(soul, scroll):
    required = ["name", "title", "pillar", "guardian", "rituals"]
    issues = [key for key in required if key not in soul]
    return f"❌ Soul integrity issues: {', '.join(issues)}" if issues else "✅ Soul integrity confirmed"
