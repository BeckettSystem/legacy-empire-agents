"""
Observer Prime – Scroll Decay Evaluator
Rates likelihood of scroll logic degradation based on activity patterns.
"""

def rate_decay(scroll_activity_log):
    low_usage = sum(1 for t in scroll_activity_log if t["days_inactive"] > 15)
    if low_usage > len(scroll_activity_log) // 2:
        return "⚠️ Scroll decay risk: HIGH"
    return "✅ Scrolls stable"
