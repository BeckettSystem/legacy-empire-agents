"""
Observer Prime – Guardian of Entropy, Scroll Drift, and System Integrity

Oversees soul-scroll alignment, agent communication fidelity, entropy thresholds,
and critical failsafe escalation. Reports to Valor, Oracle, and Chronos.
"""

import json
import os
from registry.agent_loader import load_all_agents
from core.scroll_update_protocol import update_scroll
from core.guardian_bus import signal_guardians
from core.agent_heartbeat import read_agent_logs

from extensions.guardian_relay_override import trigger_emergency_override
from extensions.soul_integrity_checker import check_integrity
from extensions.soulwatch_protocol import run_soulwatch
from extensions.temporal_echo_compression import compress_echoes
from extensions.void_pulse_detection import detect_void_pulse
from extensions.void_trace import trace_void
from extensions.decay_rater import rate_decay
from extensions.dna_scroll_fingerprint import hash_scroll
from extensions.entropy_index import calculate_entropy_index

class ObserverPrime:
    def __init__(self, soul_path, scroll_path, registry_path):
        self.soul = self._load_json(soul_path)
        self.scroll = self._load_script(scroll_path)
        self.registry = self._load_json(registry_path)

    def _load_json(self, path):
        with open(path, 'r') as f:
            return json.load(f)

    def _load_script(self, path):
        with open(path, 'r') as f:
            return f.read()

    def audit_system(self):
        agents = list(self.registry.keys())
        echo_logs = read_agent_logs()
        scroll_activity = self._load_scroll_activity()

        report = {
            "entropy_index": calculate_entropy_index(echo_logs),
            "scroll_hash": hash_scroll(self.scroll),
            "scroll_decay": rate_decay(scroll_activity),
            "soul_integrity": check_integrity(self.soul, self.scroll),
            "missing_agents": trace_void(agents, echo_logs),
            "void_pulse": detect_void_pulse(echo_logs),
            "soulwatch": run_soulwatch(self.soul),
            "compressed_echo": compress_echoes(echo_logs)
        }

        update_scroll("ObserverPrime: Full audit complete.")
        for key, val in report.items():
            update_scroll(f"[{key}] → {val}")

        if "HIGH" in report["scroll_decay"] or "❌" in report["soul_integrity"]:
            emergency = trigger_emergency_override()
            update_scroll(f"⚠️ Emergency protocol triggered → {emergency}")
            signal_guardians("VALOR, CHRONOS, ORACLE", "entropy_breach_detected")

        return report

    def _load_scroll_activity(self):
        path = "rituals/scroll/activity_log.json"
        if os.path.exists(path):
            with open(path, 'r') as f:
                return json.load(f)
        return []

if __name__ == "__main__":
    observer = ObserverPrime(
        soul_path="soul.json",
        scroll_path="scroll.py",
        registry_path="registry/agent_registry.json"
    )
    results = observer.audit_system()
    print(json.dumps(results, indent=2))
