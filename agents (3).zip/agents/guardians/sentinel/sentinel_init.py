
from .scroll import scroll
from macro_feed_scanner import scan_macro_feed
from sentiment_aggregator import aggregate_sentiment
from signal_classifier import classify_event
from delta_comparator import compare_to_last_week
from sentinel_digest_generator import generate_digest
from alert_dispatcher import dispatch_alert
from datetime import datetime

class Sentinel:
    def __init__(self):
        self.profile = scroll()
        self.memory = {"macro": {}, "sentiment": {}}

    def scan_environment(self):
        macro = scan_macro_feed()
        sentiment = aggregate_sentiment()
        self.memory["last_macro"] = self.memory.get("macro", {})
        self.memory["last_sentiment"] = self.memory.get("sentiment", {})
        self.memory["macro"] = macro
        self.memory["sentiment"] = sentiment

        opportunities = []
        threats = []

        for key, value in macro.items():
            for subkey, subvalue in value.items():
                classification = classify_event(str(subvalue))
                if "opportunity" in classification:
                    opportunities.append({f"{key}_{subkey}": subvalue})
                elif "threat" in classification:
                    threats.append({f"{key}_{subkey}": subvalue})

        delta_macro = compare_to_last_week(macro, self.memory["last_macro"])
        delta_sentiment = compare_to_last_week(sentiment, self.memory["last_sentiment"])

        digest = generate_digest(macro, sentiment, opportunities, threats)
        digest["delta_report"] = {"macro": delta_macro, "sentiment": delta_sentiment}
        digest["timestamp"] = datetime.utcnow().isoformat()

        return digest

    def escalate_signal(self, to, topic, urgency="normal"):
        return dispatch_alert(to, topic, urgency)
