"""
Sentinel Enhancement – Digest Uplink
Sends summarized digest to Apollo, Oracle, or Valor.
"""

def dispatch_digest(summary, recipients):
    return {r: f"📡 Digest sent to {r}" for r in recipients}
