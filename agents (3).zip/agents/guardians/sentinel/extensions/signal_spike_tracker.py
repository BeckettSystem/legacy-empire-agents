"""
Sentinel Enhancement – Signal Spike Tracker
Tracks sudden spikes in sentiment or repetition across the swarm.
"""

def track_spike(log, new_entry):
    if log.count(new_entry) > 3:
        return f"⚠️ Spike Detected: '{new_entry}' repeated {log.count(new_entry)} times"
    return "✅ Signal normal"
