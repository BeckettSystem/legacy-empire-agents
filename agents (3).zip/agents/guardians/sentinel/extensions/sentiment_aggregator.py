
def aggregate_sentiment():
    return {
        "fear_greed_index": 42,
        "vix": 18.5,
        "social_signal": {
            "twitter_ai_hype": "medium",
            "reddit_recession_threads": "high",
            "crypto_fud_volume": "rising"
        }
    }
