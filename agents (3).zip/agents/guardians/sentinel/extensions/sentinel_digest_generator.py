
def generate_digest(macro_data, sentiment_data, opportunities, threats):
    return {
        "header": "🛰️ Sentinel Weekly Brief",
        "macro": macro_data,
        "sentiment": sentiment_data,
        "top_opportunities": opportunities[:3],
        "top_threats": threats[:3],
        "summary": f"{len(opportunities)} opportunities and {len(threats)} risks identified."
    }
