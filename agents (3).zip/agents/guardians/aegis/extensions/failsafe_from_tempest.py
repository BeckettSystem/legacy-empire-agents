"""
Aegis Enhancement – Tempest Crisis Bridge
Listens for Tempest alerts and invokes Aegis shield if emotional collapse is detected.
"""

def from_tempest(signal):
    if "crisis" in signal or "emotional collapse" in signal.lower():
        return "🧱 Tempest crisis detected. Aegis has locked system protocols."
    return "🌀 Tempest status stable."
