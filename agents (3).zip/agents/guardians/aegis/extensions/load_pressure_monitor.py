"""
Aegis Enhancement – Load + Pressure Monitor
Detects if system agent load is unsustainable and routes alert to Aegis.
"""

def check_pressure(active_agents, cpu_load, memory_free):
    if active_agents > 40 or cpu_load > 85 or memory_free < 300:
        return "⚠️ Pressure breach detected. Aegis activation recommended."
    return "✅ System load acceptable."
