"""
Aegis Enhancement – Mirror Reflection Protocol
Logs key reflections or reactions tied to Aegis engagements.
"""

import json, os
from datetime import datetime

LOG_PATH = os.path.join(os.path.dirname(__file__), "../../rituals/reflections/aegis_mirror.json")

def reflect(entry):
    record = {"timestamp": datetime.utcnow().isoformat(), "reflection": entry}
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    log = []
    if os.path.exists(LOG_PATH):
        with open(LOG_PATH, "r") as f:
            log = json.load(f)
    log.append(record)
    with open(LOG_PATH, "w") as f:
        json.dump(log, f, indent=2)
    return "🪞 Reflection Logged."
