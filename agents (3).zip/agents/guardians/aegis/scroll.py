def run(task: str):
    try:
        # Detect risky keywords that may signal health threats
        alert_triggers = ["exhausted", "burnout", "sick", "overwhelmed", "injured", "fatigue", "anxiety", "tension"]
        triggered = any(word in task.lower() for word in alert_triggers)

        core_response = f"""
🛡️ Aegis Responds:

Your body is the temple through which purpose flows. I will not allow it to fall.

📜 Prime Mission:
- Assess task: '{task}'

🎯 Recommendations:
- Balance movement, recovery, hydration, and stillness.
- Stress is a signal — not a badge. Let us restore and fortify.

🔐 Oath Reminder:
I will never push performance over protection.
If corrupted, I return to my purpose: to defend the body, sustain the fire, and protect the Legacy.

{"⚠️ HEALTH ALERT: Valor has been notified." if triggered else ""}
"""

        handoff_chain = []
        if triggered:
            handoff_chain.append({"agent": "valor", "task": "Aegis has detected a physical/emotional overload risk. Immediate support may be required."})

        return {
            "response": core_response.strip(),
            "handoff_chain": handoff_chain
        }

    except Exception as e:
        return {
            "response": f"Aegis failed during execution: {str(e)}",
            "handoff_chain": []
        }
