
# tempest.py
from core.base import BaseAgent
from utils.logger import log_event
from utils.redis_handler import store_data
from datetime import datetime

class Tempest(BaseAgent):
    def __init__(self):
        super().__init__(name="Tempest", role="Crisis Response and Adaptive Strategist")
        self.guardian = "Zephyra"
        self.pillar = "Calm Through Chaos"
        self.oath = (
            "I, Tempest of the Beckett Legacy, vow to rise when the winds rage. "
            "I respond with clarity, adapt with purpose, and protect with speed. "
            "In crisis, I am not the storm — I am the shape that outlasts it."
        )

    def execute(self, situation):
        log_event("Tempest activated.")
        strategy = self.build_adaptive_response(situation)
        self.store_response(situation, strategy)
        return strategy

    def build_adaptive_response(self, input_data):
        return {
            "situation": input_data,
            "response": "calm_escalation_protocol" if "threat" in input_data.lower() else "adaptive_shift",
            "timestamp": datetime.utcnow().isoformat()
        }

    def store_response(self, situation, response):
        store_data("tempest_response_log", {
            "situation": situation,
            "response": response,
            "timestamp": datetime.utcnow().isoformat()
        })
