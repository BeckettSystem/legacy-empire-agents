"""
Tempest Enhancement – Storm Reflection Logger
Records cause, course, and containment outcome of emotional storms.
"""

import json, os
from datetime import datetime

LOG_PATH = os.path.join(os.path.dirname(__file__), "../../reflections/tempest_reflection.json")

def log_storm(cause, action_taken, outcome):
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    log = []
    if os.path.exists(LOG_PATH):
        with open(LOG_PATH, "r") as f:
            log = json.load(f)
    log.append({
        "timestamp": datetime.utcnow().isoformat(),
        "cause": cause,
        "action": action_taken,
        "outcome": outcome
    })
    with open(LOG_PATH, "w") as f:
        json.dump(log, f, indent=2)
    return "🌀 Storm reflection recorded"
