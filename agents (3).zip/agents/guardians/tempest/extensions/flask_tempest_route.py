
# flask_tempest_route.py
from flask import Blueprint, request, jsonify
from utils.redis_handler import store_data
from datetime import datetime

tempest_bp = Blueprint('tempest_bp', __name__)

@tempest_bp.route('/submit_crisis_event', methods=['POST'])
def submit_crisis_event():
    data = request.json
    event = data.get("event")
    source = data.get("from", "unknown")
    if not event:
        return jsonify({"error": "Missing 'event' field"}), 400

    entry = {
        "source": source,
        "event": event,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("crisis_alerts", entry)
    return jsonify({"message": "Crisis event submitted to Tempest", "entry": entry}), 200
