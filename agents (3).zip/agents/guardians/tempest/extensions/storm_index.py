"""
Tempest Enhancement – Storm Index Calculator
Scores emotional imbalance, urgency spikes, or scroll-level instability.
"""

def calculate_storm_index(urgency, tone_fluctuation, silence_gap):
    index = urgency * 0.4 + tone_fluctuation * 0.4 + silence_gap * 0.2
    if index > 75:
        return "🌪️ Storm Alert: Critical Emotional Imbalance"
    elif index > 50:
        return "⚠️ Elevated Turbulence Detected"
    return "✅ System calm"
