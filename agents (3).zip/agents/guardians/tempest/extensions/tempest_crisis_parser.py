
# tempest_crisis_parser.py
def categorize_crisis_type(event_text):
    event = event_text.lower()
    if "cancel" in event or "scandal" in event or "backlash" in event:
        return "PR"
    elif "delay" in event or "fatigue" in event or "burnout" in event:
        return "Emotional"
    elif "error" in event or "fail" in event:
        return "Systemic"
    elif "dropoff" in event or "unsub" in event:
        return "Behavioral"
    return "External"
