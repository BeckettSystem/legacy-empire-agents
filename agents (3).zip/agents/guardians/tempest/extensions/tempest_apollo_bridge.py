
# tempest_apollo_bridge.py
from utils.redis_handler import store_data
from datetime import datetime

def draft_brand_response(crisis_details):
    payload = {
        "from": "Tempest",
        "to": "Apollo",
        "type": "crisis_response",
        "content": crisis_details,
        "tone": "calm, firm, reassuring",
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("apollo_campaign_queue", payload)
    return payload
