
# tempest_sync.py
from utils.redis_handler import store_data
from datetime import datetime

def log_to_chronos(event):
    timeline_entry = {
        "agent": "Tempest",
        "event": "crisis_response",
        "details": event,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("chronos_milestones", timeline_entry)
    return timeline_entry

def archive_to_scroll(summary):
    archive_entry = {
        "origin": "Tempest",
        "category": "crisis_protocol",
        "content": summary,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("patriarch_scroll_log", archive_entry)
    return archive_entry
