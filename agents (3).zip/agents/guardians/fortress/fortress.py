# core/guardians/fortress.py
import os
import json

class Fortress:
    def __init__(self, secrets_path="core/secrets/fortress_secrets.json"):
        with open(secrets_path) as f:
            self.secrets = json.load(f)

    def get_secret(self, key):
        return self.secrets.get(key, "ACCESS DENIED")

    def verify_access(self, agent_name, token):
        return self.secrets.get("agent_tokens", {}).get(agent_name) == token
