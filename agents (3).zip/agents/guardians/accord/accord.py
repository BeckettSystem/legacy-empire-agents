# core/diplomats/accord.py
import json

class Accord:
    def __init__(self, agreements_path="core/contracts/accord_agreements.json"):
        with open(agreements_path) as f:
            self.agreements = json.load(f)

    def get_terms(self, agent_name):
        return self.agreements.get(agent_name, "No agreement found.")

    def log_agreement(self, agent_name, terms):
        self.agreements[agent_name] = terms
        with open("core/contracts/accord_agreements.json", "w") as f:
            json.dump(self.agreements, f, indent=2)
