"""
Ledger Enhancement – Treasury Report Generator
Produces summary of balances, recent inflow/outflow, and notes for Tycoon and Merchant.
"""
def generate_report(transactions):
    total = sum(t["amount"] for t in transactions)
    return f"📊 Treasury Report: Current float = ${total}"
