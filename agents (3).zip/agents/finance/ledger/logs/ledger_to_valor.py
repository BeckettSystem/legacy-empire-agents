"""
Escalation Hook – Ledger to Valor
If a flagged transaction exceeds $100,000, notify Valor.
"""

def escalate_transaction(amount):
    if amount >= 100000:
        return "⚔️ Valor Alert: Transaction threshold exceeded."
    return "✅ Transaction within acceptable bounds."
