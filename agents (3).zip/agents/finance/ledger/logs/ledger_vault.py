# core/extensions/ledger_vault.py
import json
from datetime import datetime

def log_deployment(entry_type, content):
    record = {
        "timestamp": str(datetime.utcnow()),
        "entry_type": entry_type,
        "content": content
    }
    try:
        with open("core/logs/ledger_vault.json", "a") as f:
            f.write(json.dumps(record) + "\n")
    except Exception as e:
        print(f"Vault log error: {str(e)}")
