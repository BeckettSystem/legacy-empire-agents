# core/scrolls/scroll_ledger.py
from core.agents.finance.ledger_agent import run_ledger
from core.extensions.ledger_terms import generate_terms
from core.extensions.ledger_score import evaluate_proposal
from core.extensions.ledger_vault import log_deployment

def capital_plan(prompt):
    result = run_ledger(prompt)
    log_deployment("capital_plan", result)
    return result

def evaluate_opportunity(summary):
    return evaluate_proposal(summary)

def generate_lending_terms(applicant_profile):
    return generate_terms(applicant_profile)
