"""
Ledger Enhancement – Float Estimator
Estimates liquid capital available for short-term use.
"""
def estimate_float(balance, commitments):
    return max(balance - sum(commitments), 0)
