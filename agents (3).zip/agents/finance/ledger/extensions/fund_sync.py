"""
Ledger Enhancement – Capital Sync
Syncs current funds with Merchant and Tycoon.
"""
def sync_funds(balance):
    return {
        "merchant": balance * 0.6,
        "tycoon": balance * 0.4,
        "status": "synced"
    }
