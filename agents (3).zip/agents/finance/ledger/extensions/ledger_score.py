# core/extensions/ledger_score.py
def evaluate_proposal(summary):
    summary = summary.lower()
    score = 0
    if "housing" in summary or "community" in summary:
        score += 2
    if "modular" in summary or "scalable" in summary:
        score += 2
    if "return" in summary or "roi" in summary:
        score += 1
    if "risky" in summary or "unsecured" in summary:
        score -= 2
    return {"opportunity_score": score}
