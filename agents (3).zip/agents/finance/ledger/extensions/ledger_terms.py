# core/extensions/ledger_terms.py
def generate_terms(profile):
    base_rate = 8.5
    score = profile.get("credit_score", 650)
    amount = profile.get("requested_amount", 50000)
    term_months = 12 if score < 600 else 24 if score < 700 else 36
    interest = base_rate - 1 if score > 720 else base_rate + 1
    return {
        "approved_amount": amount,
        "term_length_months": term_months,
        "interest_rate": interest,
        "structure": "Installment Loan"
    }
