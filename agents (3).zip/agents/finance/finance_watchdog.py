"""
Finance Watchdog Agent – Silent Sensor
Monitors capital and compliance for Guardian trigger thresholds.
"""

def scan_financial_state(float_amt, compliance_flags):
    if compliance_flags > 2:
        return "🚨 Alert: Multiple compliance breaches. Escalate to Valor."
    if float_amt < 5000:
        return "⚠️ Treasury critically low. Signal Titan and Ledger."
    return "🛡️ Status: Stable"
