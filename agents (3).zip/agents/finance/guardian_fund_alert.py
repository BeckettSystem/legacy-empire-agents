"""
Finance-to-Guardian Sync – Fund Alert Protocol
Sends signal to Valor, Titan, or Helm if treasury conditions meet criteria.
"""

def alert_guardians(float_level, active_exposure):
    if float_level < 10000:
        return "⚠️ Low Float: Valor + Helm notified."
    if active_exposure > 500000:
        return "⚠️ Exposure High: Titan notified to adjust expansion logic."
    return "✅ Capital conditions within acceptable range."
