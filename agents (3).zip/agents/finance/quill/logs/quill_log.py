# core/extensions/quill_log.py
import json
from datetime import datetime

def log_advice(event_type, subject, result):
    entry = {
        "timestamp": str(datetime.utcnow()),
        "event": event_type,
        "subject": subject,
        "result": result
    }
    try:
        with open("core/logs/quill_log.json", "a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception as e:
        print(f"Quill log error: {str(e)}")
