# core/scrolls/scroll_quill.py
from core.agents.lending.quill_agent import run_quill
from core.extensions.quill_log import log_advice
from core.extensions.quill_profile import recommend_loans
from core.extensions.quill_ethics import check_risk

def compare_loans(profile_summary):
    result = run_quill(f"Compare loan options for: {profile_summary}")
    log_advice("loan_comparison", profile_summary, result)
    return result

def suggest_dpa(location="Georgia"):
    result = run_quill(f"List available Down Payment Assistance programs in {location}")
    log_advice("dpa_suggestion", location, result)
    return result

def recommend_paths(profile):
    return recommend_loans(profile)

def validate_ethics(statement):
    return check_risk(statement)
