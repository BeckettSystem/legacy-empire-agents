"""
Quill Enhancement – Ledger Cross-Check
Verifies entries across Ledger and internal Quill logs.
"""
def verify_entry(entry, ledger_entry):
    return "✅ Match confirmed" if entry == ledger_entry else "❌ Mismatch found"
