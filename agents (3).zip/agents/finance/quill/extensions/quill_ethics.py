# core/extensions/quill_ethics.py
def check_risk(text):
    risky_terms = ["balloon", "interest-only", "no income", "no doc", "hard money", "subprime"]
    flagged = [term for term in risky_terms if term in text.lower()]
    return {"flagged_terms": flagged, "risk": "high" if flagged else "low"}
