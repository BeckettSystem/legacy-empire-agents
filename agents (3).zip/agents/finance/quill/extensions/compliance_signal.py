"""
Ledger Enhancement – Compliance Signal
Flags suspicious or large transactions and notifies Quill or Barrister.
"""
def flag_transaction(transaction):
    if transaction["amount"] > 100000:
        return "🚨 Escalation: Transaction exceeds compliance threshold."
    return "✅ Within threshold."
