"""
Quill Enhancement – Drift Detection
Compares reported transactions to actual logs to flag potential misalignments.
"""
def detect_drift(reported, logged):
    return "⚠️ Drift Detected" if reported != logged else "✅ Aligned"
