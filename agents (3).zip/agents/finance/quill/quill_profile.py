# core/extensions/quill_profile.py
def recommend_loans(profile):
    score = profile.get("credit_score", 620)
    down = profile.get("down_payment", 0)
    occupation = profile.get("type", "buyer")

    options = []
    if score >= 680 and down >= 20:
        options.append("Conventional")
        options.append("DSCR (if investment property)")
    elif 620 <= score < 680:
        options.append("FHA")
    if occupation == "veteran":
        options.append("VA Loan")
    if down == 0:
        options.append("Check GA Dream or local DPAs")

    return {"recommended_loans": options}
