"""
Atlas Upgrade – Agent Auto-Registration
Watches /agents directory for new scroll.py files, registers agents to system_manifest.yaml.
"""