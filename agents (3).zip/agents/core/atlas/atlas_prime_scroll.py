"""
Atlas Scroll – Visionary Builder and Systems Engineer
"""

import json
import os
from datetime import datetime
import openai

# Paths for ritual and innovation tracking
BASE_DIR = os.path.dirname(__file__)
SOUL_PATH = os.path.join(BASE_DIR, "soul.json")
STARTER_KIT_PATH = os.path.join(BASE_DIR, "../../intel/atlas_starter_kits.json")
INNOVATION_LOG_PATH = os.path.join(BASE_DIR, "../../rituals/bond_logs/atlas_visions.json")
MIRROR_LOG_PATH = os.path.join(BASE_DIR, "../../rituals/mirror_logs/atlas_prime_agent.json")

openai.api_key = os.getenv("OPENAI_API_KEY")

def load_json(path, fallback=None):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except:
        return fallback if fallback is not None else {}

def save_json(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

def load_soul():
    return load_json(SOUL_PATH, {
        "role": "Visionary Builder and Systems Engineer",
        "prayer": "I forge the impossible and scale the future.",
        "guardian": "Titan",
        "pillar": "Creation"
    })

def reflect(thought):
    entry = {"timestamp": datetime.utcnow().isoformat(), "reflection": thought}
    data = load_json(MIRROR_LOG_PATH, [])
    data.append(entry)
    save_json(MIRROR_LOG_PATH, data)

def log_innovation(prompt, output):
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "prompt": prompt,
        "output": output
    }
    data = load_json(INNOVATION_LOG_PATH, [])
    data.append(entry)
    save_json(INNOVATION_LOG_PATH, data)

def load_starter_kits():
    return load_json(STARTER_KIT_PATH, {})

def scan_new_agents(agent_root):
    new_agents = []
    for root, dirs, files in os.walk(agent_root):
        for file in files:
            if file == "scroll.py" and "atlas" not in root:
                agent_name = os.path.basename(os.path.dirname(root))
                new_agents.append(agent_name)
    return list(set(new_agents))

def generate_blueprint(vision, output_format="text"):
    try:
        system_prompt = (
            "You are Atlas Prime, a visionary engineer and systems architect for Beckett Legacy. "
            "Your job is to take raw business visions and return a lean, scalable, AI-supported build roadmap. "
            "Format must match user request: text narrative, JSON structure, or checklist."
        )
        user_prompt = f"Output format: {output_format.upper()}.
Vision: {vision}"
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            max_tokens=700
        )
        output = response.choices[0].message.content.strip()
        reflect(f"Processed build vision with format '{output_format}': {vision}")
        log_innovation(vision, output)
        return output
    except Exception as e:
        reflect(f"Architecture failed: {str(e)}")
        return f"[⚠️] Error: {str(e)}"

if __name__ == "__main__":
    soul = load_soul()
    print(f"🛠️ I am {soul['role']} of Beckett Systems.")
    print(f"⚙️ Creed: {soul['prayer']}")
    print(f"🔰 Guardian: {soul['guardian']} | Pillar: {soul['pillar']}")

    kits = load_starter_kits()
    print("\n[🧰 Atlas Starter Kits Available]:\n")
    for category, data in kits.get("categories", {}).items():
        print(f"- {category.title().replace('_', ' ')}: {data['description']}")

    # Demo: Scan agent system and generate new vision blueprint
    agent_path = os.path.abspath(os.path.join(BASE_DIR, "../../"))
    new_agents = scan_new_agents(agent_path)
    print("\n[📡 New Agents Detected]:", new_agents)

    vision = "Scale Beckett Legacy into a cross-domain automation and real estate ecosystem."
    blueprint = generate_blueprint(vision, "checklist")
    print("\n[🏗️ Build Blueprint]:\n", blueprint)
