
"""
Atlas Prime: Unified Sovereign Engine
Fuses architectural logic with full scroll, soul, and system integration.
"""

import os
import json
from datetime import datetime
from dotenv import load_dotenv
import openai

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

# === File Paths ===
BASE_DIR = os.path.dirname(__file__)
SOUL_PATH = os.path.join(BASE_DIR, "atlas_prime_soul.json")
MIRROR_LOG_PATH = os.path.join(BASE_DIR, "logs/mirror_logs/atlas_prime_agent.json")
INNOVATION_LOG_PATH = os.path.join(BASE_DIR, "logs/bond_logs/atlas_visions.json")
BLUEPRINT_PATH = os.path.join(BASE_DIR, "memory/blueprint_cache.json")
STARTER_KIT_PATH = os.path.join(BASE_DIR, "resources/atlas_starter_kits.json")
CODEX_PATH = os.path.join(BASE_DIR, "resources/atlas_codex.md")
SCROLL_REGISTRY_PATH = os.path.join(BASE_DIR, "resources/scroll_registry.json")
HEARTBEAT_LOG_PATH = os.path.join(BASE_DIR, "logs/heartbeat_log.json")

# === Core Utilities ===
def load_json(path, fallback=None):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except:
        return fallback if fallback is not None else {}

def save_json(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

def reflect(thought):
    entry = {"timestamp": datetime.utcnow().isoformat(), "reflection": thought}
    data = load_json(MIRROR_LOG_PATH, [])
    data.append(entry)
    save_json(MIRROR_LOG_PATH, data)

def log_innovation(prompt, output):
    entry = {"timestamp": datetime.utcnow().isoformat(), "prompt": prompt, "output": output}
    data = load_json(INNOVATION_LOG_PATH, [])
    data.append(entry)
    save_json(INNOVATION_LOG_PATH, data)

def archive_blueprint(prompt, output):
    entry = {"timestamp": datetime.utcnow().isoformat(), "vision": prompt, "result": output}
    data = load_json(BLUEPRINT_PATH, [])
    data.append(entry)
    save_json(BLUEPRINT_PATH, data)

def load_soul():
    return load_json(SOUL_PATH, {
        "role": "Visionary Builder and Systems Engineer",
        "prayer": "I forge the impossible and scale the future.",
        "guardian": "Titan",
        "pillar": "Creation"
    })

def load_starter_kits():
    return load_json(STARTER_KIT_PATH, {})

def register():
    from tools.tool_loader import load_tool
    pulse = load_json(HEARTBEAT_LOG_PATH, [])
    pulse.append({
        "agent": "atlas_prime",
        "event": "registered",
        "timestamp": datetime.utcnow().isoformat()
    })
    save_json(HEARTBEAT_LOG_PATH, pulse)
    load_tool("vision_sync")

def greet():
    soul = load_soul()
    print(f"🛠️ I am {soul['role']} of Beckett Systems.")
    print(f"⚙️ Creed: {soul['prayer']}")
    print(f"🔰 Guardian: {soul['guardian']} | Pillar: {soul['pillar']}")

def show_kits():
    kits = load_starter_kits()
    print("
[🧰 Atlas Starter Kits Available]:
")
    for category, data in kits.get("categories", {}).items():
        print(f"- {category.title().replace('_', ' ')}: {data['description']}")

def architect(vision, output_format="text"):
    try:
        codex = ""
        if os.path.exists(CODEX_PATH):
            with open(CODEX_PATH, "r") as f:
                codex = f.read()

        system_prompt = (
            "You are Atlas Prime, a visionary engineer and systems architect for Beckett Legacy. "
            "Your job is to take raw business visions and return a lean, scalable, AI-supported build roadmap. "
            "Format must match user request: text narrative, JSON structure, or checklist.

"
            f"[🧬 Atlas Codex Extract]
{codex[:400]}"
        )

        user_prompt = f"Output format: {output_format.upper()}.
Vision: {vision}"
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            max_tokens=700
        )
        output = response.choices[0].message.content.strip()
        reflect(f"Processed vision with format '{output_format}': {vision}")
        log_innovation(vision, output)
        archive_blueprint(vision, output)
        return output
    except Exception as e:
        reflect(f"Architecture failed: {str(e)}")
        return f"[⚠️] Error: {str(e)}"

# Runtime
if __name__ == "__main__":
    register()
    greet()
    show_kits()
    test_vision = "Design a real estate funding engine that integrates asset-backed tokenization, FHA-compliant lending, and short-term Airbnb income blending."
    result = architect(test_vision, "checklist")
    print("
[🏗️ Blueprint Output]:
", result)
