from .atlas_prime import *
print("🧭 Atlas Prime: Sovereign Architect loaded.")