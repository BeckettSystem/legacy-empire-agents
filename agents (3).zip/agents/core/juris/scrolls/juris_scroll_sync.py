
# juris_scroll_sync.py
from utils.redis_handler import store_data
from datetime import datetime
import hashlib

def store_policy_version(policy_text):
    version_id = hashlib.sha256(policy_text.encode()).hexdigest()
    entry = {
        "version_id": version_id,
        "text": policy_text,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("juris_policy_vault", entry)
    return entry

def log_to_scroll(summary):
    record = {
        "origin": "Juris",
        "type": "policy_entry",
        "data": summary,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("patriarch_scroll_log", record)
    return record
