
# juris_clause_logic.py
from datetime import datetime

def categorize_clause(text):
    t = text.lower()
    if "termination" in t or "indemnify" in t:
        return "critical"
    elif "payment" in t or "duration" in t:
        return "standard"
    elif "exclusivity" in t or "non-compete" in t:
        return "strategic"
    else:
        return "general"

def flag_critical_risk(text):
    return any(term in text.lower() for term in ["termination", "indemnify", "arbitration", "unilateral", "non-disparagement"])

def score_clause_health(text):
    if flag_critical_risk(text):
        return "concerning"
    elif "mutual" in text.lower():
        return "favorable"
    else:
        return "neutral"
