
# juris_cross_review.py
from utils.redis_handler import store_data
from datetime import datetime

def review_partner_terms(text):
    flagged = "inconsistent" if "conflict" in text.lower() or "ambiguity" in text.lower() else "aligned"
    entry = {
        "from": "Juris",
        "to": "Pact",
        "status": flagged,
        "text": text,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("pact_clause_alignment", entry)
    return entry

def reference_diplomatic_conflict(text):
    entry = {
        "from": "Juris",
        "to": "Diplomat",
        "type": "policy_reference",
        "reference_text": text,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("diplomatic_policy_support", entry)
    return entry
