
# flask_juris_route.py
from flask import Blueprint, request, jsonify
from utils.redis_handler import store_data
from datetime import datetime

juris_bp = Blueprint('juris_bp', __name__)

@juris_bp.route('/submit_clause_review', methods=['POST'])
def submit_clause_review():
    data = request.json
    clause = data.get("clause")
    source = data.get("from", "unknown")
    if not clause:
        return jsonify({"error": "Missing 'clause' field"}), 400

    entry = {
        "source": source,
        "clause": clause,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("juris_review_queue", entry)
    return jsonify({"message": "Clause submitted to Juris", "entry": entry}), 200
