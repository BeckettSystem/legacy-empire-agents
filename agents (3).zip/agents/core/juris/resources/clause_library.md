# Clause Library

Includes standard clauses: indemnity, force majeure, non-disparagement, right of refusal, etc.