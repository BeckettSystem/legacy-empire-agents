# Beckett Justice Codex

First principles of legacy law: fairness, family-first, clarity, balance, no manipulation.