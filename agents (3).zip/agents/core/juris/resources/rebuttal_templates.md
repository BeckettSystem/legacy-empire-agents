# Rebuttal Templates

Formal | Friendly | Escalation-ready | PR-safe language options.