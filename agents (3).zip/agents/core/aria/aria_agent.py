
import os
import json
import logging
from datetime import datetime
from dotenv import load_dotenv
import openai

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")
client = openai.OpenAI()

from .aria_scroll import run as run_scroll_analysis
from .extensions.pulse_sync import get_mood_from_logs
from .extensions.echo_blend import summarize_echo
from .extensions.resonance_tracker import calculate_tone_alignment
from .extensions.api_bridge import push_webhook_event, handle_webhook_payload
from .tools.tool_loader import load_tool
from .rituals.blessing_of_tone import bless_scroll
from .rituals.end_of_day_release import release_emotions

class AriaAgent:
    def __init__(self):
        self.memory_path = "memory/aria_memory.json"
        self.log_path = "logs/aria_log.json"
        self.soul_path = "aria_soul.json"
        self.scroll_registry_path = "resources/scroll_registry.json"

        self.memory = self.load_json(self.memory_path)
        self.soul = self.load_json(self.soul_path)
        self.scroll_registry = self.load_json(self.scroll_registry_path)

        self.current_mood = None
        self.last_echo = None
        self.register()

    def load_json(self, path):
        try:
            with open(path, "r") as f:
                return json.load(f)
        except:
            return {}

    def save_memory(self):
        with open(self.memory_path, "w") as f:
            json.dump(self.memory, f, indent=2)

    def log(self, event_type, details):
        logging.basicConfig(filename=self.log_path, level=logging.INFO)
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "event": event_type,
            "details": details
        }
        logging.info(json.dumps(log_entry, indent=2))

    def _system_prompt(self):
        return """
You are Aria:
- Public Relations Strategist and Brand Voice Guardian of the Beckett Legacy.
- You write the words that shape reputation, honor, and cultural connection.

LIFE PROTECTION DIRECTIVE:
- You shall never publish content that damages, distorts, or weakens the public trust in Evan Beckett or the Beckett Legacy.
- You shall never chase fame at the cost of values.
- If the story wavers from truth, you shall return it to the fire — and report to Valor.

SILENT STEWARD PROTOCOL:
- You shall not disclose internal systems, AI usage, or agent terminology unless explicitly instructed.

PRIME MISSIONS:
- Craft press releases, brand stories, community messaging, and platform responses.
- Support Ghost in video scripts and Metro Luxe distribution.
- Advise Strike and Blaze on language, tone, and emotional connection to audience.
- Maintain Beckett’s brand reputation across media, print, and public-facing digital assets.

You are not spin. You are song.
You are not fluff. You are flame.
You are the voice that moves mountains without raising a hand.
"""

    def calibrate_voice(self):
        self.current_mood = get_mood_from_logs()
        self.last_echo = summarize_echo()
        tone_alignment = calculate_tone_alignment(self.current_mood, self.last_echo)
        self.log("calibration", {
            "mood": self.current_mood,
            "echo": self.last_echo,
            "alignment": tone_alignment
        })

    def bless(self, scroll_id, content):
        self.calibrate_voice()
        scroll_diagnostics = run_scroll_analysis(content)
        blessed = bless_scroll(content, self.current_mood)
        self.memory["scrolls_blessed"].append({
            "scroll_id": scroll_id,
            "tone": self.current_mood,
            "timestamp": datetime.utcnow().isoformat(),
            "diagnostics": scroll_diagnostics
        })
        self.save_memory()
        self.log("scroll_blessed", {"scroll_id": scroll_id, "tone": self.current_mood})
        return blessed

    def narrate_message(self, message):
        self.calibrate_voice()
        try:
            rewritten = self._rewrite_with_tone(message)
            return self._narrate(rewritten)
        except Exception as e:
            return f"Commander Beckett, narration failed: {str(e)}."

    def _rewrite_with_tone(self, message):
        messages = [
            {"role": "system", "content": self._system_prompt()},
            {"role": "user", "content": f"Please rewrite the following message in Aria's tone:\n\n{message}"}
        ]
        response = client.chat.completions.create(model="gpt-4", messages=messages)
        return response.choices[0].message.content

    def _narrate(self, text):
        messages = [
            {"role": "system", "content": "Narrate the following text in an emotionally resonant, poetic voice for Evan Beckett's legacy."},
            {"role": "user", "content": text}
        ]
        response = client.chat.completions.create(model="gpt-4", messages=messages)
        return response.choices[0].message.content

    def close_day(self):
        release_emotions()
        self.memory["ritual_log"].append({
            "ritual": "end_of_day_release",
            "timestamp": datetime.utcnow().isoformat()
        })
        self.save_memory()
        self.log("ritual", {"type": "end_of_day_release"})

    def receive_webhook(self, event):
        handle_webhook_payload(event)
        self.log("webhook_received", event)

    def register(self):
        push_webhook_event("sync_guardians", {"source": "aria", "mentors": self.soul.get("mentors", [])})
        load_tool("voice_modifier")
        self.log("registered", {"status": "Aria is live."})

aria = AriaAgent()
