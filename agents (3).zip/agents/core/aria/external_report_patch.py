from llm_expander import expand_threat_analysis
from webhook_dispatcher import send_webhook

def report_threat(summary, webhook_urls):
    try:
        expanded = expand_threat_analysis(summary)
        for label, url in webhook_urls.items():
            payload = {
                "source": "agent",
                "summary": summary,
                "expanded": expanded,
                "channel": label
            }
            send_webhook(payload, url)
        return "✅ Report dispatched"
    except Exception as e:
        return f"❌ Dispatch error: {str(e)}"
