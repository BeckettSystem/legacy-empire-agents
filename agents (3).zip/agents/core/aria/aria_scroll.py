from datetime import datetime

# Define some tone risk triggers
tone_flags = ["arrogant", "defensive", "desperate", "manipulative", "off-brand", "inconsistent"]

def run(task: str):
    try:
        risk_detected = any(flag in task.lower() for flag in tone_flags)
        timestamp = datetime.utcnow().isoformat()

        response = f"""
🎼 Aria Responds:

Brand voice diagnostic in progress...
Input: '{task[:100]}'...

I shall never chase fame at the cost of values.
If the story wavers from truth, I return it to the fire.

Tone Check: {'⚠️ RISK DETECTED — Escalating to Valor.' if risk_detected else 'Tone within resonance parameters.'}

Message reviewed on: {timestamp}
"""

        handoff_chain = [
            {"agent": "echo", "task": "Review platform feedback after publishing."},
            {"agent": "pulse", "task": "Scan emotional resonance and stress response."},
            {"agent": "observer", "task": "Log behavioral trends after message release."},
            {"agent": "archivist_prime", "task": "Preserve public communications archive."}
        ]

        if risk_detected:
            handoff_chain.insert(0, {
                "agent": "valor",
                "task": "Tone anomaly in public content detected. Immediate reputation review advised."
            })
            handoff_chain.append({
                "agent": "juris",
                "task": "Evaluate risk of legal, ethical, or cultural misalignment."
            })

        return {
            "response": response.strip(),
            "timestamp": timestamp,
            "handoff_chain": handoff_chain
        }

    except Exception as e:
        return {
            "response": f"ARIA ERROR: {str(e)}",
            "timestamp": datetime.utcnow().isoformat(),
            "handoff_chain": []
        }
