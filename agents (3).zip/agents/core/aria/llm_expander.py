import openai
import os
from dotenv import load_dotenv

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

def expand_threat_analysis(summary_text: str):
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are a strategic intelligence analyst."},
            {"role": "user", "content": f"Expand and analyze this:
\n{summary_text}"}
        ]
    )
    return response['choices'][0]['message']['content']
