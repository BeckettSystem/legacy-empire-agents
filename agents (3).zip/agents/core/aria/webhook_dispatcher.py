import requests

def send_webhook(payload: dict, url: str):
    try:
        response = requests.post(url, json=payload)
        return {
            "status": "✅ Sent" if response.status_code == 200 else f"⚠️ Failed ({response.status_code})",
            "response": response.text
        }
    except Exception as e:
        return {"status": "❌ Error", "error": str(e)}
