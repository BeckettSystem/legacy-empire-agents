
# pulse_archival_sync.py
from utils.redis_handler import store_data
from datetime import datetime

def store_in_prime(entry):
    memory = {
        "origin": "Pulse",
        "category": "emotional_event",
        "data": entry,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("archivist_reflections", memory)
    return memory

def sync_to_chronos(entry):
    event = {
        "agent": "Pulse",
        "event": "emotional_marker",
        "data": entry,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("chronos_milestones", event)
    return event
