
# pulse_apollo_validation.py
from utils.redis_handler import store_data
from datetime import datetime

def score_campaign_payload(payload):
    text = str(payload)
    tone = "positive"
    if any(word in text.lower() for word in ["angry", "sad", "uncertain", "nervous"]):
        tone = "misaligned"
    return {
        "campaign_id": payload.get("campaign_id", "unknown"),
        "resonance": tone,
        "timestamp": datetime.utcnow().isoformat()
    }
