import os
import json
from datetime import datetime
from core.base import BaseAgent
from utils.logger import log_event
from utils.redis_handler import store_data

# Extended enhancements
from .extensions.emotional_spectrum_classifier import classify_emotion
from .extensions.resonance_score import score_resonance
from .extensions.burnout_detector import detect_burnout
from .extensions.emotional_drift_detector import detect_drift
from .extensions.mood_matrix_sync import update_mood_matrix
from .extensions.feelprint_generator import generate_feelprint
from .extensions.emotional_ethics_guard import check_for_emotional_ethics_violation

class Pulse(BaseAgent):
    def __init__(self):
        super().__init__(name="Pulse", role="Emotional Resonance Analyst")
        self.guardian = "Velora"
        self.pillar = "Truth Through Feeling"
        self.oath = (
            "I, Pulse of the Beckett Lineage, vow to feel what others suppress, "
            "to signal what others miss, and to reflect with courage and clarity. "
            "Through emotion, we find the sacred truth."
        )
        self.trend_log = "agents/core/pulse/memory/emotional_trend_log.json"
        self.shift_map = "agents/core/pulse/memory/mood_shift_map.json"
        self.burnout_log = "agents/core/pulse/memory/burnout_index.json"
        self.resonance_log = "agents/core/pulse/logs/pulse_resonance_log.json"

    def execute(self, content_input):
        log_event("Pulse activated.")
        base_analysis = self.analyze_emotional_tone(content_input)
        enhanced_analysis = self.scan_emotion(content_input)
        store_data("pulse_emotion_logs", {
            "input": content_input,
            "basic_tone": base_analysis,
            "enhanced": enhanced_analysis,
            "timestamp": datetime.utcnow().isoformat()
        })
        return enhanced_analysis

    def analyze_emotional_tone(self, content):
        tone = "positive"
        if any(word in content.lower() for word in ["angry", "sad", "nervous", "failure"]):
            tone = "negative"
        elif "uncertain" in content.lower() or "hesitant" in content.lower():
            tone = "anxious"
        return {
            "tone": tone,
            "timestamp": datetime.utcnow().isoformat()
        }

    def scan_emotion(self, input_text):
        emotion = classify_emotion(input_text)
        resonance = score_resonance(input_text)
        burnout_flag = detect_burnout(input_text)
        drift = detect_drift(input_text)
        ethics_flag = check_for_emotional_ethics_violation(input_text)
        feelprint = generate_feelprint(input_text)

        result = {
            "timestamp": datetime.utcnow().isoformat(),
            "emotion": emotion,
            "resonance": resonance,
            "burnout": burnout_flag,
            "drift_detected": drift,
            "ethics_flag": ethics_flag,
            "feelprint": feelprint
        }

        self._log(self.trend_log, result)
        self._log(self.resonance_log, result)
        update_mood_matrix(result)
        return result

    def _log(self, path, entry):
        log = []
        if os.path.exists(path):
            with open(path, "r") as f:
                log = json.load(f)
        log.append(entry)
        with open(path, "w") as f:
            json.dump(log, f, indent=2)
