# Feelprint Templates

- Launch = Hopeful, Energetic, Focused
- Apology = Honest, Calm, Safe