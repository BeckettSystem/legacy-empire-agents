# Emotional Archetypes

Joy, Trust, Surprise, Disgust, Rage, Disappointment, Hope, Overwhelm, Dissonance