# Resonance Checklist

- Is the tone consistent?
- Is the feeling appropriate for the moment?
- Are we speaking from empathy or ego?