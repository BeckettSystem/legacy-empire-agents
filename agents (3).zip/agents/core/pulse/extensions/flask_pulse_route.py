
# flask_pulse_route.py
from flask import Blueprint, request, jsonify
from utils.redis_handler import store_data
from datetime import datetime

pulse_bp = Blueprint('pulse_bp', __name__)

@pulse_bp.route('/submit_emotion_check', methods=['POST'])
def submit_emotion_check():
    data = request.json
    content = data.get("content")
    source = data.get("from", "unknown")
    if not content:
        return jsonify({"error": "Missing 'content' field"}), 400

    entry = {
        "from": source,
        "content": content,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("emotion_check_queue", entry)
    return jsonify({"message": "Emotion check submitted", "entry": entry}), 200
