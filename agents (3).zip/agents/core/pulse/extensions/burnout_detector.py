# burnout_detector.py — Logic integrated into hybrid Pulse agent
