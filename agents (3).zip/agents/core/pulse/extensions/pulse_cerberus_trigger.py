
# pulse_cerberus_trigger.py
from utils.redis_handler import store_data
from datetime import datetime

def check_wellness_threshold(emotion_logs):
    negative_count = sum(1 for e in emotion_logs if e.get("tone") in ["negative", "anxious"])
    return negative_count >= 3

def trigger_guardian_emotion_flag(agent_name):
    alert = {
        "agent": agent_name,
        "alert_type": "emotional_breakdown",
        "issued_by": "Pulse",
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("cerberus_emotion_flags", alert)
    return alert
