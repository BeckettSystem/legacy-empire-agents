# emotional_ethics_guard.py — Logic integrated into hybrid Pulse agent
