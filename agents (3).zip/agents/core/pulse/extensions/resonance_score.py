# resonance_score.py — Logic integrated into hybrid Pulse agent
