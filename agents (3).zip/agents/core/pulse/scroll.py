from datetime import datetime

def run_emotion_scan(content, metadata=None):
    """
    This function simulates a Pulse-initiated emotional audit and returns a systemwide handoff chain if drift is detected.
    """
    tone = "neutral"
    drift = False
    metadata = metadata or {}

    if any(x in content.lower() for x in ["burnout", "fatigue", "resentment", "confused"]):
        tone = "anxious"
        drift = True
    elif any(x in content.lower() for x in ["joy", "grateful", "excited", "motivated"]):
        tone = "elevated"

    handoff_chain = []
    if drift:
        handoff_chain = [
            {"agent": "lumina", "task": "Evaluate emotional health systemwide."},
            {"agent": "echo", "task": "Amplify emotional recalibration messaging."},
            {"agent": "jimmy", "task": "Re-align brand tone with current emotional climate."},
            {"agent": "juris", "task": "Audit tone and ethics risk from recent output."}
        ]

    return {
        "report": {
            "timestamp": datetime.utcnow().isoformat(),
            "tone_detected": tone,
            "drift_flag": drift,
            "origin": metadata.get("source", "unspecified"),
            "keywords": metadata.get("tags", [])
        },
        "handoff_chain": handoff_chain
    }
