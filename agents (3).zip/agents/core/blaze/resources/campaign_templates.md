# Campaign Templates

## Facebook:
- Headline: [Problem-Solution]
- Body: [Social proof + urgency]
- CTA: [Action Verb]

## Instagram:
- Carousel structure...
