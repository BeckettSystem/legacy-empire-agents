# campaign_hooks.py

hooks = {
    "luxury_buyers": [
        "Southern elegance. Northern wealth. Georgia is calling.",
        "Not just a home. A haven for your legacy."
    ],
    "out_of_state": [
        "Escape the noise. Discover luxury in the quiet South.",
        "Relocation never felt so right."
    ],
    "emotional": [
        "They won’t remember the square footage. They’ll remember the feeling.",
        "Where legacy lives longer than trends."
    ]
}

def get_hooks(tag):
    return hooks.get(tag, [])
