# reinforcement_loop.py – Logic will be defined per campaign context
