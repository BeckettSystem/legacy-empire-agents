# simulate_metrics.py – Logic will be defined per campaign context
