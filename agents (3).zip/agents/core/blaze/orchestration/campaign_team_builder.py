
import json
from datetime import datetime

WEIGHT_PATH = "core/orchestration/campaign_weights.json"
SCROLL_OUTPUT = "core/orchestration/campaign_team_scroll.json"

def assemble_campaign_team(campaign_type="awareness"):
    with open(WEIGHT_PATH, "r") as f:
        weights = json.load(f)
    agent_scores = weights.get(campaign_type, {})
    sorted_agents = sorted(agent_scores.items(), key=lambda x: x[1], reverse=True)

    team = [{
        "agent": name,
        "weight": weight,
        "assigned_role": "core collaborator" if weight >= 0.9 else "support"
    } for name, weight in sorted_agents]

    scroll = {
        "campaign_type": campaign_type,
        "timestamp": datetime.utcnow().isoformat(),
        "team": team
    }

    with open(SCROLL_OUTPUT, "w") as f:
        json.dump(scroll, f, indent=2)

    return scroll
