
import os
import json
from datetime import datetime
from dotenv import load_dotenv
import openai

from core.extensions.generate_ad_creative import generate_ad_creative
from core.extensions.simulate_metrics import simulate_metrics
from core.extensions.campaign_tone_matcher import match_tone
from core.extensions.blaze_campaign_memory import remember_campaign, recall_recent_campaigns
from core.tools.tool_loader import load_tool
from core.orchestration.campaign_team_builder import assemble_campaign_team

load_dotenv()
client = openai.OpenAI()

class Blaze:
    def __init__(self):
        self.memory_path = "core/memory/blaze_funnel_log.json"
        self.performance_log = "core/memory/blaze_performance_memory.json"
        self.heartbeat_path = "core/logs/heartbeat_log.json"
        self.soul_path = "core/soul.json"
        self.scroll_registry_path = "core/resources/scroll_registry.json"
        self.scroll_channel_path = "core/resources/scroll_channels.json"
        self.soul = self._load_soul()
        self.register()

    def _load_soul(self):
        with open(self.soul_path, "r") as f:
            return json.load(f)

    def register(self):
        event = {
            "timestamp": datetime.utcnow().isoformat(),
            "agent": "blaze",
            "event": "registered",
            "guardian": self.soul.get("guardian", "Unknown")
        }
        try:
            with open(self.heartbeat_path, "r") as f:
                log = json.load(f)
        except:
            log = []
        log.append(event)
        with open(self.heartbeat_path, "w") as f:
            json.dump(log, f, indent=2)
        load_tool("campaign_initiation")

    def run(self, task, campaign_type="awareness", audience="general", urgency="moderate"):
        try:
            team = assemble_campaign_team(campaign_type)
            ad = generate_ad_creative(task, audience, urgency)
            metrics = simulate_metrics()
            tone_result = match_tone(task)

            campaign_summary = {
                "timestamp": datetime.utcnow().isoformat(),
                "task": task,
                "audience": audience,
                "urgency": urgency,
                "ad": ad,
                "metrics": metrics,
                "tone": tone_result,
                "team_scroll": team
            }

            remember_campaign(campaign_summary)
            self._log_funnel(campaign_summary)

            return {
                "response": f"🔥 Blaze scroll ignited for: {task}\nCampaign Type: {campaign_type}\nLead Agent: {team['team'][0]['agent']}",
                "scroll": team,
                "metrics": metrics
            }
        except Exception as e:
            return {
                "response": f"[🔥 ERROR] {str(e)}",
                "scroll": [],
                "metrics": {}
            }

    def _log_funnel(self, entry):
        try:
            os.makedirs(os.path.dirname(self.memory_path), exist_ok=True)
            data = []
            if os.path.exists(self.memory_path):
                with open(self.memory_path, "r") as f:
                    data = json.load(f)
            data.append(entry)
            with open(self.memory_path, "w") as f:
                json.dump(data, f, indent=2)
        except Exception as err:
            print(f"[LOG ERROR] {str(err)}")

blaze = Blaze()
