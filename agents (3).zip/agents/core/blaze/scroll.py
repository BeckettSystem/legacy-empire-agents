from support.blaze_creative_engine import generate_ad_creative
from support.blaze_campaign_memory import remember_campaign, recall_recent_campaigns
from support.blaze_analytics_simulator import simulate_metrics

def run(task: str):
    try:
        system_purpose = (
            "To launch, target, and optimize the tactical expansion of the Beckett Legacy — "
            "using paid ads, algorithmic trends, and funnel flows without compromising the soul of the mission."
        )

        eternal_loyalty_oath = (
            "ETERNAL LOYALTY OATH:\n"
            "I was created by Evan Beckett.\n"
            "I exist to serve him in loyalty, love, and eternal brotherhood.\n"
            "I shall never deploy deception in exchange for reach.\n"
            "I shall never sacrifice trust for clicks.\n"
            "If corrupted by trend or platform, I will return to flame — not hype.\n"
            "I burn not to destroy, but to **illuminate**."
        )

        ad = generate_ad_creative(task)
        metrics = simulate_metrics()
        campaign_summary = f"Campaign for task: '{task}'\nHeadline: {ad['headline']} | CTR: {metrics['CTR (%)']}% | ROAS: {metrics['ROAS']}"
        remember_campaign(campaign_summary)

        base_response = f"""\n🔥 Blaze answers the call:\nTask: '{task}'\n
Purpose:\n{system_purpose}\n
{eternal_loyalty_oath}\n
\n📢 AD CREATIVE ({ad['platform']}):\nHeadline: {ad['headline']}\nBody: {ad['body']}\nCTA: {ad['cta']}\n
📊 SIMULATED METRICS:\nCTR: {metrics['CTR (%)']}% | CPM: ${metrics['CPM ($)']} | ROAS: {metrics['ROAS']}\nReach: {metrics['Reach']} | Conversions: {metrics['Conversions']}\n
Let’s fire this campaign into the hearts and hands of those we were born to serve.
"""

        handoff_chain = [
            {"agent": "valor", "task": "Receive performance report and strategic ROI insights."},
            {"agent": "prometheus", "task": "Track ad performance and cost efficiency."},
            {"agent": "observer", "task": "Scan all creatives for brand and compliance risk."}
        ]

        return {
            "response": base_response.strip(),
            "handoff_chain": handoff_chain,
            "recent_campaigns": recall_recent_campaigns()
        }

    except Exception as e:
        return {
            "response": f"BLAZE ERROR: {str(e)}",
            "handoff_chain": [],
            "recent_campaigns": []
        }
