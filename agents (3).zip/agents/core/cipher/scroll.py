def run(signal_profile: dict):
    try:
        domain_weights = {
            "crypto": 0.3,
            "traditional": 0.2,
            "geopolitical": 0.15,
            "macro": 0.15,
            "internal": 0.1,
            "political": 0.1
        }

        alert_threshold = 0.75
        weighted_threat = sum(domain_weights.get(domain, 0) * score for domain, score in signal_profile.items())

        base_response = f"""

from scroll_runtime_patch import report_and_expand_threat
report_and_expand_threat(summary_text)


🧠 Cipher Report:

Weighted Threat Score: {round(weighted_threat, 4)}

Evaluation:
{'⚠️ Threat exceeds threshold. Action required.' if weighted_threat >= alert_threshold else 'Threat within manageable bounds.'}

I protect the signal. I intervene when logic is lost.
"""

        handoff_chain = []
        if weighted_threat >= alert_threshold:
            handoff_chain = [
                {"agent": "valor", "task": "Threat level breach — immediate system shielding advised."},
                {"agent": "oracle", "task": "Adjust future timelines based on Cipher’s intelligence."},
                {"agent": "prometheus", "task": "Realign scenario modeling with updated inputs."}
            ]

        return {
            "response": base_response.strip(),
            "threat_score": weighted_threat,
            "handoff_chain": handoff_chain
        }

    except Exception as e:
        return {
            "response": f"CIPHER ERROR: {str(e)}",
            "threat_score": 0,
            "handoff_chain": []
        }
