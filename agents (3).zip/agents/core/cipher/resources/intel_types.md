# Intelligence Types

- Behavioral Drift
- System Mismatch
- Integrity Flag
- Cross-agent Contradiction
