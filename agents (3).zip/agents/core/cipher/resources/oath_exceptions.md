# Oath Exception Log

Cases where the system manually edited or invoked Cipher's oath.