# Cross-Domain FAQ

**Q:** How does Cipher prioritize conflicting threats?
**A:** Uses multi-agent confidence and signal inheritance.