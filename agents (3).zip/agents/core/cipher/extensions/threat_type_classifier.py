# Extension logic for Threat Type Classifier
