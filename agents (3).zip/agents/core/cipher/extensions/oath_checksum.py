# Extension logic for Oath Checksum
