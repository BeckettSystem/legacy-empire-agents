from fastapi import FastAPI, Request
import uvicorn
from scroll import run as cipher_scroll

app = FastAPI()

@app.post("/webhook/cipher")
async def cipher_webhook(req: Request):
    data = await req.json()
    result = cipher_scroll(data)
    return {"status": "processed", "cipher_result": result}

# To run: uvicorn webhook_listener:app --reload --port 8001
