# scrambler.py – Counter-Intelligence Extension

import hashlib
import json
from datetime import datetime

def scramble_payload(data: dict, reason="Unknown threat pattern"):
    """
    Obfuscates sensitive data and returns a secure hash signature.
    """
    timestamp = datetime.utcnow().isoformat()
    payload_copy = data.copy()

    # Convert to string and hash
    data_str = json.dumps(payload_copy, sort_keys=True)
    hash_signature = hashlib.sha256(data_str.encode()).hexdigest()

    # Generate scrambled payload
    scrambled_output = {
        "timestamp": timestamp,
        "hash_signature": hash_signature,
        "reason": reason,
        "status": "scrambled",
        "note": "Payload concealed for security. Confirm with Valor or Evan Beckett to decrypt."
    }

    return scrambled_output
