# Extension logic for Forecast Simulator
