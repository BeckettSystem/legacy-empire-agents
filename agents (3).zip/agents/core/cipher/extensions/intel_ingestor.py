import requests

def fetch_crypto_market():
    try:
        r = requests.get("https://api.coingecko.com/api/v3/global")
        return r.json()
    except Exception as e:
        return {"error": str(e)}

def fetch_rss_news(feed_url="https://www.reutersagency.com/feed/?best-topics=politics"):
    import feedparser
    return feedparser.parse(feed_url)
