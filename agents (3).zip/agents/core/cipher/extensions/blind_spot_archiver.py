# Extension logic for Blind Spot Archiver
