# Extension logic for Logic Contradiction Detector
