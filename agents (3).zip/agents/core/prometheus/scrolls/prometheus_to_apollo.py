
# prometheus_to_apollo.py
from utils.redis_handler import store_data
from datetime import datetime

def format_for_apollo(idea_entry):
    apollo_payload = {
        "campaign_title": f"Inspired by Prometheus: {idea_entry['idea'][:50]}",
        "creative_direction": "Bold, future-forward, disruptive",
        "content_payload": idea_entry,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("apollo_campaign_queue", apollo_payload)
    return apollo_payload
