
# chronos_prometheus_sync.py
from utils.redis_handler import store_data
from datetime import datetime

def register_innovation_milestone(idea_id, milestone="idea_born"):
    event = {
        "agent": "Prometheus",
        "milestone": milestone,
        "idea_id": idea_id,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("chronos_milestones", event)
    return event
