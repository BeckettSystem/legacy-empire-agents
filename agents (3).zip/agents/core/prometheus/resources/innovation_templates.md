# Innovation Templates

- Agent Blueprint Template
- Ritual Scroll Draft Template
- Campaign Architecture Models