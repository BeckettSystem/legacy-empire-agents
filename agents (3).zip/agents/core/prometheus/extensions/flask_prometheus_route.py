
# flask_prometheus_route.py
from flask import Blueprint, request, jsonify
from utils.redis_handler import store_data
from datetime import datetime

prometheus_bp = Blueprint('prometheus_bp', __name__)

@prometheus_bp.route('/submit_challenge', methods=['POST'])
def submit_challenge():
    data = request.json
    challenge = data.get("challenge")
    if not challenge:
        return jsonify({"error": "Challenge is required"}), 400
    
    entry = {
        "challenge": challenge,
        "submitted_at": datetime.utcnow().isoformat(),
        "status": "pending"
    }
    store_data("prometheus_challenge_queue", entry)
    return jsonify({"message": "Challenge submitted to Prometheus", "entry": entry}), 200
