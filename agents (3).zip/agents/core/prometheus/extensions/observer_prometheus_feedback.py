
# observer_prometheus_feedback.py
from utils.redis_handler import store_data
from datetime import datetime

def log_feedback_from_observer(idea_id, results):
    feedback_entry = {
        "origin_agent": "Prometheus",
        "idea_id": idea_id,
        "results": results,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("observer_insight_log", feedback_entry)
    return feedback_entry
