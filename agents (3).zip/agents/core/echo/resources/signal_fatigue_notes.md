# Signal Fatigue Notes

Document when campaigns lose energy or engagement too quickly.