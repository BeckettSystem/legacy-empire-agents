# Resonance Patterns

Use this to record common campaign tone profiles and emotional signature mappings.