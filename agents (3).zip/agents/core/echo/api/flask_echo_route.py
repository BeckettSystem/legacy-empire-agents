
# flask_echo_route.py
from flask import Blueprint, request, jsonify
from utils.redis_handler import store_data
from datetime import datetime

echo_bp = Blueprint('echo_bp', __name__)

@echo_bp.route('/deploy_campaign', methods=['POST'])
def deploy_campaign():
    data = request.json
    entry = {
        "triggered_by": "dashboard",
        "payload": data,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("echo_deploy_queue", entry)
    return jsonify({"message": "Campaign deployed by Echo", "entry": entry}), 200
