# echo_decay_logger.py — Functional logic handled at runtime
