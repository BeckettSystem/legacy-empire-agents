
# echo_sync_tools.py
from utils.redis_handler import store_data
from datetime import datetime

def sync_to_chronos(campaign_title):
    event = {
        "agent": "Echo",
        "event": "campaign_deployed",
        "campaign": campaign_title,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("chronos_milestones", event)
    return event

def archive_to_scroll(campaign_data):
    entry = {
        "origin": "Echo",
        "type": "platform_delivery",
        "content": campaign_data,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("patriarch_scroll_log", entry)
    return entry
