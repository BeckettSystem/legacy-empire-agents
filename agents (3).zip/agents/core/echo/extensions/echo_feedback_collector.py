
# echo_feedback_collector.py
from utils.redis_handler import store_data
from datetime import datetime

def receive_feedback(campaign_id, feedback_data):
    entry = {
        "campaign_id": campaign_id,
        "feedback": feedback_data,
        "timestamp": datetime.utcnow().isoformat(),
        "source": "Pulse/Observer"
    }
    store_data("echo_feedback_log", entry)
    return entry
