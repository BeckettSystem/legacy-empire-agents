
# echo_channel_publisher.py
from utils.redis_handler import store_data
from datetime import datetime

def publish_to_channel(platform, campaign):
    result = {
        "platform": platform,
        "campaign": campaign.get("campaign_title", "Untitled"),
        "timestamp": datetime.utcnow().isoformat(),
        "status": "simulated_delivery"
    }
    store_data("echo_channel_reports", result)
    return result
