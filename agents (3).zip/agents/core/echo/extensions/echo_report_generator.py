
# echo_report_generator.py
from utils.redis_handler import fetch_data

def generate_report():
    logs = fetch_data("echo_delivery_logs")
    return {
        "total_campaigns": len(logs),
        "campaigns": logs
    }
