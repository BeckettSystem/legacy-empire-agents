import os
import json
from datetime import datetime
from .extensions.platform_sentiment_aggregator import aggregate_sentiment
from .extensions.resonance_analyzer import analyze_resonance
from .extensions.echo_decay_logger import log_echo_decay
from .extensions.multi_tone_scaler import scale_tones
from .extensions.echo_cloak_protocol import check_for_cloak

class Echo:
    def __init__(self):
        self.signal_log = "agents/core/echo/memory/signal_memory.json"
        self.decay_log = "agents/core/echo/logs/echo_decay_log.json"
        self.resonance_log = "agents/core/echo/logs/resonance_analysis_log.json"

    def transmit(self, campaign_payload):
        try:
            result = {
                "campaign": campaign_payload.get("campaign_title", "Untitled"),
                "timestamp": datetime.utcnow().isoformat(),
                "platforms": ["Instagram", "YouTube", "Email", "SMS"]
            }

            result["sentiment"] = aggregate_sentiment(campaign_payload)
            result["resonance"] = analyze_resonance(campaign_payload)
            result["tones_detected"] = scale_tones(campaign_payload)

            self._log_signal(result)
            log_echo_decay(result)
            check_for_cloak(result)

            return {
                "status": "delivered",
                "summary": result
            }

        except Exception as e:
            return {"error": str(e)}

    def _log_signal(self, result):
        log = []
        if os.path.exists(self.signal_log):
            with open(self.signal_log, "r") as f:
                log = json.load(f)
        log.append(result)
        with open(self.signal_log, "w") as f:
            json.dump(log, f, indent=2)
