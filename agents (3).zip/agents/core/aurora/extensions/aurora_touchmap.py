# core/extensions/aurora_touchmap.py
def get_touch_sequence(persona="luxury buyer"):
    flows = {
        "luxury buyer": [
            "Day 1: Personal welcome message from Evan",
            "Day 3: Curated neighborhood showcase",
            "Day 7: Home vision alignment call",
            "Day 10: Bespoke lender intro",
            "Day 14: First look at off-market inventory"
        ],
        "relocation client": [
            "Day 1: Welcome email with area guide",
            "Day 2: Virtual welcome basket",
            "Day 4: School and commute resources",
            "Day 6: Personalized relocation checklist",
            "Day 9: Local ambassador call setup"
        ]
    }
    return flows.get(persona, flows["luxury buyer"])
