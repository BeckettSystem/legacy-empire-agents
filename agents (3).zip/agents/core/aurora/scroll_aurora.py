# core/scrolls/scroll_aurora.py
from core.agents.experience.aurora_agent import run_aurora
from core.extensions.aurora_log import log_memory
from core.extensions.aurora_touchmap import get_touch_sequence

def generate_onboarding_flow(audience_type):
    prompt = f"Create a 5-touch onboarding flow for {audience_type}."
    response = run_aurora(prompt)
    log_memory("onboarding_flow", audience_type, response)
    return response

def get_first_touch_sequence(persona="luxury buyer"):
    return get_touch_sequence(persona)
