
def load_tool(tool_name):
    try:
        print(f"[💫] Tool '{tool_name}' is now active for Aurora.")
        return {tool_name: "active"}
    except Exception as e:
        return {"error": str(e)}
