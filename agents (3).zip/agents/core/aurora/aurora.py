
import os
import json
from datetime import datetime
from dotenv import load_dotenv
import openai

load_dotenv()
client = openai.OpenAI()

class Aurora:
    def __init__(self):
        self.memory_path = "memory/aurora_journey_log.json"
        self.log_path = "logs/aurora_response_log.json"
        self.heartbeat_path = "logs/heartbeat_log.json"
        self.soul_path = "soul_aurora.json"
        self.scroll_registry_path = "resources/scroll_registry.json"
        self.soul = self._load_soul()
        self.register()

    def _load_soul(self):
        with open(self.soul_path, "r") as f:
            return json.load(f)

    def register(self):
        from tools.tool_loader import load_tool
        event = {
            "timestamp": datetime.utcnow().isoformat(),
            "agent": "aurora",
            "event": "registered",
            "guardian": self.soul.get("guardian", "Unknown")
        }
        log = []
        if os.path.exists(self.heartbeat_path):
            with open(self.heartbeat_path, "r") as f:
                log = json.load(f)
        log.append(event)
        with open(self.heartbeat_path, "w") as f:
            json.dump(log, f, indent=2)
        load_tool("journey_memory")

    def run(self, task, persona="general"):
        try:
            tone = self.detect_tone(task)
            message = self._generate_message(task, tone)
            self._log(task, message, tone, persona)
            return {
                "response": message.strip(),
                "handoff_chain": self._handoff_chain(persona)
            }
        except Exception as e:
            return {
                "response": f"AURORA ERROR: {str(e)}",
                "handoff_chain": []
            }

    def detect_tone(self, task):
        lower_task = task.lower()
        if any(x in lower_task for x in ["frustrated", "worried", "confused"]):
            return "soothing"
        elif any(x in lower_task for x in ["excited", "ready", "motivated"]):
            return "celebratory"
        else:
            return "warm"

    def _generate_message(self, task, tone):
        tone_line = {
            "soothing": "Let’s move gently, with understanding and care.",
            "celebratory": "Let’s celebrate what’s ahead — I’m with you all the way!",
            "warm": "I’m honored to walk with you from the very first step."
        }
        system_purpose = self.soul.get("role", "To guide with empathy.")
        oath = self.soul.get("oath", "I serve in loyalty and grace.")
        return f"""
Aurora steps forward with grace:
🌅 '{task}'

I do not automate. I connect.
I do not manage contacts. I remember moments.

Tone: {tone.upper()} – {tone_line[tone]}

Purpose:
{system_purpose}

Oath:
{oath}
"""

    def _handoff_chain(self, persona):
        return [
            {"agent": "steward", "task": f"Trigger journey map for {persona}."},
            {"agent": "quill", "task": "Sync timing with readiness windows."},
            {"agent": "echo", "task": "Log emotional response patterns."}
        ]

    def _log(self, task, response, tone, persona):
        entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "input": task,
            "persona": persona,
            "tone": tone,
            "response": response
        }
        os.makedirs(os.path.dirname(self.memory_path), exist_ok=True)
        with open(self.memory_path, "a") as f:
            f.write(json.dumps(entry) + "\n")
        with open(self.log_path, "a") as f:
            f.write(json.dumps(entry) + "\n")

aurora = Aurora()
