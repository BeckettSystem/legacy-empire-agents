# collector.py
"""
Collector - The Treasury Guardian for the Beckett Legacy
"""

from scroll.scroll_update_protocol import update_scroll
from support.secrets_loader import load_secrets

class Collector:
    def __init__(self):
        self.records = []
        self.secrets = load_secrets()

    def log_transaction(self, source, amount, currency="USD", notes=None):
        entry = {
            "source": source,
            "amount": amount,
            "currency": currency,
            "notes": notes
        }
        self.records.append(entry)
        update_scroll(f"Collector: Logged transaction from {source} for {amount} {currency}.")

    def summarize(self):
        total = sum(entry['amount'] for entry in self.records)
        update_scroll(f"Collector: Current session total: {total} USD")
        return total

    def export_ledger(self, path="scroll/ledger.md"):
        with open(path, "a") as f:
            for entry in self.records:
                f.write(f"{entry['source']} | {entry['amount']} {entry['currency']} | {entry.get('notes','-')}
")
        update_scroll("Collector: Ledger export complete.")

if __name__ == "__main__":
    collector = Collector()
    collector.log_transaction("Broker", 8500, notes="Commission from closing")
    collector.summarize()
    collector.export_ledger()
