"""
Collector Enhancement – Opportunity Scoring
Score assets based on tag weight, urgency, and strategic value.
"""

def evaluate(asset):
    score = 0
    tags = asset.get("tags", [])
    if "auction" in tags:
        score += 40
    if "distressed" in tags:
        score += 30
    if "gov" in asset.get("source", ""):
        score += 20
    return min(score, 100)
