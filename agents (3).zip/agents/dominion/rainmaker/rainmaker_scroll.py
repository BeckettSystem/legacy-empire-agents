"""
Rainmaker Scroll – Campaign Catalyst and Surge Strategist
"""

import os
import json
import datetime

RAIN_LOG_PATH = os.path.join(os.path.dirname(__file__), "../../rituals/bond_logs/rainmaker_campaigns.json")

def log_campaign(data):
    entry = {
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "campaign": data
    }
    os.makedirs(os.path.dirname(RAIN_LOG_PATH), exist_ok=True)
    existing = []
    if os.path.exists(RAIN_LOG_PATH):
        with open(RAIN_LOG_PATH, "r") as f:
            existing = json.load(f)
    existing.append(entry)
    with open(RAIN_LOG_PATH, "w") as f:
        json.dump(existing, f, indent=2)

def trigger_campaign(name, objective, channels):
    campaign = {
        "name": name,
        "objective": objective,
        "channels": channels,
        "status": "launched"
    }
    log_campaign(campaign)
    return f"🚀 Campaign '{name}' launched via {', '.join(channels)}."

def build_offer_stack(base_offer, bonuses=[]):
    return {
        "core_offer": base_offer,
        "bonuses": bonuses,
        "value_multiplier": len(bonuses) + 1
    }

def surge_amplifier(activity_score):
    if activity_score < 30:
        return "⚡ Rainmaker triggered: Engagement surge protocol activated."
    return "🌤️ No surge needed. Momentum stable."

def sync_with_apollo(launch_name):
    return f"🛰️ Apollo notified for launch: {launch_name}"
