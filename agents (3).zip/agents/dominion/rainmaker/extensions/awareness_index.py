"""
Rainmaker Enhancement – Awareness Tracker
Calculates current system attention index based on reach + visibility metrics.
"""

def calculate_index(visits, shares, inquiries):
    return visits * 0.5 + shares * 1.2 + inquiries * 2.0
