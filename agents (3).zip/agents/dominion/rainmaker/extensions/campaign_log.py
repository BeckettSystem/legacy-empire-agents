"""
Rainmaker Enhancement – Campaign Outcome Log
Records success, metrics, and feedback for each launch cycle.
"""

def archive_campaign(name, results):
    return {
        "campaign": name,
        "results": results,
        "timestamp": datetime.datetime.utcnow().isoformat()
    }
