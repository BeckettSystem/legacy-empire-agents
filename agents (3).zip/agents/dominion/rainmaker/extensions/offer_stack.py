"""
Rainmaker Enhancement – Offer Stack Generator
Builds powerful value ladders from core offers and bonus tiers.
"""

def generate_stack(base, bonuses):
    return {"core": base, "bonuses": bonuses, "stack_score": len(bonuses) + 1}
