"""
Rainmaker Enhancement – Storm Trigger
Detects low system momentum and auto-activates campaign launch.
"""

def check_momentum(score):
    return score < 25
