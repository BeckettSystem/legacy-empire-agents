# dashboard_routes.py
from flask import Blueprint, jsonify
from agent_loader import get_agent

dashboard_bp = Blueprint('dashboard_bp', __name__)

@dashboard_bp.route("/dashboard/trigger/<agent>/action", methods=["POST"])
def trigger_agent_action(agent):
    agent_instance = get_agent(agent)
    if agent == "tycoon":
        agent_instance.run_weekly_review()
    elif agent == "magnet":
        agent_instance.summarize_leads()
    elif agent == "merchant":
        agent_instance.summarize_sales()
    elif agent == "rainmaker":
        agent_instance.export_deals()
    elif agent == "collector":
        agent_instance.summarize()
    elif agent == "broker":
        agent_instance.sync_listings()
    return jsonify({"status": "Triggered", "agent": agent})
