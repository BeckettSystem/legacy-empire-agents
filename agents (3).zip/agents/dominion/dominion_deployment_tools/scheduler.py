# scheduler.py
import schedule
import time
from agent_loader import get_agent

def run_all_daily():
    get_agent("magnet").summarize_leads()
    get_agent("merchant").summarize_sales()
    get_agent("broker").sync_listings()

def run_all_weekly():
    get_agent("tycoon").run_weekly_review()
    get_agent("collector").summarize()
    get_agent("rainmaker").export_deals()

schedule.every().day.at("06:00").do(run_all_daily)
schedule.every().sunday.at("06:00").do(run_all_weekly)

if __name__ == "__main__":
    while True:
        schedule.run_pending()
        time.sleep(60)
