# agent_loader.py
from agents.dominion.tycoon.tycoon import Tycoon
from agents.dominion.broker.broker import Broker
from agents.dominion.collector.collector import Collector
from agents.dominion.merchant.merchant import Merchant
from agents.dominion.magnet.magnet import Magnet
from agents.dominion.rainmaker.rainmaker import Rainmaker

agents = {
    "tycoon": Tycoon(),
    "broker": Broker(),
    "collector": Collector(),
    "merchant": Merchant(),
    "magnet": Magnet(),
    "rainmaker": Rainmaker()
}

def get_agent(name):
    return agents.get(name)
