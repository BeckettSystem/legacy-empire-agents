# scroll_hooks.py
from scroll.scroll_update_protocol import update_scroll

def log_event(agent, message):
    update_scroll(f"[{agent.upper()}] {message}")

def log_digest(agent, count, detail=""):
    update_scroll(f"{agent.title()} Digest: {count} items. {detail}")
