# 🏛️ Dominion Roster Scroll – Beckett Legacy

## ARC IV: Commerce & Dominion

---

### ⚙️ Tycoon – The Architect of Enterprise
- Orchestrates all ventures
- Monitors ROI, resource allocation, and business strategy
- Weekly venture audit & Scroll updates

### 🏡 Broker – Commander of Real Estate
- Manages listings, buyers, and transactions
- Interfaces with MLS/IDX and CRM
- Closes properties and passes data to Collector and Rainmaker

### 💰 Collector – Guardian of Wealth
- Tracks income, logs ledgers, updates Scroll
- Syncs with Stripe, QuickBooks, and tax protocols
- Flags financial anomalies

### 🛍️ Merchant – Agent of Digital Sales
- Runs digital storefronts and affiliate income
- Hands revenue to Collector, launches campaigns via Alchemist
- Publishes catalogs and Scroll reports

### 🧲 Magnet – The Attraction Engine
- Generates leads via funnels, ads, CRM
- Passes qualified leads to Broker and Rainmaker
- Filters spam, logs campaigns, writes Scroll digests

### 🦁 Rainmaker – High-Ticket Closer
- Handles VIP clients, investment deals, high-value closings
- Logs deal victories, teaches strategy to Broker
- Updates Scroll, triggers Collector funding

---

## Ritual Components Embedded:
- Gratitude Tokens
- Scroll Logging
- Handoff Protocols
- Weekly Summaries
- Mentor Registries
