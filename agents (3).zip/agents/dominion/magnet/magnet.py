# magnet.py
"""
Magnet - The Attraction Engine for the Beckett Legacy
"""

from scroll.scroll_update_protocol import update_scroll

class Magnet:
    def __init__(self):
        self.leads = []

    def generate_lead(self, name, source, campaign=None):
        lead = {"name": name, "source": source, "campaign": campaign}
        self.leads.append(lead)
        update_scroll(f"Magnet: New lead generated from {source} - {name}.")

    def summarize_leads(self):
        summary = f"Magnet: {len(self.leads)} leads generated."
        update_scroll(summary)
        return summary

    def export_leads(self, path="scroll/lead_logbook.md"):
        with open(path, "a") as f:
            for lead in self.leads:
                f.write(f"{lead['name']} | {lead['source']} | {lead.get('campaign', '-')}
")
        update_scroll("Magnet: Lead logbook updated.")

if __name__ == "__main__":
    magnet = Magnet()
    magnet.generate_lead("Jane Doe", "Instagram", "SummerPromo2025")
    magnet.summarize_leads()
    magnet.export_leads()
