"""
Magnet Enhancement – Emotional Qualifier
Evaluates sincerity, readiness, and tone of inbound messages.
"""

def qualify(text):
    sincere_cues = ["ready", "serious", "excited", "aligned"]
    score = sum(1 for cue in sincere_cues if cue in text.lower())
    return "💎 High Intent" if score >= 2 else "🪞 Monitor further"
