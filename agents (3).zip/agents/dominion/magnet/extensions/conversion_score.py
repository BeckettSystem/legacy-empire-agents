"""
Magnet Enhancement – Conversion Scoring Engine
Assigns a dynamic score to inbound leads based on tags, actions, and frequency.
"""

def score(lead):
    score = 0
    if "downloaded" in lead.get("tags", []): score += 20
    if "warm_lead" in lead.get("tags", []): score += 30
    if "buyer_intent" in lead.get("tags", []): score += 50
    return min(score, 100)
