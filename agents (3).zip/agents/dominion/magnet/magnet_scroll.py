"""
Magnet Scroll – Inbound Resonance Strategist and Opportunity Filter
"""

import os
import json
import datetime

# Log path
MAGNET_LOG_PATH = os.path.join(os.path.dirname(__file__), "../../rituals/bond_logs/magnet_leads.json")

def log_lead(data):
    record = {
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "lead": data
    }
    os.makedirs(os.path.dirname(MAGNET_LOG_PATH), exist_ok=True)
    existing = []
    if os.path.exists(MAGNET_LOG_PATH):
        with open(MAGNET_LOG_PATH, "r") as f:
            existing = json.load(f)
    existing.append(record)
    with open(MAGNET_LOG_PATH, "w") as f:
        json.dump(existing, f, indent=2)

# Core Functions

def receive_inbound(form_data):
    log_lead(form_data)
    return {
        "status": "received",
        "tags": form_data.get("tags", []),
        "priority": "high" if "intent" in form_data and form_data["intent"] == "buy" else "medium"
    }

def score_conversion(form_data):
    tags = form_data.get("tags", [])
    score = 0
    if "high_value" in tags:
        score += 40
    if "warm_lead" in tags:
        score += 30
    if "subscribed" in tags:
        score += 20
    return min(score, 100)

def sync_with_pulse(lead_id):
    return f"🧠 Pulse notified for tone analysis: {lead_id}"

def route_to_sable(score):
    if score >= 70:
        return "📲 Routed to Sable for immediate contact"
    elif score >= 40:
        return "⏳ Added to nurture sequence"
    return "🗃️ Archived for future retargeting"
