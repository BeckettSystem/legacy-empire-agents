"""
Broker Enhancement – Lead Scoring Module
Assigns a score to leads based on urgency, alignment, and strategic value.
"""

def score_lead(lead):
    score = 0
    if lead.get("urgency") == "high":
        score += 50
    if lead.get("investment_size", 0) > 500000:
        score += 30
    if lead.get("alignment") in ["core", "expansion"]:
        score += 20
    return min(score, 100)
