"""
Broker Enhancement – Auto Bundle Creator
Packages all finalized deal data into a zip-ready payload.
"""

import os
import zipfile

def create_broker_bundle(source_dir, bundle_name="broker_final_bundle.zip"):
    bundle_path = os.path.join(source_dir, bundle_name)
    with zipfile.ZipFile(bundle_path, 'w') as zipf:
        for root, _, files in os.walk(source_dir):
            for file in files:
                full_path = os.path.join(root, file)
                arcname = os.path.relpath(full_path, start=source_dir)
                zipf.write(full_path, arcname)
    return f"✅ Broker bundle created at {bundle_path}"
