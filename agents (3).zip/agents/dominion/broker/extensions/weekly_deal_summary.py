"""
Broker Enhancement – Weekly Deal Summary Generator
Compiles all logged deals into a summary for review by Ledger or Leadership.
"""

import json
import os
from datetime import datetime

LOG_PATH = os.path.join(os.path.dirname(__file__), "../../rituals/bond_logs/broker_log.json")

def generate_summary():
    if not os.path.exists(LOG_PATH):
        return "No deals logged."
    with open(LOG_PATH, "r") as f:
        deals = json.load(f)
    summary = f"📈 Weekly Deal Summary ({datetime.utcnow().date()}): {len(deals)} deals logged."
    return summary
