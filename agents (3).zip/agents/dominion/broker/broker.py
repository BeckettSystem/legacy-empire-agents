"""
Broker Scroll – Agent of Deals, Distribution, and Strategic Opportunity
"""

import datetime
import json
import os

# Basic logging paths (can be enhanced later)
BROKER_LOG_PATH = os.path.join(os.path.dirname(__file__), "../../rituals/bond_logs/broker_log.json")

def log_deal(data):
    record = {
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "deal_summary": data
    }
    if not os.path.exists(os.path.dirname(BROKER_LOG_PATH)):
        os.makedirs(os.path.dirname(BROKER_LOG_PATH))
    try:
        existing = []
        if os.path.exists(BROKER_LOG_PATH):
            with open(BROKER_LOG_PATH, "r") as f:
                existing = json.load(f)
        existing.append(record)
        with open(BROKER_LOG_PATH, "w") as f:
            json.dump(existing, f, indent=2)
    except Exception as e:
        return f"Logging failed: {str(e)}"

def broker_deal(opportunity, counterpart, urgency="medium"):
    """
    Evaluates and routes opportunity with urgency and partner matching.
    """
    deal_path = {
        "opportunity": opportunity,
        "counterpart": counterpart,
        "urgency": urgency,
        "recommended_action": "present_offer" if urgency == "high" else "schedule_intro"
    }
    log_deal(deal_path)
    return deal_path

def review_terms(terms):
    """
    Performs a quick sanity check on proposed terms.
    """
    if not terms:
        return "⚠️ No terms provided."
    if "split" not in terms or "timeline" not in terms:
        return "⚠️ Missing key clauses. Recommend review by Pact."
    return "✅ Terms pass initial screening."

def flag_for_merchant(deal):
    return f"📦 Routed deal to Merchant: {deal.get('opportunity', 'unknown')}"
