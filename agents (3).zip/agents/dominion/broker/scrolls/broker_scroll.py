"""
Broker Scroll – Real Estate Commander and Dealflow Strategist
"""

import os
import json
import datetime
import zipfile
import openai

# Paths
BROKER_LOG_PATH = os.path.join(os.path.dirname(__file__), "../../rituals/bond_logs/broker_log.json")
BUNDLE_DIR = os.path.dirname(__file__)
openai.api_key = os.getenv("OPENAI_API_KEY")

# --- Logging Utilities ---

def log_deal(data):
    record = {
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "deal_summary": data
    }
    os.makedirs(os.path.dirname(BROKER_LOG_PATH), exist_ok=True)
    existing = []
    if os.path.exists(BROKER_LOG_PATH):
        with open(BROKER_LOG_PATH, "r") as f:
            existing = json.load(f)
    existing.append(record)
    with open(BROKER_LOG_PATH, "w") as f:
        json.dump(existing, f, indent=2)

# --- Core Deal Functions ---

def broker_deal(opportunity, counterpart, urgency="medium"):
    deal_path = {
        "opportunity": opportunity,
        "counterpart": counterpart,
        "urgency": urgency,
        "recommended_action": "present_offer" if urgency == "high" else "schedule_intro"
    }
    log_deal(deal_path)
    return deal_path

def review_terms(terms):
    if not terms:
        return "⚠️ No terms provided."
    if "split" not in terms or "timeline" not in terms:
        return "⚠️ Missing key clauses. Recommend review by Pact."
    return "✅ Terms pass initial screening."

def flag_for_merchant(deal):
    return f"📦 Routed deal to Merchant: {deal.get('opportunity', 'unknown')}"

# --- Enhancement: Lead Scoring ---

def score_lead(lead):
    score = 0
    if lead.get("urgency") == "high":
        score += 50
    if lead.get("investment_size", 0) > 500000:
        score += 30
    if lead.get("alignment") in ["core", "expansion"]:
        score += 20
    return min(score, 100)

# --- Enhancement: IDX Connector Stub ---

def fetch_listings():
    return ["123 Legacy Way", "456 Titan Trail"]

# --- Enhancement: Weekly Deal Summary ---

def generate_summary():
    if not os.path.exists(BROKER_LOG_PATH):
        return "No deals logged."
    with open(BROKER_LOG_PATH, "r") as f:
        deals = json.load(f)
    summary = f"📈 Weekly Deal Summary ({datetime.datetime.utcnow().date()}): {len(deals)} deals logged."
    return summary

# --- Enhancement: Auto Bundle Builder ---

def create_broker_bundle(bundle_name="broker_final_bundle.zip"):
    bundle_path = os.path.join(BUNDLE_DIR, bundle_name)
    with zipfile.ZipFile(bundle_path, 'w') as zipf:
        for root, _, files in os.walk(BUNDLE_DIR):
            for file in files:
                full_path = os.path.join(root, file)
                arcname = os.path.relpath(full_path, start=BUNDLE_DIR)
                zipf.write(full_path, arcname)
    return f"✅ Broker bundle created at {bundle_path}"
