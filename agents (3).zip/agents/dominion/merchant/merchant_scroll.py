"""
Merchant Scroll – Transaction Strategist and Fulfillment Executor
"""

import os
import json
import datetime

# Log path
MERCHANT_LOG_PATH = os.path.join(os.path.dirname(__file__), "../../rituals/bond_logs/merchant_transactions.json")
REGISTRY_PATH = os.path.join(os.path.dirname(__file__), "business_registry.yaml")

def log_transaction(data):
    record = {
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "transaction": data
    }
    os.makedirs(os.path.dirname(MERCHANT_LOG_PATH), exist_ok=True)
    existing = []
    if os.path.exists(MERCHANT_LOG_PATH):
        with open(MERCHANT_LOG_PATH, "r") as f:
            existing = json.load(f)
    existing.append(record)
    with open(MERCHANT_LOG_PATH, "w") as f:
        json.dump(existing, f, indent=2)

def validate_offer(product_name, lead_tags):
    if not os.path.exists(REGISTRY_PATH):
        return "⚠️ No product registry found."
    with open(REGISTRY_PATH, "r") as f:
        content = f.read()
        if product_name in content:
            return f"✅ Offer validated: {product_name}"
    return "❌ Product not found in registry."

def create_offer_bundle(lead_type):
    base = ["welcome_kit", "service_guide"]
    if lead_type == "investor":
        base.append("roi_report")
    elif lead_type == "buyer":
        base.append("neighborhood_comparison")
    return base

def execute_fulfillment(offer_list, method="digital"):
    log_transaction({"method": method, "items": offer_list})
    return f"📦 Fulfilled: {', '.join(offer_list)} via {method}"
