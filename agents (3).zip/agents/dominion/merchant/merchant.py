# merchant.py
"""
Merchant - Digital Sales & Product Intelligence for the Beckett Legacy
"""

from scroll.scroll_update_protocol import update_scroll
from support.secrets_loader import load_secrets

class Merchant:
    def __init__(self):
        self.catalog = []
        self.orders = []
        self.secrets = load_secrets()

    def add_product(self, name, price, platform):
        product = {"name": name, "price": price, "platform": platform}
        self.catalog.append(product)
        update_scroll(f"Merchant: Added {name} at ${price} via {platform}.")

    def record_order(self, product_name, buyer, amount):
        order = {"product": product_name, "buyer": buyer, "amount": amount}
        self.orders.append(order)
        update_scroll(f"Merchant: Recorded sale of {product_name} to {buyer}.")

    def summarize_sales(self):
        total = sum(order['amount'] for order in self.orders)
        update_scroll(f"Merchant: Total sales recorded = ${total}")
        return total

if __name__ == "__main__":
    merchant = Merchant()
    merchant.add_product("Metro Luxe Print Ad", 1500, "Shopify")
    merchant.record_order("Metro Luxe Print Ad", "John Smith", 1500)
    merchant.summarize_sales()
