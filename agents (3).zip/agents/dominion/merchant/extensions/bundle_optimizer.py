"""
Merchant Enhancement – Offer Bundle Optimizer
Recommends bundles based on lead behavior and prior wins.
"""

def suggest_bundle(lead_tags):
    bundle = ["welcome_kit"]
    if "investor" in lead_tags:
        bundle.append("roi_projection")
    if "warm_lead" in lead_tags:
        bundle.append("priority_access")
    return bundle
