"""
Merchant Enhancement – Inventory Checker
Confirms if all offered items are available before commitment.
"""

def check_inventory(item, registry_lines):
    return "✅ Available" if item in registry_lines else "❌ Missing"
