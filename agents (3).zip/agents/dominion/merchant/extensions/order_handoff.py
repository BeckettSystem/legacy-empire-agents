"""
Merchant Enhancement – Order Packaging Protocol
Prepares transaction details for legal, marketing, and fulfillment handoff.
"""

def package_order(lead_name, offer):
    return {
        "lead": lead_name,
        "package": offer,
        "ready_for": ["Pact", "Aria", "Ledger"]
    }
