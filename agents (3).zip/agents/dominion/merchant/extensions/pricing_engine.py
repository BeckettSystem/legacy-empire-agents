"""
Merchant Enhancement – Dynamic Pricing Engine
Adjusts pricing based on scarcity, urgency, and lead tier.
"""

def calculate_price(base_price, scarcity_level="low", urgency="medium"):
    multiplier = 1
    if scarcity_level == "high":
        multiplier += 0.25
    if urgency == "high":
        multiplier += 0.25
    return round(base_price * multiplier, 2)
