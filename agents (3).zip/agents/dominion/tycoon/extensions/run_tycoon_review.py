from tycoon_scroll import TycoonScroll

if __name__ == "__main__":
    scroll = TycoonScroll()
    ventures = [{"name": "Metro Luxe", "budget": 100000}, {"name": "Beckett Modular Homes", "budget": 250000}]
    scroll.analyze_ventures(ventures)