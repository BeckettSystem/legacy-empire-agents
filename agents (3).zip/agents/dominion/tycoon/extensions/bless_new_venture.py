from tycoon_scroll import TycoonScroll

if __name__ == "__main__":
    scroll = TycoonScroll()
    venture = input("Enter venture name to bless: ")
    print(scroll.bless_venture(venture))