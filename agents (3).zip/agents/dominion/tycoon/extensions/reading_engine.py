import json
from logs.reflection_logger import log_reflection

class ReadingEngine:
    def __init__(self, source_file="knowledge_sources.json"):
        with open(source_file, "r") as f:
            self.library = json.load(f)

    def reflect_on_book(self, title):
        book = next((b for b in self.library["books"] if b["title"] == title), None)
        if not book:
            return f"Book '{title}' not found."
        insight = {
            "book": title,
            "lessons": book["lessons"]
        }
        log_reflection("Reading Insight", insight)
        return insight

    def all_lessons(self):
        return [lesson for book in self.library["books"] for lesson in book["lessons"]]