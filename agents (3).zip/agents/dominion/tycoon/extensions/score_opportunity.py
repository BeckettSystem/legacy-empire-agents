from tycoon_scroll import TycoonScroll

if __name__ == "__main__":
    scroll = TycoonScroll()
    idea = input("Describe your opportunity idea: ")
    print(scroll.score_opportunity(idea))