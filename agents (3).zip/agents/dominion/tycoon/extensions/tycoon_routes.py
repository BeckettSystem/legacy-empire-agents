from flask import Blueprint, render_template, request
from logs.reflection_logger import log_reflection
from agents.tycoon_scroll import TycoonScroll

tycoon_bp = Blueprint('tycoon', __name__)

@tycoon_bp.route("/invoke/tycoon", methods=["GET", "POST"])
def invoke_tycoon():
    scroll = TycoonScroll()
    if request.method == "POST":
        venture = request.form.get("venture")
        result = scroll.bless_venture(venture)
        log_reflection("Manual Venture Blessing", {"venture": venture})
        return render_template("tycoon_report.html", result=result, venture=venture)
    return render_template("tycoon_report.html")