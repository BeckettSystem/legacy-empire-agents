# tycoon.py
"""
Tycoon - Enterprise Strategist for the Beckett System
"""

from support.guardian_triggers import check_legacy_alignment, alert_bastion
from scroll.scroll_update_protocol import update_scroll
from agents.dominion.collector import log_transaction

class Tycoon:
    def __init__(self):
        self.ventures = self.load_registry()
        self.feedback = self.load_feedback()

    def load_registry(self):
        import yaml
        with open("business_registry.yaml", "r") as f:
            return yaml.safe_load(f)

    def load_feedback(self):
        import json
        try:
            with open("tycoon_feedback.json", "r") as f:
                return json.load(f)
        except:
            return {}

    def run_weekly_review(self):
        for venture in self.ventures.get("ventures", []):
            performance = self.analyze_venture(venture)
            if performance["risk"]:
                alert_bastion(venture["name"], performance)
            if not check_legacy_alignment(venture):
                update_scroll("ALERT: {} deviates from legacy vision.".format(venture["name"]))
            log_transaction(venture["name"], performance)
        update_scroll("Tycoon weekly review completed.")

    def analyze_venture(self, venture):
        return {
            "revenue": 100000,  # Mocked data
            "risk": False
        }

if __name__ == "__main__":
    tycoon = Tycoon()
    tycoon.run_weekly_review()
