# Buyer/Seller Onboarding Checklist
This file will be duplicated per client journey.

## Buyer Journey:
- [ ] Initial Consultation
- [ ] Pre-approval Verified
- [ ] Search Criteria Logged
- [ ] Showing Scheduled
- [ ] Offer Strategy Defined

## Seller Journey:
- [ ] Initial Walkthrough
- [ ] Pricing Strategy Confirmed
- [ ] Staging Consultation Booked
- [ ] Listing Date Scheduled
- [ ] Open House Plans Set
