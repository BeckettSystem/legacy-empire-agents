# scroll_update_protocol.py
def update_scroll(message):
    with open("scroll/patriarch_scroll.txt", "a") as f:
        f.write(f"{message}\n")
