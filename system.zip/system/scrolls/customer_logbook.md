# Customer Logbook
Buyer | Product | Timestamp | Notes
------|---------|-----------|------
