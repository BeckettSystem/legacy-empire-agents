import os
import yaml
from pathlib import Path

BASE_DIR = Path("agents")
GUARDIAN_DIR = Path("guardians")
MANIFEST_NAME = "manifest.yaml"

def build_manifest(agent_path, name):
    scroll_exists = (agent_path / "scroll.py").exists()
    soul_exists = (agent_path / "soul.json").exists()
    manifest_path = agent_path / MANIFEST_NAME

    if not scroll_exists or not soul_exists:
        return None

    manifest = {
        "name": name,
        "role": "TBD",
        "guardian": "TBD",
        "pillar": "TBD",
        "triggers": ["manual"],
        "entrypoint": "scroll.py",
        "outputs": ["logs/"],
        "dependencies": ["soul.json", "scroll.py"],
        "scheduler": {"weekly": "TBD"}
    }

    with open(manifest_path, "w") as f:
        yaml.dump(manifest, f, sort_keys=False)
    return manifest

def scan_directory(path):
    for agent_folder in path.iterdir():
        if agent_folder.is_dir():
            manifest_file = agent_folder / MANIFEST_NAME
            if not manifest_file.exists():
                print(f"[GENERATING] {manifest_file}")
                build_manifest(agent_folder, agent_folder.name)

if __name__ == "__main__":
    print("🔍 Scanning agents...")
    if BASE_DIR.exists():
        scan_directory(BASE_DIR)
    print("🔍 Scanning guardians...")
    if GUARDIAN_DIR.exists():
        scan_directory(GUARDIAN_DIR)
    print("✅ Manifest generation complete.")