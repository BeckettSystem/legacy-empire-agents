import os
import json
import argparse
from pathlib import Path

def apply_fixes(base_dir, report_path, rewrite_map_path, dry_run=False, backup=False):
    base = Path(base_dir)
    with open(report_path, 'r') as f:
        report = json.load(f)
    with open(rewrite_map_path, 'r') as f:
        rewrite_map = json.load(f)

    for item in report.get("broken", []):
        file_path = base / item["file"]
        if not file_path.exists():
            continue

        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        new_lines = []
        changed = False
        for line in lines:
            original_line = line
            for wrong, correct in rewrite_map.items():
                if wrong in line:
                    line = line.replace(wrong, correct)
                    changed = True
            new_lines.append(line)

        if changed:
            print(f"[FIXED] {file_path}")
            if not dry_run:
                if backup:
                    backup_path = file_path.with_suffix(".bak")
                    file_path.rename(backup_path)
                with open(file_path, "w", encoding="utf-8") as f:
                    f.writelines(new_lines)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--base_dir", required=True, help="Root of codebase")
    parser.add_argument("--report", required=True, help="Path to import validation report")
    parser.add_argument("--map", required=True, help="Path to import rewrite map JSON")
    parser.add_argument("--dry_run", action="store_true", help="Only simulate the changes")
    parser.add_argument("--backup", action="store_true", help="Backup original files as .bak")
    args = parser.parse_args()

    apply_fixes(args.base_dir, args.report, args.map, dry_run=args.dry_run, backup=args.backup)