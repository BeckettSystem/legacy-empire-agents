from flask import Blueprint, render_template, request
import subprocess
import os

import_fix_bp = Blueprint('import_fixer', __name__)

@import_fix_bp.route("/tools/import-fixer", methods=["GET", "POST"])
def import_fixer():
    result = ""
    if request.method == "POST":
        mode = request.form.get("mode", "dry_run")
        backup = "--backup" if "backup" in request.form else ""
        dry_run = "--dry_run" if mode == "dry_run" else ""
        command = f"python system/utilities/import_cleaner/auto_fix_imports.py --base_dir beckett_system --report system_import_validation_report.json --map import_rewrite_map.json {dry_run} {backup}"
        try:
            result = subprocess.getoutput(command)
        except Exception as e:
            result = str(e)
    return render_template("import_fix_report.html", result=result)