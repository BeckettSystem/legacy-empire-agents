"""
Webbridge Module – Guardian Alerts
Dispatches urgent system events to Valor, Pulse, or internal alerting system.
"""

import logging
from datetime import datetime

ALERT_LOG = "logs/system_alerts.log"

def raise_alert(agent_name, alert_type, message):
    alert_entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "agent": agent_name,
        "type": alert_type,
        "message": message
    }
    with open(ALERT_LOG, "a") as f:
        f.write(f"{alert_entry}\n")
    logging.warning(f"🚨 Alert from {agent_name}: {alert_type} – {message}")
    return alert_entry