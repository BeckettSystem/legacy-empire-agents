"""
Webbridge Module – API Bridge
Universal gateway for all external API calls, with auth loading, retry logic, and failover support.
"""

import os
import requests
import logging
from time import sleep
from dotenv import load_dotenv

load_dotenv()

API_KEYS = {
    "stripe": os.getenv("STRIPE_API_KEY"),
    "shopify": os.getenv("SHOPIFY_API_KEY"),
    "tiktok": os.getenv("TIKTOK_API_KEY"),
    "meta": os.getenv("META_ACCESS_TOKEN"),
    "google_trends": os.getenv("GOOGLE_TRENDS_KEY")
}

def call(api_name, endpoint, params=None, retries=3):
    if api_name not in API_KEYS:
        raise ValueError(f"❌ Unknown API: {api_name}")

    headers = {"Authorization": f"Bearer {API_KEYS[api_name]}"}
    base_urls = {
        "stripe": "https://api.stripe.com/v1/",
        "shopify": "https://yourstore.myshopify.com/admin/api/2023-07/",
        "tiktok": "https://business-api.tiktok.com/open_api/v1.2/",
        "meta": "https://graph.facebook.com/v17.0/",
        "google_trends": "https://trends.google.com/trends/api/"
    }

    url = base_urls[api_name] + endpoint
    for attempt in range(retries):
        try:
            response = requests.get(url, headers=headers, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logging.warning(f"Retry {attempt + 1}/{retries} for {api_name}: {e}")
            sleep(2)
    raise Exception(f"❌ API call to {api_name} failed after {retries} attempts.")