"""
System Utility – Quarantine Bin
Holds files or records that should not be deleted but are considered unsafe.
"""

def tag_for_quarantine(item, flag):
    return {
        "item": item,
        "flag": flag,
        "status": "held"
    }
