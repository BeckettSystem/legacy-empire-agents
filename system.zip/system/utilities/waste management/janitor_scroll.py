"""
Janitor Scroll – System Entropy Cleaner and Void Reclaimer
"""

import os, json
from datetime import datetime

DISPOSAL_LOG = os.path.join(os.path.dirname(__file__), "../../logs/janitor_disposal_log.json")
QUARANTINE_LOG = os.path.join(os.path.dirname(__file__), "../../quarantine/quarantine_index.json")

def log_disposal(item, reason):
    record = {"timestamp": datetime.utcnow().isoformat(), "item": item, "reason": reason}
    os.makedirs(os.path.dirname(DISPOSAL_LOG), exist_ok=True)
    log = []
    if os.path.exists(DISPOSAL_LOG):
        with open(DISPOSAL_LOG, "r") as f:
            log = json.load(f)
    log.append(record)
    with open(DISPOSAL_LOG, "w") as f:
        json.dump(log, f, indent=2)
    return f"🧼 Disposed: {item}"

def quarantine_item(item, reason):
    record = {"timestamp": datetime.utcnow().isoformat(), "item": item, "reason": reason}
    os.makedirs(os.path.dirname(QUARANTINE_LOG), exist_ok=True)
    qlog = []
    if os.path.exists(QUARANTINE_LOG):
        with open(QUARANTINE_LOG, "r") as f:
            qlog = json.load(f)
    qlog.append(record)
    with open(QUARANTINE_LOG, "w") as f:
        json.dump(qlog, f, indent=2)
    return f"🚫 Quarantined: {item}"
