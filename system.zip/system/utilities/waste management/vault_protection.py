"""
System Utility – Vault Protection Shield
Ensures protected scrolls/souls are never deleted or quarantined.
"""

def protect(item_name, protected_list):
    if item_name in protected_list:
        return "🔒 Vault-Protected: cannot modify"
    return "✅ Action permitted"
