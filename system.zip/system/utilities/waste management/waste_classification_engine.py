
def detect_waste_flags(content):
    flags = []
    if "expired" in content.lower():
        flags.append("structural_expiry")
    if "stressed" in content.lower() or "resentful" in content.lower():
        flags.append("emotional_residue")
    if "duplicated" in content.lower():
        flags.append("redundant_scroll")
    return flags
