"""
System Utility – Disposal Tracker
Logs what was deleted, why, and under what trigger.
"""

def track_disposal(source, content, trigger):
    return {
        "source": source,
        "removed": content,
        "trigger": trigger
    }
