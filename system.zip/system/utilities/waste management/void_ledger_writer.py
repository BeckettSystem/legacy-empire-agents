
from datetime import datetime

def archive_to_void(entry_id, reason):
    return {
        "entry_id": entry_id,
        "reason": reason,
        "ledger": "VOID",
        "action": "Permanently retired from scroll cycle",
        "timestamp": datetime.utcnow().isoformat()
    }
