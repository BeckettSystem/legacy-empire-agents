"""
System Utility – Override Tracker
Logs every scroll/soul override attempt across the system.
"""

def log_override(file_name, user, action):
    return {
        "file": file_name,
        "by": user,
        "action": action,
        "timestamp": datetime.utcnow().isoformat()
    }
