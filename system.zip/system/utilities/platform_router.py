"""
Webbridge Module – Platform Router
Translates abstract agent requests into the correct platform action.
"""

from api_bridge import call

def route(task, platform, data):
    if platform == "stripe" and task == "list_transactions":
        return call("stripe", "charges", data)
    elif platform == "shopify" and task == "get_products":
        return call("shopify", "products.json", data)
    elif platform == "tiktok" and task == "get_trending":
        return call("tiktok", "report/integrated/get", data)
    elif platform == "meta" and task == "get_ad_accounts":
        return call("meta", "me/adaccounts", data)
    else:
        raise ValueError(f"Unsupported route: {task} on {platform}")