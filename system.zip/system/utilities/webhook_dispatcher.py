"""
Webbridge Module – Webhook Dispatcher
Handles outbound and inbound webhook flows with logging and signature validation.
"""

import json
import hmac
import hashlib
import logging
import os

WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "test_secret")

def generate_signature(payload, secret=WEBHOOK_SECRET):
    return hmac.new(secret.encode(), payload.encode(), hashlib.sha256).hexdigest()

def validate_signature(payload, signature, secret=WEBHOOK_SECRET):
    expected = generate_signature(payload, secret)
    return hmac.compare_digest(expected, signature)

def dispatch_webhook(url, data, headers=None):
    import requests
    response = requests.post(url, json=data, headers=headers or {})
    return response.status_code, response.text