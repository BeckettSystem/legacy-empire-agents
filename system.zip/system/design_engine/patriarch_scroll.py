from flask import Blueprint, render_template, request, redirect, url_for
import json, os
from datetime import datetime

patriarch_scroll = Blueprint("patriarch_scroll", __name__)

# Load role settings
with open("media_engine/roles.json") as f:
    roles = json.load(f)

# Sample placeholder content until live data sources connect
def load_digest():
    with open("media_engine/output/patriarch_digest.json") as f:
        return json.load(f)

@patriarch_scroll.route("/patriarch-scroll")
def scroll():
    digest = load_digest()
    return render_template("patriarch_scroll.html", digest=digest, patriarch=roles["roles"]["patriarch"])
