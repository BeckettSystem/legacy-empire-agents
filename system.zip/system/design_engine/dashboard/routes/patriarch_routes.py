from flask import Blueprint, render_template, request, redirect, url_for, flash
import json, os, shutil
from datetime import datetime

patriarch_scroll = Blueprint("patriarch_scroll", __name__)

DIGEST_PATH = "media_engine/output/patriarch_digest.json"
HEIRLOOM_LOG = "media_engine/legacy/heirlooms/blessed_log.json"
HEIRLOOM_FOLDER = "media_engine/legacy/heirlooms/"


def load_digest():
    with open(DIGEST_PATH, "r") as f:
        return json.load(f)

def save_log(entry):
    if not os.path.exists(HEIRLOOM_LOG):
        log = []
    else:
        with open(HEIRLOOM_LOG, "r") as f:
            log = json.load(f)
    log.append(entry)
    with open(HEIRLOOM_LOG, "w") as f:
        json.dump(log, f, indent=2)

@patriarch_scroll.route("/patriarch-scroll")
def scroll():
    digest = load_digest()
    return render_template("patriarch_scroll.html", digest=digest)

@patriarch_scroll.route("/bless/<item_id>", methods=["POST"])
def bless(item_id):
    flash(f"Item {item_id} blessed by Patriarch.")
    return redirect(url_for("patriarch_scroll.scroll"))

@patriarch_scroll.route("/anoint/<item_id>", methods=["POST"])
def anoint(item_id):
    digest = load_digest()
    item = next((i for i in digest['content'] if i['id'] == item_id), None)
    if item:
        dest_folder = os.path.join(HEIRLOOM_FOLDER, item['type'] + 's')
        os.makedirs(dest_folder, exist_ok=True)
        filename = os.path.basename(item['file_path'])
        shutil.copy(item['file_path'], os.path.join(dest_folder, filename))

        log_entry = {
            "title": item['title'],
            "type": item['type'],
            "blessed_by": "Evan Beckett",
            "date": datetime.utcnow().isoformat(),
            "origin": item['file_path'],
            "notes": "Anointed via Patriarch's Scroll"
        }
        save_log(log_entry)
        flash(f"Item {item_id} anointed and archived.")
    return redirect(url_for("patriarch_scroll.scroll"))

@patriarch_scroll.route("/revoke/<item_id>", methods=["POST"])
def revoke(item_id):
    flash(f"Item {item_id} revoked.")
    return redirect(url_for("patriarch_scroll.scroll"))
