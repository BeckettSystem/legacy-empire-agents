
import os
import openai
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

if not OPENAI_API_KEY:
    raise EnvironmentError("❌ OPENAI_API_KEY not found in .env file.")

openai.api_key = OPENAI_API_KEY

def generate_response(prompt, model="gpt-4", temperature=0.7, max_tokens=500):
    try:
        response = openai.ChatCompletion.create(
            model=model,
            messages=[
                {"role": "system", "content": "You are a helpful assistant for the Beckett Legacy."},
                {"role": "user", "content": prompt}
            ],
            temperature=temperature,
            max_tokens=max_tokens
        )
        reply = response.choices[0].message["content"].strip()
        log_openai_use(prompt, reply)
        return reply
    except Exception as e:
        return f"⚠️ OpenAI error: {e}"

def log_openai_use(prompt, response):
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    with open(os.path.join(log_dir, "openai_usage.log"), "a", encoding="utf-8") as f:
        f.write(f"--- {datetime.now()} ---\n")
        f.write(f"Prompt: {prompt}\n")
        f.write(f"Response: {response}\n\n")
