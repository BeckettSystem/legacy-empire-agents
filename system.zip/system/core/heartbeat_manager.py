import json
import os
from datetime import datetime

REGISTRY_FILE = "agent_registry.json"
HEARTBEAT_FILE = "last_heartbeat.json"

def load_registry():
    with open(REGISTRY_FILE, "r") as f:
        return json.load(f)

def update_heartbeat(agent_id):
    now = datetime.now().isoformat()
    if os.path.exists(HEARTBEAT_FILE):
        with open(HEARTBEAT_FILE, "r") as f:
            heartbeats = json.load(f)
    else:
        heartbeats = {}
    heartbeats[agent_id] = now
    with open(HEARTBEAT_FILE, "w") as f:
        json.dump(heartbeats, f, indent=2)
    print(f"Heartbeat updated for {agent_id} at {now}")

def check_status():
    with open(HEARTBEAT_FILE, "r") as f:
        heartbeats = json.load(f)
    for agent, timestamp in heartbeats.items():
        print(f"{agent} last checked in at {timestamp}")

if __name__ == "__main__":
    agents = load_registry()
    print("Command Circle Active:")
    for aid in agents:
        update_heartbeat(aid)
    check_status()
