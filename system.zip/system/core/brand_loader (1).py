
import os
import yaml

BRAND_PROFILE_DIR = "/mnt/data/brand_profiles"

def load_brand_profile(profile_name):
    path = os.path.join(BRAND_PROFILE_DIR, f"{profile_name}.yaml")
    if not os.path.exists(path):
        return {"error": f"Brand profile '{profile_name}' not found."}

    with open(path, "r", encoding="utf-8") as f:
        profile = yaml.safe_load(f)
    return profile

def list_available_profiles():
    profiles = []
    for file in os.listdir(BRAND_PROFILE_DIR):
        if file.endswith(".yaml"):
            profiles.append(file.replace(".yaml", ""))
    return profiles
