from valor_agent import run_valor
from jimmy_agent import run_jimmy

def main():
    print("\n--- Beckett Real Estate Command Center ---\n")
    choice = input("Which agent would you like to activate? (valor/jimmy): ").lower()

    if choice == "valor":
        task = input("\nWhat strategic task should Valor execute?: ")
        print("\nValor's Response:\n")
        print(run_valor(task))

    elif choice == "jimmy":
        task = input("\nWhat creative task should Jimmy execute?: ")
        print("\nJimmy's Response:\n")
        print(run_jimmy(task))

    else:
        print("\nInvalid agent choice. Please select 'valor' or 'jimmy'.")

if __name__ == "__main__":
    main()
