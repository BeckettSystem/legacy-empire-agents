"""
Throne Room Flask Routes – Updated with Live Scroll & Heartbeat Logic
"""

from flask import Blueprint, render_template
import json
import os

throne_bp = Blueprint("throne", __name__)

def read_log(path):
    if not os.path.exists(path):
        return "No data available."
    with open(path, "r") as f:
        return f.read()

@throne_bp.route("/throne")
def throne_room():
    return render_template("throne_room.html",
        heartbeat_data=read_log("logs/heartbeat_status.json"),
        active_tasks=read_log("logs/active_tasks.json"),
        scroll_log=read_log("logs/scroll_activity.json"),
        weekly_report=read_log("logs/weekly_report.json")
    )
