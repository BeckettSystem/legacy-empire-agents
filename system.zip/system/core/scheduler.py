import schedule
import time
import importlib
from datetime import datetime

DAILY_TASKS = {
    "cipher": "Run market scan and risk assessment.",
    "sentinel": "Generate today's strategic intelligence report.",
    "seeker": "Identify auction and distressed assets in GA.",
    "scout": "Scan platforms for rising real estate content trends.",
    "echo": "Log today's legacy milestones and emotional shifts.",
    "kairos": "Design today's optimal time-blocked schedule.",
    "lumina": "Offer morning affirmation and clarity breathwork.",
    "titan": "Audit Atlas and Cipher for system issues.",
    "helm": "Review Juris and Sentinel for compliance drift.",
    "nyx": "Validate Blaze and Aurora campaign alignment.",
    "orion": "Scan Solon and Jimmy for narrative and financial integrity."
}

def run_agent(agent_name, task):
    try:
        module = importlib.import_module(f"{agent_name}_agent" if agent_name not in ["titan", "helm", "nyx", "orion"] else f"{agent_name}_guardian")
        run_fn = getattr(module, f"run_{agent_name}")
        output = run_fn(task)
        print(f"[{datetime.now().isoformat()}] ✅ {agent_name.upper()} completed task.")
    except Exception as e:
        print(f"[{datetime.now().isoformat()}] ❌ ERROR from {agent_name.upper()}: {str(e)}")

# Morning execution (6 AM)
for agent in ["cipher", "sentinel", "seeker", "scout", "kairos", "lumina"]:
    schedule.every().day.at("06:00").do(run_agent, agent_name=agent, task=DAILY_TASKS[agent])

# Guardians check every 3 hours
for agent in ["titan", "helm", "nyx", "orion"]:
    schedule.every(3).hours.do(run_agent, agent_name=agent, task=DAILY_TASKS[agent])

# Echo nightly log (9 PM)
schedule.every().day.at("21:00").do(run_agent, agent_name="echo", task=DAILY_TASKS["echo"])

def start_scheduler():
    print("⏳ Beckett Scheduler Running. Monitoring daily ops...")
    while True:
        schedule.run_pending()
        time.sleep(30)

if __name__ == "__main__":
    start_scheduler()
