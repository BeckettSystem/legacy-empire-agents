"""
Module: Audio Narrator
Reads scrolls aloud using a system-generated narrator for ritual, reflection, or announcement.
"""

def narrate(scroll_text, voice="patriarch"):
    return f"🔊 Narrating scroll in voice: {voice}...
{scroll_text[:120]}..."
