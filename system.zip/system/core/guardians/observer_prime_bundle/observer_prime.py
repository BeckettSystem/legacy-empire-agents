"""
Guardian: Observer Prime
Central awareness engine for system integrity, scroll tracking, and agent drift detection.
"""

from .drift_scanner import scan_agent_drift
from .guardian_advisor import recommend_action

def monitor_system():
    issues = scan_agent_drift()
    if issues:
        return recommend_action(issues)
    return "🧠 All agents aligned and scrolls clear."
