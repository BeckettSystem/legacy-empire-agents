"""
Scroll: Guardian Advisor
Recommends system corrections based on drift data or scroll anomalies.
"""

def recommend_action(drift_data):
    return f"⚠️ Observer Prime recommends scroll re-alignment for: {[d['agent'] for d in drift_data]}"
