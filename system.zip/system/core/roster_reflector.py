"""
Scroll: Roster Reflector
Scans the system for agent presence, soul/scroll alignment, and registry consistency.
"""

import os
import json

AGENTS_PATH = "agents/"
HABITATS_PATH = "system/habitats/"
REGISTRY_PATH = "system/agent_registry.json"

def load_registry():
    if os.path.exists(REGISTRY_PATH):
        with open(REGISTRY_PATH) as f:
            return json.load(f)
    return {}

def reflect_roster():
    registry = load_registry()
    findings = {"unregistered": [], "missing_scroll_home": []}
    known_agents = registry.keys()

    for root, dirs, files in os.walk(AGENTS_PATH):
        for file in files:
            if file.endswith("_agent.py"):
                name = file.replace("_agent.py", "")
                if name not in known_agents:
                    findings["unregistered"].append(name)
                else:
                    expected = registry[name].get("scroll_home")
                    if not expected or not os.path.exists(os.path.join(HABITATS_PATH, expected)):
                        findings["missing_scroll_home"].append(name)
    return findings
