"""
Module: Memory Mesh
Allows agents across domains to share scroll outcomes, decisions, and reflections.
"""

import json
import os

def write_shared_memory(agent, target_agent, insight):
    path = f"memory_mesh/{target_agent}_shared.json"
    if not os.path.exists(path):
        with open(path, "w") as f:
            json.dump([], f)
    with open(path, "r+") as f:
        data = json.load(f)
        data.append({"from": agent, "insight": insight})
        f.seek(0)
        json.dump(data, f, indent=2)
        f.truncate()
