import subprocess
import webbrowser
import time
import os

print("🚀 Launching Beckett Legacy System...")

# Step 1: Start scheduler in background
subprocess.Popen(["python", "core/scheduler.py"], creationflags=subprocess.CREATE_NEW_CONSOLE)

# Step 2: Wait to ensure agent ops begin
time.sleep(2)

# Step 3: Start Flask dashboard
subprocess.Popen(["python", "dashboard/command_center.py"], creationflags=subprocess.CREATE_NEW_CONSOLE)

# Step 4: Open browser
time.sleep(1)
webbrowser.open("http://localhost:5001")

print("🧠 Beckett Core & Command Center active.")
