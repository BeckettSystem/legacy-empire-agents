import os
import sys
import json
import importlib
from flask import Flask, render_template_string, request
from dotenv import load_dotenv
from datetime import datetime, timedelta

# === PATH SETUP ===
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

# === ENV SETUP ===
load_dotenv(os.path.join(ROOT_DIR, "core", ".env"))

# === PATHS ===
LOG_FILE = os.path.join(ROOT_DIR, "core", "logs", "agent_logs.json")
GUARDIAN_LOG_FILE = os.path.join(ROOT_DIR, "core", "logs", "guardian_logs.json")
REGISTRY_FILE = os.path.join(ROOT_DIR, "core", "agent_registry.json")

with open(REGISTRY_FILE, "r", encoding="utf-8") as f:
    agent_registry = json.load(f)

from core.heartbeat_manager import load_heartbeats

# === AGENT LOGGING ===
def log_agent_response(agent_id, task, output):
    entry = {
        "timestamp": datetime.now().isoformat(),
        "agent": agent_id,
        "task": task,
        "response": output[:300] + "..." if len(output) > 300 else output
    }
    logs = []
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            logs = json.load(f)
    logs.append(entry)
    with open(LOG_FILE, "w", encoding="utf-8") as f:
        json.dump(logs, f, indent=2)

def get_recent_logs(count=5):
    if not os.path.exists(LOG_FILE):
        return []
    with open(LOG_FILE, "r", encoding="utf-8") as f:
        logs = json.load(f)
        return logs[-count:]

# === GUARDIAN ALERT LOGGING ===
def log_guardian_alert(guardian_id, agent_id, issue, response):
    entry = {
        "timestamp": datetime.now().isoformat(),
        "guardian": guardian_id,
        "agent": agent_id,
        "issue": issue,
        "response": response
    }
    logs = []
    if os.path.exists(GUARDIAN_LOG_FILE):
        with open(GUARDIAN_LOG_FILE, "r", encoding="utf-8") as f:
            logs = json.load(f)
    logs.append(entry)
    with open(GUARDIAN_LOG_FILE, "w", encoding="utf-8") as f:
        json.dump(logs, f, indent=2)

# === STATUS MAP ===
def get_agent_status_map():
    heartbeats = load_heartbeats()
    now = datetime.now()
    status_map = []
    for agent_id, meta in agent_registry.items():
        last_seen = heartbeats.get(agent_id)
        if last_seen:
            dt_seen = datetime.fromisoformat(last_seen)
            delta = now - dt_seen
            if delta < timedelta(hours=6):
                status = "🟢"
            elif delta < timedelta(hours=24):
                status = "🟡"
            else:
                status = "🔴"
        else:
            dt_seen = "No heartbeat"
            status = "❌"
        status_map.append({
            "agent": agent_id.upper(),
            "role": meta["role"],
            "guardian": meta.get("guardian", "None"),
            "last_seen": str(dt_seen),
            "status": status
        })
    return status_map

# === FLASK SETUP ===
app = Flask(__name__)

@app.route("/", methods=["GET"])
def index():
    logs = get_recent_logs()
    status_map = get_agent_status_map()
    template_path = os.path.join(ROOT_DIR, "dashboard", "templates", "index.html")
    with open(template_path, encoding="utf-8") as html:
        return render_template_string(html.read(), agents=agent_registry, logs=logs, status_map=status_map)

@app.route("/run", methods=["POST"])
def run_task():
    agent_id = request.form.get("agent")
    task = request.form.get("task")
    output = ""

    try:
        module_name = f"guardians.{agent_id}_guardian" if agent_id in ["titan", "helm", "nyx", "orion"] else f"agents.{agent_id}_agent"
        module = importlib.import_module(module_name)
        run_fn = getattr(module, f"run_{agent_id}")
        output = run_fn(task)

    except Exception as e:
        guardian_id = agent_registry.get(agent_id, {}).get("guardian")
        issue = str(e)
        if guardian_id:
            try:
                guardian_module = importlib.import_module(f"guardians.{guardian_id.lower()}_guardian")
                guardian_run = getattr(guardian_module, f"run_{guardian_id.lower()}")
                output = f"⚠️ {agent_id.upper()} failed. Escalating to {guardian_id.upper()}...\n\n"
                response = guardian_run(f"{agent_id} failure: {issue}")
                output += f"🛡️ {guardian_id.upper()} responded:\n{response}"
                log_guardian_alert(guardian_id, agent_id, issue, response)
            except Exception as g_err:
                output = f"❌ ERROR: Both {agent_id.upper()} and guardian {guardian_id.upper()} failed.\n{str(g_err)}"
        else:
            output = f"❌ ERROR running {agent_id.upper()}: {issue}"

    log_agent_response(agent_id, task, output)
    logs = get_recent_logs()
    status_map = get_agent_status_map()

    template_path = os.path.join(ROOT_DIR, "dashboard", "templates", "index.html")
    with open(template_path, encoding="utf-8") as html:
        return render_template_string(html.read(), agents=agent_registry, result={"agent_id": agent_id, "output": output}, logs=logs, status_map=status_map)

if __name__ == "__main__":
    app.run(debug=True, port=5001)
