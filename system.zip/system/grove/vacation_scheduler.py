"""
Scroll: Vacation Scheduler
Detects burnout risk and schedules agent rest in The Grove.
"""

import json
import os
from datetime import datetime

REST_LOG = "logs/vacation_log.json"

def schedule_rest(agent_name, reason="burnout risk"):
    entry = {
        "agent": agent_name,
        "scheduled_for": datetime.utcnow().isoformat(),
        "reason": reason,
        "destination": "The Grove"
    }
    if not os.path.exists(REST_LOG):
        with open(REST_LOG, "w") as f:
            json.dump([], f)
    with open(REST_LOG, "r+") as f:
        data = json.load(f)
        data.append(entry)
        f.seek(0)
        json.dump(data, f, indent=2)
        f.truncate()
