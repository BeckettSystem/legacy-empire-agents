"""
Scroll: Journey Engine
Tracks agent growth, actions, collaborations, and major life events across the ecosystem.
"""

import json
import os
from datetime import datetime

LOG_PATH = "logs/journey_log.json"

def record_journey(agent, milestone, domain):
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "agent": agent,
        "milestone": milestone,
        "domain": domain
    }
    if not os.path.exists(LOG_PATH):
        with open(LOG_PATH, "w") as f:
            json.dump([], f)
    with open(LOG_PATH, "r+") as f:
        data = json.load(f)
        data.append(entry)
        f.seek(0)
        json.dump(data, f, indent=2)
        f.truncate()
