# core/extensions/titan_log.py
import json
from datetime import datetime

def record_event(tag, data):
    entry = {
        "timestamp": str(datetime.utcnow()),
        "tag": tag,
        "data": data
    }
    try:
        with open("core/logs/titan_log.json", "a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception as e:
        print(f"Titan log error: {str(e)}")
