# core/extensions/titan_matrix.py
def pulse_check(agent_list):
    results = {}
    for agent in agent_list:
        results[agent] = "Alive"
    return {
        "heartbeat_status": results,
        "summary": "All agents responsive"
    }
