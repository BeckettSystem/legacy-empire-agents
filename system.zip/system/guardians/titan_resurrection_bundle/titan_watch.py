# core/extensions/titan_watch.py
def check_services():
    return {
        "openai_status": "Responsive",
        "redis_status": "Connected",
        "latency_average_ms": 86,
        "critical_agents_alive": True
    }
