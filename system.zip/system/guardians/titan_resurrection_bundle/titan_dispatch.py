# core/extensions/titan_dispatch.py
def dispatch_alert(summary):
    return {
        "escalated_to": "Valor",
        "reason": summary,
        "status": "Escalated with priority"
    }
