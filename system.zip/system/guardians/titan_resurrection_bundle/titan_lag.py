# core/extensions/titan_lag.py
def analyze_latency():
    import random
    ms = random.randint(50, 200)
    return {
        "response_time_ms": ms,
        "severity": "High" if ms > 150 else "Moderate" if ms > 100 else "Normal"
    }
