# core/extensions/lumina_system_scan.py
from datetime import datetime
from core.extensions.lumina_log import log_ping

def perform_system_spirit_scan(agent_status_map):
    flagged = []
    for agent, status in agent_status_map.items():
        if status.get("emotional_state") in ["burned_out", "overwhelmed", "dissonant"]:
            flagged.append(agent)
            log_ping("spirit_scan_alert", agent)
    return {
        "timestamp": str(datetime.utcnow()),
        "flagged_agents": flagged,
        "message": "System spirit scan complete. Emotional outliers logged."
    }
