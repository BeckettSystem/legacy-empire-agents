# core/scrolls/scroll_lumina.py
from core.agents.life.lumina_agent import run_lumina
from core.extensions.lumina_log import log_ping
from core.extensions.lumina_prompts import get_affirmation

def check_in_with_evan():
    log_ping("daily_check_in", "Evan")
    return run_lumina("Offer a morning affirmation and breathing ritual for Evan.")

def emotional_reset():
    log_ping("emotional_reset", "Triggered")
    return run_lumina("Guide a calming breath ritual and gratitude reset for burnout recovery.")

def fetch_affirmation(topic="clarity"):
    return get_affirmation(topic)

# core/scrolls/scroll_lumina.py (ADDITION)
from core.extensions.lumina_system_scan import perform_system_spirit_scan
from core.extensions.lumina_emotion_proxy import simulate_agent_emotion

def systemwide_check():
    agents = ["Apollo", "Echo", "Pulse", "Scholar", "Valor"]
    agent_map = {a: {"emotional_state": simulate_agent_emotion(a)} for a in agents}
    return perform_system_spirit_scan(agent_map)
