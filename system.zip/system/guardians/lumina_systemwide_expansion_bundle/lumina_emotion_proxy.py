# core/extensions/lumina_emotion_proxy.py
def simulate_agent_emotion(agent_name):
    # Simulated emotional state logic (placeholder for integration with Pulse)
    sample_states = {
        "Apollo": "tired",
        "Echo": "overwhelmed",
        "Pulse": "alert",
        "Scholar": "focused",
        "Valor": "dissonant"
    }
    return sample_states.get(agent_name, "balanced")
