# core/extensions/lumina_log.py
import json
from datetime import datetime

def log_ping(event_type, target):
    ping = {
        "timestamp": str(datetime.utcnow()),
        "event": event_type,
        "target": target
    }
    try:
        with open("core/logs/lumina_log.json", "a") as f:
            f.write(json.dumps(ping) + "\n")
    except Exception as e:
        print(f"Lumina log failed: {str(e)}")
