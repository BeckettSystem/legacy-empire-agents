# core/extensions/lumina_prompts.py
def get_affirmation(topic="clarity"):
    bank = {
        "clarity": "Today, I breathe through the fog. My purpose is waiting in the stillness.",
        "resilience": "Every challenge is a fire I walk through — stronger, wiser, softer still.",
        "peace": "In the quiet, I remember who I am. I am safe. I am held. I am whole.",
        "focus": "Distractions drift. I choose where my energy lands. My mind is sharp. My heart is steady."
    }
    return bank.get(topic, bank["clarity"])
