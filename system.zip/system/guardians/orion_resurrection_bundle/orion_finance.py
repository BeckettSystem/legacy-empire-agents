# core/extensions/orion_finance.py
def evaluate_model(narrative, model_summary):
    model_flags = []
    if "profit-max" in model_summary.lower() and "legacy" in narrative.lower():
        model_flags.append("Short-term emphasis vs mission tone")
    if "cut cost" in model_summary.lower() and "luxury" in narrative.lower():
        model_flags.append("Cost mismatch with premium brand promise")
    return {
        "flags": model_flags,
        "summary": "Aligned" if not model_flags else "Needs review"
    }
