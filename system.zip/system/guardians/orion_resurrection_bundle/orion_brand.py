# core/extensions/orion_brand.py
def scan_tone(content):
    off_tone_words = ["cheap", "quick", "guaranteed", "limited time"]
    matches = [w for w in off_tone_words if w in content.lower()]
    return {
        "tone_drift": matches,
        "verdict": "Clean" if not matches else "Off-brand detected"
    }
