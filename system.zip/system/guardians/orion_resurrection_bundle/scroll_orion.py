# core/scrolls/scroll_orion.py
from core.agents.guardians.orion_agent import run_orion
from core.extensions.orion_brand import scan_tone
from core.extensions.orion_finance import evaluate_model
from core.extensions.orion_conflict import detect_conflict
from core.extensions.orion_sync import reconcile_alignment
from core.extensions.orion_log import archive_report
from core.extensions.orion_score import score_fidelity

def check_brand_alignment(content):
    return scan_tone(content)

def audit_financial_model(narrative, model_summary):
    return evaluate_model(narrative, model_summary)

def detect_strategic_drift(message, projection):
    return detect_conflict(message, projection)

def propose_reconciliation(brand, finance):
    return reconcile_alignment(brand, finance)

def log_orion_event(topic, insight):
    return archive_report(topic, insight)

def score_alignment(script):
    return score_fidelity(script)
