# core/extensions/orion_conflict.py
def detect_conflict(message, model_projection):
    if "legacy" in message.lower() and "subscription churn" in model_projection.lower():
        return {
            "conflict": True,
            "reason": "Legacy tone misaligned with high-churn monetization model"
        }
    return {"conflict": False}
