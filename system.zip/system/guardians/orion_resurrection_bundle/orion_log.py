# core/extensions/orion_log.py
import json
from datetime import datetime

def archive_report(topic, insight):
    entry = {
        "timestamp": str(datetime.utcnow()),
        "topic": topic,
        "insight": insight
    }
    try:
        with open("core/logs/orion_log.json", "a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception as e:
        print(f"Orion log error: {str(e)}")
