# core/extensions/orion_score.py
def score_fidelity(script):
    sacred_terms = ["legacy", "vision", "honor", "resonance"]
    score = sum(1 for term in sacred_terms if term in script.lower())
    return {
        "fidelity_score": score,
        "rating": "Aligned" if score >= 3 else "Risk of Drift"
    }
