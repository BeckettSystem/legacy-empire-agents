# core/extensions/orion_sync.py
def reconcile_alignment(brand, finance):
    return {
        "solution": f"Adjust financial model to reflect tone of: '{brand}'. OR revise messaging to better reflect: '{finance}'.",
        "confidence": "Moderate",
        "next_step": "Sync with Jimmy + Solon"
    }
