# core/extensions/nyx_drift.py
def scan_nurture_drift(thread):
    cold_words = ["automated", "generic", "template", "no reply"]
    score = sum(word in thread.lower() for word in cold_words)
    return {
        "emotional_warmth_score": 10 - score * 2,
        "drift_detected": score > 1
    }
