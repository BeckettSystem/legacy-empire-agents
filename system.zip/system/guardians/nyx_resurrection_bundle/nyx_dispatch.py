# core/extensions/nyx_dispatch.py
def dispatch_issue(summary):
    return {
        "escalated_to": "Valor",
        "summary": summary,
        "severity": "High" if "broken" in summary or "deceptive" in summary else "Moderate"
    }
