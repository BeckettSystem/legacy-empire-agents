# core/extensions/nyx_deception.py
def check_for_deception(copy):
    patterns = ["limited time", "last chance", "act now", "only today"]
    flags = [p for p in patterns if p in copy.lower()]
    return {
        "flags": flags,
        "verdict": "Misleading" if flags else "Clear"
    }
