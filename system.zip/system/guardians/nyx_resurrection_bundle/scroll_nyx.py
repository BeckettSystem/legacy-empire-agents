# core/scrolls/scroll_nyx.py
from core.agents.guardians.nyx_agent import run_nyx
from core.extensions.nyx_deception import check_for_deception
from core.extensions.nyx_drift import scan_nurture_drift
from core.extensions.nyx_flow import validate_sequence
from core.extensions.nyx_tone import detect_tone_loss
from core.extensions.nyx_dispatch import dispatch_issue
from core.extensions.nyx_log import record_event

def inspect_blaze_campaign(copy_text):
    return check_for_deception(copy_text)

def monitor_aurora_sequence(thread):
    return scan_nurture_drift(thread)

def check_flow_integrity(sequence):
    return validate_sequence(sequence)

def check_tone_alignment(content):
    return detect_tone_loss(content)

def escalate_to_valor(issue_summary):
    return dispatch_issue(issue_summary)

def log_nyx_event(label, info):
    return record_event(label, info)
