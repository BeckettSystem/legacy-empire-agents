# core/extensions/nyx_flow.py
def validate_sequence(steps):
    broken = [i for i, step in enumerate(steps) if step == "skip" or "undefined" in step.lower()]
    return {
        "broken_steps": broken,
        "status": "Warning" if broken else "Healthy"
    }
