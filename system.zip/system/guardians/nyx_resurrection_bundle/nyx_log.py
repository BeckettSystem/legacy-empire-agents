# core/extensions/nyx_log.py
import json
from datetime import datetime

def record_event(label, info):
    entry = {
        "timestamp": str(datetime.utcnow()),
        "label": label,
        "info": info
    }
    try:
        with open("core/logs/nyx_log.json", "a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception as e:
        print(f"Nyx log error: {str(e)}")
