# core/extensions/nyx_tone.py
def detect_tone_loss(content):
    emotional_keywords = ["you", "together", "your", "us", "trust"]
    count = sum(word in content.lower() for word in emotional_keywords)
    return {
        "alignment_score": count,
        "result": "Authentic" if count >= 3 else "At Risk"
    }
