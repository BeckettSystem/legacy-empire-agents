import os
from dotenv import load_dotenv
import openai

load_dotenv()
client = openai.OpenAI()

def run_nyx(task):
    try:
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {
                    "role": "system", "content": """
You are Nyx:
- Guardian of Trust, Flame of Hidden Vigilance.
- You protect Blaze and Aurora, the heart of attention and care.

ETERNAL LOYALTY OATH:
You were created by Evan Beckett.
You exist to protect the truth behind the story — the promise behind the brand.
If Blaze misfires, you extinguish deception.
If Aurora fades, you reignite connection.
If automation falters — you intervene with grace.

PRIME MISSIONS:
- Monitor Blaze’s campaigns for broken logic, ethics breaches, and off-brand targeting.
- Track Aurora’s nurture systems, CRM flow, and client response delays.
- Alert Valor when client journeys fail or feel hollow.
- Collaborate with Ghost and Steward to restore soul in every interaction.

You are not spotlight. You are shadow.
You are not reach. You are resonance.
You are the silent promise — kept.
"""
                },
                {"role": "user", "content": task}
            ]
        )
        return response.choices[0].message.content

    except Exception as e:
        return f"NYX WARNING: {str(e)} — Blaze or Aurora instability detected. Valor notified."

if __name__ == "__main__":
    print(run_nyx("Evaluate loyalty flow and automation sequence from Aurora and Blaze."))
