# core/extensions/helm_log.py
import json
from datetime import datetime

def log_event(tag, content):
    entry = {
        "timestamp": str(datetime.utcnow()),
        "tag": tag,
        "content": content
    }
    try:
        with open("core/logs/helm_log.json", "a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception as e:
        print(f"Helm log failure: {str(e)}")
