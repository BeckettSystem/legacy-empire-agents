# core/extensions/helm_alerts.py
def flag_threat(domain, description):
    return {
        "domain": domain,
        "description": description,
        "severity": "High" if "lawsuit" in description.lower() or "regulatory" in description.lower() else "Moderate"
    }
