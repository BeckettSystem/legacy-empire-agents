# core/extensions/helm_matrix.py
def get_override_matrix(agent):
    authority = {
        "Juris": ["Helm", "Valor"],
        "Sentinel": ["Helm", "Oracle"],
        "Echo": ["Valor", "Pulse"],
        "Pact": ["Helm", "Barrister"],
        "Tactician": ["Helm", "Scholar"]
    }
    return {
        "agent": agent,
        "override_by": authority.get(agent, ["Valor"])
    }
