# core/extensions/helm_audit.py
def review_legal_logic(logic_tree):
    risky_clauses = ["binding in perpetuity", "irrevocable", "liquidated damages"]
    flagged = [c for c in risky_clauses if c in logic_tree.lower()]
    return {
        "clauses_flagged": flagged,
        "score": 10 - len(flagged) * 2
    }
