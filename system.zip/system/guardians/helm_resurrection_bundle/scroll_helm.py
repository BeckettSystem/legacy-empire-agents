# core/scrolls/scroll_helm.py
from core.agents.guardians.helm_agent import run_helm
from core.extensions.helm_scan import audit_signal
from core.extensions.helm_audit import review_legal_logic
from core.extensions.helm_alerts import flag_threat
from core.extensions.helm_log import log_event
from core.extensions.helm_matrix import get_override_matrix
from core.extensions.helm_registry import precedent_lookup
from core.extensions.helm_pattern import track_drift

def evaluate_report(report):
    return audit_signal(report)

def review_juris_path(logic_tree):
    return review_legal_logic(logic_tree)

def raise_risk_alert(domain, description):
    return flag_threat(domain, description)

def store_guardian_log(tag, content):
    return log_event(tag, content)

def query_override(agent):
    return get_override_matrix(agent)

def lookup_precedent(topic):
    return precedent_lookup(topic)

def detect_drift(thread_log):
    return track_drift(thread_log)
