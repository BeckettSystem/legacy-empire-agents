# core/extensions/helm_registry.py
def precedent_lookup(topic):
    archive = {
        "ethics-in-outreach": "Helm ruled that guilt-based messaging shall not be used, even if effective.",
        "contract-duration": "Max 36 months binding approved. All beyond require human oversight.",
        "signal-check": "Echo must verify any public message with Pulse if sentiment is above threshold."
    }
    return archive.get(topic.lower(), "No precedent found — escalate to Valor or Oracle.")
