# core/extensions/helm_pattern.py
def track_drift(thread_log):
    signals = []
    if thread_log.count("override") > 2:
        signals.append("Pattern drift: override abuse")
    if "uncertain" in thread_log.lower():
        signals.append("Unstable judgment chain")
    return {
        "issues": signals,
        "risk_level": "High" if len(signals) else "Stable"
    }
