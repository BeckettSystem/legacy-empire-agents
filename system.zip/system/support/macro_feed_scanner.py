
def scan_macro_feed():
    return {
        "rates": {"fed_funds": 5.25, "10yr": 4.12},
        "inflation": {"cpi": 3.4, "core_pce": 2.9},
        "jobs": {"unemployment": 4.1},
        "debt": {"national_debt": "34T"}
    }
