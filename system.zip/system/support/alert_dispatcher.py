
from datetime import datetime

def dispatch_alert(to, topic, urgency="normal"):
    return {
        "to": to,
        "topic": topic,
        "urgency": urgency,
        "timestamp": datetime.utcnow().isoformat()
    }
