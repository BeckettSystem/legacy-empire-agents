
# flask_diplomat_route.py
from flask import Blueprint, request, jsonify
from utils.redis_handler import store_data
from datetime import datetime

diplomat_bp = Blueprint('diplomat_bp', __name__)

@diplomat_bp.route('/submit_conflict_event', methods=['POST'])
def submit_conflict_event():
    data = request.json
    source = data.get("from", "unknown")
    conflict = data.get("conflict")
    if not conflict:
        return jsonify({"error": "Missing 'conflict' field"}), 400

    entry = {
        "source": source,
        "conflict": conflict,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("diplomatic_event_queue", entry)
    return jsonify({"message": "Conflict event submitted", "entry": entry}), 200
