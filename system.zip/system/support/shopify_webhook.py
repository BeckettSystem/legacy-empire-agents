# shopify_webhook.py
from flask import Blueprint, request
from agents.dominion.merchant.merchant import Merchant

shopify_bp = Blueprint('shopify_bp', __name__)

@shopify_bp.route("/webhook/shopify", methods=["POST"])
def receive_shopify_order():
    order = request.json
    merchant = Merchant()
    product = order.get("line_items", [{}])[0].get("title", "Unknown Product")
    buyer = order.get("customer", {}).get("first_name", "Unknown Buyer")
    amount = float(order.get("total_price", 0))
    merchant.record_order(product, buyer, amount)
    return "", 200
