
# barrister_counsel_sync.py
from utils.redis_handler import store_data
from datetime import datetime

def prepare_case_package(case_data):
    package = {
        "title": "Legal Brief for Counsel",
        "contents": case_data,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("barrister_case_packages", package)
    return package
