# guardian_triggers.py
def check_legacy_alignment(venture):
    return True  # Placeholder logic

def alert_bastion(venture_name, performance):
    print(f"ALERT sent to Bastion for {venture_name}: {performance}")
