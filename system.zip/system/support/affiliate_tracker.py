# affiliate_tracker.py
import yaml

def load_affiliate_programs(path="support/merchant_affiliates.yaml"):
    with open(path, "r") as f:
        return yaml.safe_load(f)

def track_click(link):
    programs = load_affiliate_programs()
    for name, data in programs.get("programs", {}).items():
        if link.startswith(data["prefix"]):
            return {"program": name, "link": link, "status": "tracked"}
    return {"program": "unknown", "link": link, "status": "untracked"}
