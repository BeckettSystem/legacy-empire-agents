# stripe_webhook_listener.py
from flask import Blueprint, request

stripe_webhook_bp = Blueprint('stripe_webhook_bp', __name__)

@stripe_webhook_bp.route("/webhook/stripe", methods=["POST"])
def stripe_webhook():
    payload = request.json
    print("Received Stripe event:", payload)
    return "", 200
