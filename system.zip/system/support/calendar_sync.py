# calendar_sync.py
def get_calendar_events():
    # Placeholder for Google or Calendly calendar sync
    return ["Showing at 10 AM", "Inspection at 2 PM"]
