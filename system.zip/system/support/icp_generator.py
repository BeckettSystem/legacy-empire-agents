
def build_icp(demographic, psychographics, platform_habits, pain_points):
    return {
        "audience": demographic,
        "psychographics": psychographics,
        "platform_habits": platform_habits,
        "pain_points": pain_points,
        "persona_summary": f"{demographic} who often {psychographics[0]}, prefers {platform_habits[0]}, and struggles with {pain_points[0]}."
    }
