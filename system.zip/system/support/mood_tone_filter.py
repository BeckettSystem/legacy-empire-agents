
def analyze_tone(message):
    if any(word in message.lower() for word in ["frustrated", "angry", "confused", "cold"]):
        return "⚠️ Needs gentle follow-up"
    elif any(word in message.lower() for word in ["thank you", "excited", "love", "happy"]):
        return "💚 Positive engagement"
    return "🟡 Neutral"
