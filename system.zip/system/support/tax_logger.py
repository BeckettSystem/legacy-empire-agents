# tax_logger.py
import json

def tag_income(entry, categories_path="support/categories.yaml"):
    import yaml
    with open(categories_path, "r") as f:
        categories = yaml.safe_load(f)
    for key, tags in categories.items():
        if entry["source"] in tags:
            entry["category"] = key
            break
    return entry
