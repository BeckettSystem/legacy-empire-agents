
from datetime import datetime

def dispatch_to_allies(asset, classification, risk_flag):
    return {
        "asset": asset,
        "classification": classification,
        "risk_flag": risk_flag,
        "handoffs": [
            {"to": "griffin", "task": "Overlay match analysis"},
            {"to": "solon", "task": "ROI model"},
            {"to": "echo", "task": "Investor-ready description"},
            {"to": "blaze", "task": "Flag for marketing or flip route"},
            {"to": "cipher", "task": "Add to legacy asset log"}
        ],
        "timestamp": datetime.utcnow().isoformat()
    }
