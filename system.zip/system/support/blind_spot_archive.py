
from datetime import datetime

def log_blind_spot(topic, missed_by, discovered_by):
    return {
        "topic": topic,
        "missed_by": missed_by,
        "discovered_by": discovered_by,
        "timestamp": datetime.utcnow().isoformat(),
        "action": "Archived for growth awareness"
    }
