
def map_local_insight(zip_code):
    return {
        "zip": zip_code,
        "housing_movement": "rising multi-unit permits",
        "school_closure": False,
        "cultural_event": "Latinx community expansion festival",
        "economic_signal": "Commercial vacancy down 7% over 3 months"
    }
