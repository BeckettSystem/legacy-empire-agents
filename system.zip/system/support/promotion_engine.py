# promotion_engine.py
import json
import requests

def load_campaigns(path="support/merchant_promotions.json"):
    with open(path, "r") as f:
        return json.load(f)

def launch_campaign(product_name):
    campaigns = load_campaigns()
    campaign_id = campaigns.get(product_name)
    if campaign_id:
        response = requests.post("http://localhost:5000/alchemist/launch_campaign", json={"campaign_id": campaign_id})
        return response.status_code
    return 404
