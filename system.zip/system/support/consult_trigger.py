
from datetime import datetime

def trigger_consult(client_name, method="chat"):
    return {
        "client": client_name,
        "trigger_method": method,
        "timestamp": datetime.utcnow().isoformat(),
        "action": "Live consult offered"
    }
