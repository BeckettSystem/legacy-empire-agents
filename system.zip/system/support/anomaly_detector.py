# anomaly_detector.py
def detect_anomalies(transactions):
    seen = set()
    anomalies = []
    for tx in transactions:
        tx_id = f"{tx['source']}_{tx['amount']}_{tx['currency']}"
        if tx_id in seen:
            anomalies.append(tx)
        else:
            seen.add(tx_id)
    return anomalies
