
def scrape_assets(source="GSA"):
    mock_data = [
        {"source": "GSA", "type": "commercial", "price": 125000, "location": "Atlanta, GA", "url": "https://gsa.gov/asset-123"},
        {"source": "HUD", "type": "residential", "price": 89000, "location": "Macon, GA", "url": "https://hud.gov/asset-456"}
    ]
    return [a for a in mock_data if a["source"] == source or source == "ALL"]
