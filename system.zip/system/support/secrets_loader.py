# secrets_loader.py
import json

def load_secrets(path="secrets.json"):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        raise Exception("Secrets file not found at " + path)
