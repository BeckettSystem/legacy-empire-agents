
# barrister_legal_engine.py
from datetime import datetime

def build_defense(scenario):
    return {
        "strategy": "defense",
        "position": "Deny wrongdoing. Present facts. Reference clauses.",
        "notes": f"Scenario reviewed: {scenario}",
        "timestamp": datetime.utcnow().isoformat()
    }

def draft_claim(scenario):
    return {
        "strategy": "claim",
        "position": "Detail harm. Cite violation. Demand remedy.",
        "notes": f"Claim based on: {scenario}",
        "timestamp": datetime.utcnow().isoformat()
    }

def simulate_opposition(scenario):
    return {
        "assumed_counter": "They may dispute intent, claim waiver, or miscommunication.",
        "scenario": scenario,
        "timestamp": datetime.utcnow().isoformat()
    }
