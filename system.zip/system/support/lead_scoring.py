# lead_scoring.py
def score_lead(lead):
    # Basic example logic
    score = 0
    if lead.get("budget") > 500000:
        score += 20
    if lead.get("status") == "active":
        score += 10
    if lead.get("location") in ["Smyrna", "Atlanta"]:
        score += 10
    return score
