
# diplomat_tone_engine.py
from datetime import datetime

def generate_tone_response(conflict):
    tone = "clarifying"
    if "angry" in conflict.lower() or "upset" in conflict.lower():
        tone = "empathic"
    elif "misunderstood" in conflict.lower() or "confused" in conflict.lower():
        tone = "explanatory"
    return {
        "recommended_tone": tone,
        "timestamp": datetime.utcnow().isoformat()
    }

def suggest_script(conflict_type="client"):
    if conflict_type == "client":
        return "We hear your concern and want to make this right. Here's what we can do..."
    elif conflict_type == "public":
        return "We understand your frustration — clarity is our goal. Let’s talk directly."
    else:
        return "We appreciate your feedback. We're committed to realignment and clarity."
