# refund_handler.py
from datetime import datetime
from scroll.scroll_update_protocol import update_scroll

def process_refund(product, buyer, reason="unspecified"):
    timestamp = datetime.now().isoformat()
    with open("scroll/refund_log.md", "a") as f:
        f.write(f"{timestamp} | {product} | {buyer} | REFUNDED | Reason: {reason}\n")
    update_scroll(f"Merchant: Refunded {product} for {buyer} due to {reason}.")
