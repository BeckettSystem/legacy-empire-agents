
# flask_barrister_route.py
from flask import Blueprint, request, jsonify
from utils.redis_handler import store_data
from datetime import datetime

barrister_bp = Blueprint('barrister_bp', __name__)

@barrister_bp.route('/submit_case_review', methods=['POST'])
def submit_case_review():
    data = request.json
    scenario = data.get("scenario")
    source = data.get("from", "unknown")
    case_type = data.get("type", "general")
    if not scenario:
        return jsonify({"error": "Missing 'scenario' field"}), 400

    entry = {
        "source": source,
        "type": case_type,
        "scenario": scenario,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("barrister_case_queue", entry)
    return jsonify({"message": "Case review submitted to Barrister", "entry": entry}), 200
