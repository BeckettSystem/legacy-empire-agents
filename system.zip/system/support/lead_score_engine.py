
def score_lead(notice, contact):
    base_score = 50
    if "foreclosure" in notice["type"]:
        base_score += 20
    if "deceased" in notice["name"].lower():
        base_score += 10
    if contact["email"]:
        base_score += 10
    return {
        "score": min(base_score, 100),
        "rating": "🔥" if base_score > 75 else "⚠️" if base_score > 60 else "🕊️"
    }
