
from datetime import datetime

memory_log = []

def thread_memory(note, context):
    entry = {
        "note": note,
        "context": context,
        "timestamp": datetime.utcnow().isoformat()
    }
    memory_log.append(entry)
    return entry
