
from datetime import datetime

def log_competitor_gap(competitor_name, weak_spot, new_target):
    return {
        "competitor": competitor_name,
        "weakness": weak_spot,
        "opportunity": new_target,
        "timestamp": datetime.utcnow().isoformat()
    }
