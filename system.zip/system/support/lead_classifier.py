
def classify_lead(asset):
    if asset["score"] >= 30:
        return "🔥 Immediate Action"
    elif asset["score"] >= 20:
        return "⚠️ Watchlist"
    return "🕊️ Low Priority"
