
def detect_subculture_signals(channel):
    samples = {
        "discord": ["AI research DAOs", "Real estate trading guilds"],
        "newsletter": ["Indie developers monetizing templates", "Crypto native publishing"],
        "youtube": ["Shadow journaling", "Sovereignty farming"]
    }
    return samples.get(channel.lower(), [])
