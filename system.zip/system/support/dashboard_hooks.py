# dashboard_hooks.py
"""
Flask hooks for manually triggering Tycoon from the dashboard UI
"""
from flask import Blueprint, jsonify
from agents.dominion.tycoon import Tycoon

tycoon_bp = Blueprint('tycoon_bp', __name__)

@tycoon_bp.route("/trigger/tycoon", methods=["POST"])
def trigger_tycoon():
    tycoon = Tycoon()
    tycoon.run_weekly_review()
    return jsonify({"status": "Tycoon review complete"})
