
from datetime import datetime

def build_narrative(grant):
    return {
        "header": f"Funding Narrative: {grant['title']}",
        "intro": f"This opportunity is ideal for Beckett due to our alignment with {grant['goal']}.",
        "partners": ["Echo", "Barrister", "Apollo"],
        "objectives": [
            "Enhance community access to affordable housing",
            "Leverage federal capital to uplift underserved areas"
        ],
        "timestamp": datetime.utcnow().isoformat()
    }
