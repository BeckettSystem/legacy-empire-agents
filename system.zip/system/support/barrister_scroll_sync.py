
# barrister_scroll_sync.py
from utils.redis_handler import store_data
from datetime import datetime

def log_to_scroll(case_summary):
    entry = {
        "origin": "Barrister",
        "type": "legal_case",
        "content": case_summary,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("patriarch_scroll_log", entry)
    return entry

def index_to_chronos(case_event):
    entry = {
        "agent": "Barrister",
        "event": "legal_event",
        "data": case_event,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("chronos_milestones", entry)
    return entry

def store_case_to_archive(case_event):
    entry = {
        "origin": "Barrister",
        "type": "case_archive",
        "data": case_event,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("archivist_case_log", entry)
    return entry
