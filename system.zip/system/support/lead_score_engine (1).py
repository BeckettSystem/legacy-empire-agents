
def score_lead_activity(log):
    score = 0
    if "responded" in log:
        score += 20
    if "clicked_link" in log:
        score += 15
    if "asked to tour" in log:
        score += 30
    if "ghosted" in log:
        score -= 25
    return {
        "score": score,
        "status": "🔥 HOT" if score >= 60 else "⚠️ Warm" if score >= 30 else "❄️ Cold"
    }
