
def match_dpa_programs(programs, buyer_profile):
    matches = []
    for p in programs:
        if buyer_profile.get("income") <= p["income_limit"] and buyer_profile.get("credit_score") >= p["min_credit_score"]:
            if buyer_profile.get("location") in p["regions"]:
                matches.append(p)
    return matches
