
# diplomat_scroll_log.py
from utils.redis_handler import store_data
from datetime import datetime

def log_to_scroll(resolution):
    entry = {
        "origin": "Diplomat",
        "type": "conflict_resolution",
        "content": resolution,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("patriarch_scroll_log", entry)
    return entry

def index_to_chronos(event):
    log = {
        "agent": "Diplomat",
        "event": "resolution_event",
        "data": event,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("chronos_milestones", log)
    return log

def store_to_archive(event):
    record = {
        "origin": "Diplomat",
        "type": "peace_log",
        "content": event,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("archivist_resolution_log", record)
    return record
