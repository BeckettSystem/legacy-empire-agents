
def match_properties(listings, criteria):
    results = []
    for listing in listings:
        if (
            listing.get("beds") >= criteria.get("beds", 0)
            and listing.get("baths") >= criteria.get("baths", 0)
            and listing.get("sqft", 0) >= criteria.get("sqft", 0)
            and listing.get("price", 0) <= criteria.get("budget", float("inf"))
            and criteria.get("location", "").lower() in listing.get("location", "").lower()
        ):
            results.append(listing)
    return results
