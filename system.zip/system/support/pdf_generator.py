# pdf_generator.py
from fpdf import FPDF

def generate_cma_pdf(report, filename="CMA_Report.pdf"):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt="CMA Report", ln=True, align='C')
    for key, value in report.items():
        pdf.cell(200, 10, txt=f"{key}: {value}", ln=True)
    pdf.output(filename)
