
def detect_persona_drift(current_icp, past_icp):
    drift = []
    for key in current_icp:
        if current_icp[key] != past_icp.get(key, None):
            drift.append(key)
    return {
        "fields_shifted": drift,
        "drift_score": len(drift)
    }
