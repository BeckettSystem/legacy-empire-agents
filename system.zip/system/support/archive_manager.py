# archive_manager.py
from datetime import datetime
import shutil

def archive_ledger(source_path="scroll/ledger.md"):
    today = datetime.today().strftime("%Y%m%d")
    archive_path = f"scroll/archive/ledger_backup_{today}.md"
    shutil.copy(source_path, archive_path)
    return archive_path
