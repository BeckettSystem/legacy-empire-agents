# stripe_bridge.py
import requests
from support.secrets_loader import load_secrets

def fetch_stripe_transactions():
    secrets = load_secrets()
    api_key = secrets.get("stripe_secret_key")
    if not api_key:
        raise Exception("Stripe API key missing.")

    response = requests.get(
        "https://api.stripe.com/v1/charges",
        headers={"Authorization": f"Bearer {api_key}"}
    )
    return response.json()
