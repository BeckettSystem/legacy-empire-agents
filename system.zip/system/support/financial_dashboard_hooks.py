# financial_dashboard_hooks.py
from flask import Blueprint, jsonify
from agents.dominion.collector.collector import Collector

collector_bp = Blueprint('collector_bp', __name__)

@collector_bp.route("/collector/summary", methods=["GET"])
def get_summary():
    collector = Collector()
    total = collector.summarize()
    return jsonify({"total_logged": total})
