
# diplomat_sync.py
from utils.redis_handler import store_data
from datetime import datetime

def alert_barrister(issue):
    entry = {
        "from": "Diplomat",
        "to": "Barrister",
        "type": "legal_tension",
        "context": issue,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("barrister_conflict_queue", entry)
    return entry

def ping_juris(issue):
    entry = {
        "from": "Diplomat",
        "to": "Juris",
        "type": "contract_confusion",
        "note": issue,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("juris_conflict_review", entry)
    return entry

def report_to_mentor(agent_issue):
    entry = {
        "from": "Diplomat",
        "to": "Mentor",
        "type": "repeating_client_issue",
        "note": agent_issue,
        "timestamp": datetime.utcnow().isoformat()
    }
    store_data("mentor_behavior_alert", entry)
    return entry
