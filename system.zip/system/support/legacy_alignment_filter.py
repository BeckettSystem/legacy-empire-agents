
def check_alignment(idea, values):
    return all(value.lower() in idea.lower() for value in values)
