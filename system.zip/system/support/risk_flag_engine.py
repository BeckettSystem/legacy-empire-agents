
def flag_risks(asset):
    if asset["price"] > 150000:
        return "🟥 Overbudget Risk"
    if "Macon" in asset["location"]:
        return "🟨 Secondary Market Zone"
    return "🟩 No Risk"
