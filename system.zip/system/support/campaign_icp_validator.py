
def validate_campaign_to_icp(campaign, icp):
    issues = []
    if campaign.get("tone") not in icp.get("psychographics", []):
        issues.append("Tone mismatch")
    if campaign.get("platform") not in icp.get("platform_habits", []):
        issues.append("Wrong platform")
    if not any(p in campaign.get("message", "") for p in icp.get("pain_points", [])):
        issues.append("Pain point misalignment")
    return {
        "campaign_name": campaign.get("name", "Unknown"),
        "alignment_issues": issues,
        "status": "✅ Approved" if not issues else "⚠️ Needs Refinement"
    }
