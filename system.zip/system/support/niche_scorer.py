
def score_niche(niche):
    score = 0
    if "underserved" in niche.lower():
        score += 20
    if "fast-growing" in niche.lower():
        score += 30
    if "emotional" in niche.lower():
        score += 25
    return {
        "total_score": score,
        "signal": "🔥 Prime Target" if score >= 60 else "⚠️ Worth Watching"
    }
