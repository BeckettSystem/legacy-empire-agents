
def compare_to_last_week(current_data, previous_data):
    delta_report = []
    for key in current_data:
        if key in previous_data and current_data[key] != previous_data[key]:
            delta_report.append(f"{key} changed from {previous_data[key]} to {current_data[key]}")
    return delta_report
