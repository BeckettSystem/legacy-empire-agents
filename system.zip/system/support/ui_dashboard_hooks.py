# ui_dashboard_hooks.py
from flask import Blueprint, jsonify
from agents.dominion.broker.broker import Broker

broker_bp = Blueprint('broker_bp', __name__)

@broker_bp.route("/trigger/broker/sync", methods=["POST"])
def sync_broker_listings():
    broker = Broker()
    broker.sync_listings()
    return jsonify({"status": "Broker listings synced."})

@broker_bp.route("/trigger/broker/cma", methods=["POST"])
def generate_cma():
    broker = Broker()
    report = broker.run_cma("123 Main St")
    return jsonify(report)
