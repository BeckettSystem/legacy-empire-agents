# pdf_financial_export.py
from fpdf import FPDF

def export_financial_summary(data, filename="financial_summary.pdf"):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt="Financial Summary", ln=True, align='C')
    for item in data:
        pdf.cell(200, 10, txt=str(item), ln=True)
    pdf.output(filename)
