# auto_emailer.py
import smtplib
from email.message import EmailMessage

def send_email(subject, content, to_email, from_email="broker@beckettlegacy.com"):
    msg = EmailMessage()
    msg.set_content(content)
    msg['Subject'] = subject
    msg['From'] = from_email
    msg['To'] = to_email

    # Replace with real credentials / SMTP config
    try:
        with smtplib.SMTP('localhost') as s:
            s.send_message(msg)
        return True
    except Exception as e:
        return str(e)
