# followupboss_bridge.py
def sync_fub_clients(api_key):
    # Placeholder for Follow Up Boss API integration
    return [{"name": "Client A", "status": "active"}, {"name": "Client B", "status": "new"}]
