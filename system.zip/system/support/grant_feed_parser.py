
def parse_grants(feed_data, filters):
    matches = []
    for grant in feed_data:
        if filters.get("topic") in grant["title"].lower() and filters.get("state") in grant["eligibility"].lower():
            matches.append(grant)
    return matches
