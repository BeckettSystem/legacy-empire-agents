
def classify_event(event_text):
    if any(term in event_text.lower() for term in ["fed", "collapse", "sanction", "rate hike", "layoffs"]):
        return "🟥 threat"
    elif any(term in event_text.lower() for term in ["funding", "launch", "discovery", "breakthrough"]):
        return "🟩 opportunity"
    return "🟧 monitor"
