
from datetime import datetime

def dispatch_to_reforging(entry):
    return {
        "sent_to": ["Prometheus", "Scholar"],
        "payload": entry,
        "action": "Eligible for scroll rebirth or training reuse",
        "timestamp": datetime.utcnow().isoformat()
    }
