
def send_email(to_email, subject, body):
    return {
        "method": "email",
        "to": to_email,
        "subject": subject,
        "body": body,
        "status": "sent"
    }

def send_text(to_number, message):
    return {
        "method": "sms",
        "to": to_number,
        "message": message,
        "status": "sent"
    }

def log_call(name, notes):
    return {
        "method": "call_log",
        "client": name,
        "notes": notes,
        "status": "logged"
    }
