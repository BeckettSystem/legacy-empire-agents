
def scan_viral_backscatter(data_source):
    trends = {
        "tiktok": ["AI girlfriends", "silent luxury", "ghost kitchens"],
        "reddit": ["hyper-niche microservices", "anti-influencer trends", "decentralized real estate"],
        "twitter": ["sovereign individualism", "tokenized equity", "AI ghostwriting"]
    }
    return trends.get(data_source.lower(), [])
