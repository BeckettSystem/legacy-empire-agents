# forecasting.py
"""
Basic Prophet forecasting logic (can be replaced with LSTM or ARIMA)
"""
from prophet import Prophet
import pandas as pd

def create_forecast(df, periods=30):
    model = Prophet()
    model.fit(df)
    future = model.make_future_dataframe(periods=periods)
    forecast = model.predict(future)
    return forecast
