# scroll_digest_writer.py
def write_scroll_digest(total, entry_count):
    with open("scroll/scroll_digest.md", "a") as f:
        f.write(f"Collector Digest: {entry_count} entries totaling ${total}\n")
