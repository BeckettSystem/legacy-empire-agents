
def rank_assets(assets):
    results = []
    for asset in assets:
        score = 0
        if asset["price"] < 100000:
            score += 20
        if "residential" in asset["type"]:
            score += 10
        results.append({**asset, "score": score})
    return sorted(results, key=lambda x: x["score"], reverse=True)
