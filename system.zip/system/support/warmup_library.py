# warmup_library.py
def psychological_prep(name):
    return f"Visualize the moment {name} says yes. Feel the deal closing. Enter calm power."
