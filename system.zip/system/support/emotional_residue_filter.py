
def filter_emotional_decay(logs):
    filtered = []
    for log in logs:
        if any(term in log.lower() for term in ["pain", "loss", "resentment", "regret", "guilt"]):
            filtered.append(log)
    return filtered
