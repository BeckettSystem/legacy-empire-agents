
from datetime import datetime

def log_hypothesis(statement, source, confidence=0.5):
    return {
        "hypothesis": statement,
        "source": source,
        "confidence_level": confidence,
        "logged_at": datetime.utcnow().isoformat()
    }
