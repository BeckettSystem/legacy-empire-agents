
def categorize_notice(notice):
    mapping = {
        "foreclosure": "distressed_seller",
        "probate": "estate_lead",
        "divorce": "motivated_sale",
        "tax_sale": "investor_alert"
    }
    return mapping.get(notice["type"], "general_notice")
