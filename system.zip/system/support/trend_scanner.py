
def scan_trends(platform):
    if platform.lower() == "tiktok":
        return ["Home hacking content", "Millennial money struggles", "DIY investing"]
    if platform.lower() == "youtube":
        return ["Real estate react channels", "Tiny home documentary buzz"]
    return ["Unusual finance niches", "Crowdfunded real estate sentiment"]
