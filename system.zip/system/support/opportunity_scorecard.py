
def score_opportunity(niche):
    score = 0
    if niche.get("audience_size", 0) > 100000:
        score += 25
    if niche.get("urgency") == "high":
        score += 20
    if niche.get("emotional_resonance") == "strong":
        score += 25
    if niche.get("legacy_alignment") == "true":
        score += 30
    return {
        "total_score": score,
        "grade": "🔥 Greenlight" if score >= 75 else "⚠️ Investigate" if score >= 50 else "🕊️ Archive"
    }
