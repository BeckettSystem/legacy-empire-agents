# cma_generator.py
def generate_cma(subject_address, comps):
    return {
        "subject": subject_address,
        "comps": comps,
        "estimated_value": sum([c["price"] for c in comps]) / len(comps)
    }
