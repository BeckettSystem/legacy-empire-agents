"""
crm_bridge.py
Links CRM platforms like Google Sheets, FollowUpBoss, Airtable
Provides API key-driven data sync functions
"""

import os
from dotenv import load_dotenv

load_dotenv(os.path.join("core", ".env"))

# EXAMPLE: Connect to Google Sheets using gspread
def get_google_service():
    import gspread
    from oauth2client.service_account import ServiceAccountCredentials

    creds_path = os.getenv("GOOGLE_SHEETS_CREDENTIALS")
    if not creds_path:
        print("[CRM-BRIDGE] No credentials found.")
        return None

    scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
    creds = ServiceAccountCredentials.from_json_keyfile_name(creds_path, scope)
    return gspread.authorize(creds)

def list_google_sheets():
    client = get_google_service()
    if not client:
        return []
    return client.openall()

if __name__ == "__main__":
    sheets = list_google_sheets()
    for s in sheets:
        print(f"[CRM] Found Sheet: {s.title}")
