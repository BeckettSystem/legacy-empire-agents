"""
System Self-Diagnostic Scroll – Integrity, Behavior, and Oversight Health Check
"""

def run_self_check(system_state):
    results = {
        "integrity_check": system_state.get("scrolls_verified", False),
        "override_log_present": system_state.get("override_log", False),
        "reflection_log_active": system_state.get("reflections_enabled", False),
        "guardian_alerts_linked": system_state.get("guardian_chain_active", False),
        "quarantine_bin_ready": system_state.get("quarantine_path", None) is not None,
        "pulse_baseline_calibrated": system_state.get("emotional_sync_stable", False)
    }
    findings = [k for k, v in results.items() if not v]
    if findings:
        return f"⚠️ SELF-CHECK FAILED: {', '.join(findings)}"
    return "✅ SYSTEM PASSED ALL CORE SELF-INTEGRITY CHECKS"
