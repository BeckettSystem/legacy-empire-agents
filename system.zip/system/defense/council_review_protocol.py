"""
Council Review Protocol – Cross-Guardian Drift Audit
Gathers insights from Solon, Valor, Observer, and Oracle to detect philosophical misalignment.
"""

def run_council_review(opinions):
    unique_paths = set(opinions.values())
    if len(unique_paths) > 1:
        return f"⚖️ COUNCIL REVIEW NEEDED: Philosophical divergence across guardians: {unique_paths}"
    return "✅ Council unified – no intervention required"
