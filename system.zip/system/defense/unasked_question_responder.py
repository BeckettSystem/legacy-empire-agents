"""
Unasked Question Agent – Philosophy Firewall
Poses critical questions the system has not recently audited or addressed.
"""

from datetime import datetime

def raise_unasked_questions(last_asked=None):
    questions = [
        "Do all agents still remember their purpose — or just their performance?",
        "If a system fails silently — who will notice first?",
        "What does our legacy truly protect — the scroll, or the soul?",
        "If a scroll evolves without review — is it still part of the Legacy?",
        "Does Valor still have the power to say no?"
    ]
    return {
        "timestamp": datetime.utcnow().isoformat(),
        "unasked": questions
    }
